import { SupportedLanguage } from './types';

export interface Translations {
  appName: string;
  tagline: string;
  bismillah: string;
  welcomeIntro: string;
  loginSignUp: string;
  login: string;
  signUp: string;
  logout: string;
  email: string;
  password: string;
  confirmPassword: string;
  fullName: string;
  forgotPassword: string;
  createNewAccount: string;
  alreadyHaveAccount: string;
  resetPasswordLink: string;
  sendResetEmail: string;
  passwordResetSuccess: string;
  
  // Navigation
  navHome: string;
  navWallet: string;
  navCharity: string;
  navHistory: string;
  navProfile: string;
  navSupport: string;
  adminPortal: string;

  // Authenticated Home
  masjidHeading: string;
  madrasaName: string;
  madrasaAddress: string;
  madrasaDesc: string;
  madrasaPurposeTitle: string;
  madrasaPurposeDesc: string;
  supportCharityTitle: string;
  supportCharityDesc: string;
  announcementTitle: string;
  quickDonate: string;

  // Wallet
  walletBalance: string;
  addMoney: string;
  donateCharity: string;
  transactionHistory: string;
  securityNoticeTitle: string;
  securityNoticeDesc: string;
  upiPaymentOnly: string;
  upiPaymentNote: string;
  enterAmount: string;
  selectAmount: string;
  submitUpiRef: string;
  upiRefPlaceholder: string;
  paymentPendingNotice: string;
  paymentSubmittedSuccess: string;
  
  // Charity
  monthlyCharityTitle: string;
  monthlyCharitySubtitle: string;
  automaticMonthlyCharity: string;
  monthlyCharityStatus: string;
  amountLabel: string;
  statusOn: string;
  statusOff: string;
  customAmount: string;
  cancelMandate: string;
  savePreference: string;
  autoPayNotice: string;
  donateNowWallet: string;
  insufficientBalance: string;
  donationSuccess: string;

  // History
  historyTitle: string;
  date: string;
  amount: string;
  type: string;
  status: string;
  transactionId: string;
  noTransactions: string;
  statusSuccessful: string;
  statusPending: string;
  statusFailed: string;
  typeMonthlyCharity: string;
  typeOneTimeCharity: string;
  typeSadqah: string;
  typeZakat: string;
  typeLillah: string;
  typeWalletTopup: string;

  // Profile
  profileTitle: string;
  accountCreated: string;
  editProfile: string;
  changePassword: string;
  newPassword: string;
  updateSuccess: string;
  saveChanges: string;

  // Support
  supportTitle: string;
  supportSubtitle: string;
  subject: string;
  message: string;
  submitTicket: string;
  myTickets: string;
  ticketSubmitted: string;
  noTickets: string;
  adminReply: string;

  // Admin
  adminDashboard: string;
  totalUsers: string;
  totalDonations: string;
  totalSuccessfulPayments: string;
  totalCharity: string;
  pendingPayments: string;
  verifyPayment: string;
  rejectPayment: string;
  verified: string;
  rejected: string;

  // Legal
  privacyPolicy: string;
  termsConditions: string;
  refundPolicy: string;
  contactUs: string;
  close: string;
  comingSoon: string;

  // Community Features & Bank
  communityFee: string;
  payMonthlyFee: string;
  feeStatusPaid: string;
  feeStatusDue: string;
  imamSalary: string;
  publicLedger: string;
  myLedger: string;
  anonymousDonor: string;
  donateAnonymously: string;
  bankTransfer: string;
  accountHolder: string;
  accountNumber: string;
  ifscCode: string;
  bankName: string;
  rabiUlAwwal: string;
  mosqueRenovation: string;
  uploadMosquePhoto: string;
  changeMosquePhoto: string;
  adminBankConfig: string;
  saveBankDetails: string;
  savedSuccess: string;
}

export const translations: Record<SupportedLanguage, Translations> = {
  en: {
    appName: "Apna Masjid",
    tagline: "Masjid • Madrasa • Khidmat • Charity",
    bismillah: "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ",
    welcomeIntro: "Digital platform for Masjid and Madrasa support and community welfare.",
    loginSignUp: "Login / Sign Up",
    login: "Login",
    signUp: "Sign Up",
    logout: "Logout",
    email: "Email Address",
    password: "Password",
    confirmPassword: "Confirm Password",
    fullName: "Full Name",
    forgotPassword: "Forgot Password?",
    createNewAccount: "Create New Account",
    alreadyHaveAccount: "Already have an account? Login",
    resetPasswordLink: "Send Password Reset Link",
    sendResetEmail: "Password reset instructions will be sent to your registered email.",
    passwordResetSuccess: "Password reset email sent. Please check your inbox.",

    navHome: "Home",
    navWallet: "Wallet",
    navCharity: "Charity",
    navHistory: "History",
    navProfile: "Profile",
    navSupport: "Support",
    adminPortal: "Admin Portal",

    masjidHeading: "Masjid / Madrasa",
    madrasaName: "MADRASA TEGIYA TALIM AL ISLAM",
    madrasaAddress: "Kamalpura Baradih, Muzaffarpur, Bihar",
    madrasaDesc: "Dedicated to imparting authentic Islamic knowledge, Quranic Hifz, Tajweed, and contemporary primary education with residential boarding facilities for orphan and underprivileged students.",
    madrasaPurposeTitle: "Purpose & Mission",
    madrasaPurposeDesc: "Nurturing pious and capable students, serving community spiritual needs, providing free food and lodging, and maintaining Islamic moral values in society.",
    supportCharityTitle: "Support & Charity Needs",
    supportCharityDesc: "Your generous donations directly support student meals, scholarly honorariums, textbook supplies, clean water, and building maintenance.",
    announcementTitle: "Notice Board & Announcements",
    quickDonate: "Donate Now",

    walletBalance: "Wallet Balance",
    addMoney: "+ Add Money",
    donateCharity: "Donate / Charity",
    transactionHistory: "Transaction History",
    securityNoticeTitle: "Bank-Grade Security Protocol",
    securityNoticeDesc: "Wallet balance cannot be manually edited from frontend code. Only verified bank/webhook confirmations credit your balance.",
    upiPaymentOnly: "UPI Only Payment",
    upiPaymentNote: "UPI is the authorized method for Apna Masjid. Credit and debit cards are not supported.",
    enterAmount: "Enter Amount (₹)",
    selectAmount: "Or Select Preset Amount:",
    submitUpiRef: "Submit UPI UTR / Reference ID",
    upiRefPlaceholder: "e.g. 423871928371 (12-digit UPI UTR)",
    paymentPendingNotice: "Your payment request is queued for banking verification. Balance updates securely once confirmed by administration.",
    paymentSubmittedSuccess: "UPI payment request logged. Status: Pending Verification.",

    monthlyCharityTitle: "Monthly Charity",
    monthlyCharitySubtitle: "Set up regular ongoing Sadaqah & support for the Madrasa",
    automaticMonthlyCharity: "Automatic Monthly Charity",
    monthlyCharityStatus: "Monthly Charity",
    amountLabel: "Amount",
    statusOn: "ON",
    statusOff: "OFF",
    customAmount: "Custom Amount",
    cancelMandate: "Disable Recurring Charity",
    savePreference: "Save Preference",
    autoPayNotice: "Real recurring charity uses authorized UPI AutoPay mandate with backend scheduled verification.",
    donateNowWallet: "Contribute from Wallet",
    insufficientBalance: "Insufficient wallet balance. Please add money via UPI first.",
    donationSuccess: "Jazakallah Khair! Your charity contribution has been received.",

    historyTitle: "Charity & Transaction History",
    date: "Date",
    amount: "Amount",
    type: "Type",
    status: "Status",
    transactionId: "Transaction ID",
    noTransactions: "No records found yet.",
    statusSuccessful: "Successful",
    statusPending: "Pending",
    statusFailed: "Failed",
    typeMonthlyCharity: "Monthly Charity",
    typeOneTimeCharity: "One-Time Charity",
    typeSadqah: "Sadaqah",
    typeZakat: "Zakat",
    typeLillah: "Lillah",
    typeWalletTopup: "Wallet Top-up",

    profileTitle: "User Profile",
    accountCreated: "Member Since",
    editProfile: "Edit Profile",
    changePassword: "Change Password",
    newPassword: "New Password",
    updateSuccess: "Profile updated successfully.",
    saveChanges: "Save Changes",

    supportTitle: "Support Helpdesk",
    supportSubtitle: "Need assistance with transactions or donations? Send us a message.",
    subject: "Subject",
    message: "Message",
    submitTicket: "Submit Support Ticket",
    myTickets: "My Support Queries",
    ticketSubmitted: "Your query has been logged. Our administration will review it.",
    noTickets: "No support tickets submitted yet.",
    adminReply: "Admin Response",

    adminDashboard: "Secure Admin Dashboard",
    totalUsers: "Total Users",
    totalDonations: "Total Donations",
    totalSuccessfulPayments: "Verified Payments",
    totalCharity: "Total Charity (₹)",
    pendingPayments: "Pending Payments",
    verifyPayment: "Verify & Credit",
    rejectPayment: "Reject",
    verified: "Verified",
    rejected: "Rejected",

    privacyPolicy: "Privacy Policy",
    termsConditions: "Terms & Conditions",
    refundPolicy: "Donation & Refund Policy",
    contactUs: "Contact Us",
    close: "Close",
    comingSoon: "Feature in development / Coming Soon",

    communityFee: "Monthly Mosque & Imam Fee",
    payMonthlyFee: "Pay Monthly Community Fee",
    feeStatusPaid: "Paid for this month",
    feeStatusDue: "Monthly Fee Due",
    imamSalary: "Imam Salary & Maintenance",
    publicLedger: "Community Transparency Ledger",
    myLedger: "My Private History",
    anonymousDonor: "Anonymous Well-Wisher",
    donateAnonymously: "Keep my name anonymous in public ledger",
    bankTransfer: "Direct Admin Bank Account",
    accountHolder: "Account Holder",
    accountNumber: "Bank Account Number",
    ifscCode: "IFSC Code",
    bankName: "Bank Name",
    rabiUlAwwal: "12 Rabi-ul-Awwal Appeal",
    mosqueRenovation: "Mosque Renovation & Repair",
    uploadMosquePhoto: "Upload Mosque Photo",
    changeMosquePhoto: "Change Mosque Photo",
    adminBankConfig: "Admin Bank & UPI Setup",
    saveBankDetails: "Save Bank Details",
    savedSuccess: "Saved successfully!"
  },
  hi: {
    appName: "अपना मस्जिद",
    tagline: "मस्जिद • मदरसा • खिदमत • खैरात",
    bismillah: "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ",
    welcomeIntro: "मस्जिद और मदरसे के लिए डिजिटल प्लेटफॉर्म।",
    loginSignUp: "लॉगिन / साइन अप",
    login: "लॉगिन करें",
    signUp: "साइन अप करें",
    logout: "लॉगआउट",
    email: "ईमेल पता",
    password: "पासवर्ड",
    confirmPassword: "पासवर्ड की पुष्टि करें",
    fullName: "पूरा नाम",
    forgotPassword: "पासवर्ड भूल गए?",
    createNewAccount: "नया खाता बनाएं",
    alreadyHaveAccount: "पहले से खाता है? लॉगिन करें",
    resetPasswordLink: "पासवर्ड रीसेट लिंक भेजें",
    sendResetEmail: "आपके पंजीकृत ईमेल पर पासवर्ड रीसेट लिंक भेजा जाएगा।",
    passwordResetSuccess: "पासवर्ड रीसेट ईमेल भेज दिया गया है। कृपया अपना इनबॉक्स देखें।",

    navHome: "होम",
    navWallet: "वॉलेट",
    navCharity: "दान / खैरात",
    navHistory: "इतिहास",
    navProfile: "प्रोफ़ाइल",
    navSupport: "सहायता",
    adminPortal: "एडमिन पोर्टल",

    masjidHeading: "मस्जिद / मदरसा विवरण",
    madrasaName: "मदरसा तेगिया तालीम अल इस्लाम",
    madrasaAddress: "कमलपुरा बरडीह, मुजफ्फरपुर, बिहार",
    madrasaDesc: "इस्लामी तालीम, हिफ़्ज़-ए-कुरआन, दीनियात और अनाथ व ज़रूरतमंद बच्चों के लिए मुफ़्त शिक्षा व आवासीय व्यवस्था को समर्पित संस्थान।",
    madrasaPurposeTitle: "मकसद और उद्देश्य",
    madrasaPurposeDesc: "दीनी और दुनियावी तालीम, समाज सुधार, तालिब-ए-इल्मों के लिए भोजन-आवास और नैतिक मूल्यों की रक्षा।",
    supportCharityTitle: "इमदाद और खैरात की आवश्यकता",
    supportCharityDesc: "आपका दिया हुआ दान सीधे छात्रों के भोजन, किताबों, शिक्षकों के मानदेय और मदरसे की मरम्मत में काम आता है।",
    announcementTitle: "सूचना पट्ट एवं घोषणाएं",
    quickDonate: "दान करें",

    walletBalance: "वॉलेट बैलेंस",
    addMoney: "+ पैसे जोड़ें",
    donateCharity: "दान / खैरात",
    transactionHistory: "लेनदेन इतिहास",
    securityNoticeTitle: "सुरक्षा दिशानिर्देश",
    securityNoticeDesc: "वॉलेट बैलेंस को फ्रंटएंड से नहीं बदला जा सकता। केवल सत्यापित बैंक प्रक्रिया से ही राशि जुड़ती है।",
    upiPaymentOnly: "केवल UPI भुगतान",
    upiPaymentNote: "क्रेडिट या डेबिट कार्ड समर्थित नहीं हैं। केवल अधिकृत UPI से भुगतान करें।",
    enterAmount: "राशि दर्ज करें (₹)",
    selectAmount: "राशि चुनें:",
    submitUpiRef: "UPI UTR / संदर्भ संख्या दर्ज करें",
    upiRefPlaceholder: "उदाहरण: 423871928371 (12-अंक UPI UTR)",
    paymentPendingNotice: "आपका भुगतान सत्यापन के लिए दर्ज किया गया है। एडमिन द्वारा सत्यापित होने पर बैलेंस जुड़ेगा।",
    paymentSubmittedSuccess: "UPI भुगतान अनुरोध दर्ज किया गया। स्थिति: सत्यापन लंबित।",

    monthlyCharityTitle: "मासिक खैरात",
    monthlyCharitySubtitle: "मदरसे के लिए निरंतर सदक़ा और सहयोग स्थापित करें",
    automaticMonthlyCharity: "स्वचालित मासिक खैरात",
    monthlyCharityStatus: "मासिक खैरात",
    amountLabel: "राशि",
    statusOn: "चालू (ON)",
    statusOff: "बंद (OFF)",
    customAmount: "अन्य राशि",
    cancelMandate: "मासिक खैरात बंद करें",
    savePreference: "सेटिंग सहेजें",
    autoPayNotice: "वास्तविक आवर्ती दान यूपीआई ऑटोपे मैंडेट द्वारा सुरक्षित रूप से संसाधित होता है।",
    donateNowWallet: "वॉलेट से दान करें",
    insufficientBalance: "वॉलेट में अपर्याप्त राशि है। कृपया पहले UPI से राशि जोड़ें।",
    donationSuccess: "जज़ाकल्लाह ख़ैर! आपका दान सफलतापूर्वक प्राप्त हुआ।",

    historyTitle: "दान एवं लेनदेन इतिहास",
    date: "दिनांक",
    amount: "राशि",
    type: "प्रकार",
    status: "स्थिति",
    transactionId: "ट्रांजेक्शन आईडी",
    noTransactions: "कोई लेनदेन नहीं मिला।",
    statusSuccessful: "सफल",
    statusPending: "लंबित",
    statusFailed: "विफल",
    typeMonthlyCharity: "मासिक खैरात",
    typeOneTimeCharity: "एकमुश्त दान",
    typeSadqah: "सदक़ा",
    typeZakat: "ज़कात",
    typeLillah: "लिल्लाह",
    typeWalletTopup: "वॉलेट टॉप-अप",

    profileTitle: "उपयोगकर्ता प्रोफ़ाइल",
    accountCreated: "सदस्य बने",
    editProfile: "प्रोफ़ाइल संपादित करें",
    changePassword: "पासवर्ड बदलें",
    newPassword: "नया पासवर्ड",
    updateSuccess: "प्रोफ़ाइल सफलतापूर्वक अपडेट की गई।",
    saveChanges: "बदलाव सहेजें",

    supportTitle: "सहायता केंद्र",
    supportSubtitle: "भुगतान या दान से संबंधित कोई प्रश्न है? हमें संदेश भेजें।",
    subject: "विषय",
    message: "संदेश",
    submitTicket: "टिकट भेजें",
    myTickets: "मेरी शिकायतें / संदेश",
    ticketSubmitted: "आपका संदेश दर्ज हो गया है। एडमिन जल्द उत्तर देगा।",
    noTickets: "कोई सहायता संदेश नहीं भेजा गया है।",
    adminReply: "एडमिन का जवाब",

    adminDashboard: "सुरक्षित एडमिन डैशबोर्ड",
    totalUsers: "कुल उपयोगकर्ता",
    totalDonations: "कुल दान",
    totalSuccessfulPayments: "सत्यापित भुगतान",
    totalCharity: "कुल खैरात (₹)",
    pendingPayments: "लंबित भुगतान",
    verifyPayment: "सत्यापित करें और जोड़ें",
    rejectPayment: "अस्वीकार करें",
    verified: "सत्यापित",
    rejected: "अस्वीकृत",

    privacyPolicy: "गोपनीयता नीति",
    termsConditions: "नियम व शर्तें",
    refundPolicy: "दान एवं धनवापसी नीति",
    contactUs: "संपर्क करें",
    close: "बंद करें",
    comingSoon: "जल्द आ रहा है (Coming Soon)",

    communityFee: "मासिक कम्युनिटी फीस (इमाम साहब तनख्वाह व मेंटेनेंस)",
    payMonthlyFee: "मासिक फीस जमा करें",
    feeStatusPaid: "इस महीने की फीस जमा है",
    feeStatusDue: "माहवारी फीस बकाया है",
    imamSalary: "इमाम साहब की तनख्वाह व मेंटेनेंस",
    publicLedger: "सार्वजनिक चंदा लेजर (सभी का हिसाब)",
    myLedger: "मेरा व्यक्तिगत इतिहास",
    anonymousDonor: "गुप्त दान (ख़िदमतगार)",
    donateAnonymously: "सार्वजनिक लेजर में मेरा नाम गुप्त रखें",
    bankTransfer: "एडमिन का सीधा बैंक खाता",
    accountHolder: "खाताधारक का नाम",
    accountNumber: "बैंक खाता संख्या",
    ifscCode: "IFSC कोड",
    bankName: "बैंक का नाम",
    rabiUlAwwal: "12 रबी-उल-अव्वल चंदा अपील",
    mosqueRenovation: "मस्जिद मरम्मत एवं निर्माण",
    uploadMosquePhoto: "मस्जिद की फोटो अपलोड करें",
    changeMosquePhoto: "मस्जिद की फोटो बदलें",
    adminBankConfig: "एडमिन बैंक व UPI खाता विवरण",
    saveBankDetails: "बैंक विवरण सुरक्षित करें",
    savedSuccess: "सफलतापूर्वक सुरक्षित किया गया!"
  },
  ur: {
    appName: "اپنا مسجد",
    tagline: "مسجد • مدرسہ • خدمت • خیرات",
    bismillah: "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ",
    welcomeIntro: "مسجد اور مدرسہ کے لیے ڈیجیٹل پلیٹ فارم۔",
    loginSignUp: "لاگ ان / سائن اپ",
    login: "لاگ ان کریں",
    signUp: "سائن اپ کریں",
    logout: "لاگ آؤٹ",
    email: "ای میل ایڈریس",
    password: "پاس ورڈ",
    confirmPassword: "پاس ورڈ کی تصدیق کریں",
    fullName: "پورا نام",
    forgotPassword: "پاس ورڈ بھول گئے؟",
    createNewAccount: "نیا اکاؤنٹ بنائیں",
    alreadyHaveAccount: "پہلے سے اکاؤنٹ ہے؟ لاگ ان کریں",
    resetPasswordLink: "پاس ورڈ ری سیٹ لنک بھیجیں",
    sendResetEmail: "آپ کے رجسٹرڈ ای میل پر پاس ورڈ ری سیٹ لنک بھیجا جائے گا۔",
    passwordResetSuccess: "پاس ورڈ ری سیٹ لنک بھیج دیا گیا ہے۔ برائے مہربانی اپنا ان باکس دیکھیں۔",

    navHome: "ہوم",
    navWallet: "والیٹ",
    navCharity: "خیرات",
    navHistory: "تاریخ",
    navProfile: "پروفائل",
    navSupport: "مدد / رابطہ",
    adminPortal: "ایڈمن پورٹل",

    masjidHeading: "مسجد / مدرسہ تفصیلات",
    madrasaName: "مدرسہ تیغیہ تعلیم الاسلام",
    madrasaAddress: "کمل پورا بردیہہ، مظفرپور، بہار",
    madrasaDesc: "دینی تعلیم، حفظ قرآن پاک، تجوید اور یتیم و نادار طلباء کے لیے رہائشی اور تعلیمی انتظامات کے لیے وقف ادارہ۔",
    madrasaPurposeTitle: "مقاصد اور خدمات",
    madrasaPurposeDesc: "صالح نسل کی تربیت، دینی بیداری، طلباء کے لیے قیام و طعام اور معاشرتی فلاح۔",
    supportCharityTitle: "امداد اور تعاون کی ضرورت",
    supportCharityDesc: "آپ کا دیا ہوا عطیہ طلباء کے طعام، کتب، اساتذہ کے مشاہرے اور مدرسہ کی تعمیر و ترقی میں صرف ہوتا ہے۔",
    announcementTitle: "اعلانات و اطلاعات",
    quickDonate: "عطیہ دیں",

    walletBalance: "والیٹ بیلنس",
    addMoney: "+ رقم شامل کریں",
    donateCharity: "عطیہ / خیرات",
    transactionHistory: "لین دین کی تاریخ",
    securityNoticeTitle: "سیکیورٹی ضابطہ",
    securityNoticeDesc: "والیٹ بیلنس براہ راست تبدیل نہیں کیا جا سکتا۔ صرف تصدیق شدہ ادائیگی کے بعد ہی بیلنس میں اضافہ ہوتا ہے۔",
    upiPaymentOnly: "صرف UPI ادائیگی",
    upiPaymentNote: "کریڈٹ یا ڈیبٹ کارڈ کی سہولت موجود نہیں۔ صرف منظور شدہ UPI سے ادائیگی کریں۔",
    enterAmount: "رقم درج کریں (₹)",
    selectAmount: "رقم منتخب کریں:",
    submitUpiRef: "UPI ریفرنس / UTR نمبر درج کریں",
    upiRefPlaceholder: "مثال: 423871928371",
    paymentPendingNotice: "آپ کی ادائیگی تصدیق کے انتظار میں ہے۔ انتظامیہ کی تصدیق کے بعد والیٹ میں شامل ہوگی۔",
    paymentSubmittedSuccess: "ادائیگی کی درخواست جمع ہو گئی۔ حیثیت: تصدیق کا انتظار۔",

    monthlyCharityTitle: "ماہانہ خیرات",
    monthlyCharitySubtitle: "مدرسہ کے لیے باقاعدہ ماہانہ صدقہ مقرر کریں",
    automaticMonthlyCharity: "خودکار ماہانہ خیرات",
    monthlyCharityStatus: "ماہانہ خیرات",
    amountLabel: "رقم",
    statusOn: "چالو (ON)",
    statusOff: "بند (OFF)",
    customAmount: "دیگر رقم",
    cancelMandate: "ماہانہ خیرات منسوخ کریں",
    savePreference: "ترجیحات محفوظ کریں",
    autoPayNotice: "ماہانہ کٹوتی محفوظ UPI آٹو پے کے ذریعے باقاعدہ طریقہ کار سے عمل میں آتی ہے۔",
    donateNowWallet: "والیٹ سے عطیہ دیں",
    insufficientBalance: "والیٹ میں بیلنس ناکافی ہے۔ برائے مہربانی پہلے UPI سے رقم شامل کریں۔",
    donationSuccess: "جزاک اللہ خیراً! آپ کا عطیہ موصول ہو گیا۔",

    historyTitle: "خیرات و لین دین کی تاریخ",
    date: "تاریخ",
    amount: "رقم",
    type: "قسم",
    status: "حیثیت",
    transactionId: "ٹرانزیکشن آئی ڈی",
    noTransactions: "کوئی ریکارڈ موجود نہیں۔",
    statusSuccessful: "کامیاب",
    statusPending: "زیر التواء",
    statusFailed: "ناکام",
    typeMonthlyCharity: "ماہانہ خیرات",
    typeOneTimeCharity: "یک وقتی عطیہ",
    typeSadqah: "صدقہ",
    typeZakat: "زکوٰۃ",
    typeLillah: "للہ",
    typeWalletTopup: "والیٹ ٹاپ اپ",

    profileTitle: "صارف پروفائل",
    accountCreated: "رکنیت کی تاریخ",
    editProfile: "پروفائل تبدیل کریں",
    changePassword: "پاس ورڈ تبدیل کریں",
    newPassword: "نیا پاس ورڈ",
    updateSuccess: "پروفائل کامیابی سے اپ ڈیٹ ہو گئی۔",
    saveChanges: "تبدیلیاں محفوظ کریں",

    supportTitle: "مدد و شکایات ڈیسک",
    supportSubtitle: "ادائیگی یا تعاون سے متعلق کوئی سوال ہو تو پیغام ارسال کریں۔",
    subject: "عنوان",
    message: "پیغام",
    submitTicket: "پیغام بھیجیں",
    myTickets: "میرے پیغامات",
    ticketSubmitted: "آپ کا پیغام موصول ہو گیا۔ انتظامیہ جلد جواب دے گی۔",
    noTickets: "کوئی پیغام درج نہیں۔",
    adminReply: "ایڈمن کا جواب",

    adminDashboard: "ایڈمن ڈیش بورڈ",
    totalUsers: "کل صارفین",
    totalDonations: "کل عطیات",
    totalSuccessfulPayments: "تصدیق شدہ ادائیگیاں",
    totalCharity: "کل خیرات (₹)",
    pendingPayments: "زیر التواء ادائیگیاں",
    verifyPayment: "تصدیق اور والیٹ کریڈٹ",
    rejectPayment: "مسترد کریں",
    verified: "تصدیق شدہ",
    rejected: "مسترد",

    privacyPolicy: "رازداری کی پالیسی",
    termsConditions: "شرائط و ضوابط",
    refundPolicy: "عطیات اور رقم واپسی کی پالیسی",
    contactUs: "رابطہ کریں",
    close: "بند کریں",
    comingSoon: "عنقریب دستیاب ہوگی (Coming Soon)",

    communityFee: "ماہانہ کمیونٹی فیس (امام صاحب تنخواہ و مسجد خرچ)",
    payMonthlyFee: "ماہانہ فیس ادا کریں",
    feeStatusPaid: "اس ماہ کی فیس ادا ہو چکی ہے",
    feeStatusDue: "ماہانہ فیس واجب الادا ہے",
    imamSalary: "امام صاحب کی تنخواہ و دیکھ بھال",
    publicLedger: "عوامی عطیات لیجر (سب کا حساب)",
    myLedger: "میری ذاتی ہسٹری",
    anonymousDonor: "گمنام خدمت گار",
    donateAnonymously: "عوامی لیجر میں میرا نام پوشیدہ رکھیں",
    bankTransfer: "ایڈمن کا براہ راست بینک اکاؤنٹ",
    accountHolder: "کھاتہ دار کا نام",
    accountNumber: "بینک اکاؤنٹ نمبر",
    ifscCode: "IFSC کوڈ",
    bankName: "بینک کا نام",
    rabiUlAwwal: "12 ربیع الاول چندہ مہم",
    mosqueRenovation: "مسجد تعمیر و مرمت",
    uploadMosquePhoto: "مسجد کی تصویر اپ لوڈ کریں",
    changeMosquePhoto: "تصویر تبدیل کریں",
    adminBankConfig: "ایڈمن بینک اور یو پی آئی سیٹ اپ",
    saveBankDetails: "بینک تفصیلات محفوظ کریں",
    savedSuccess: "کامیابی سے محفوظ ہو گیا!"
  },
  ar: {
    appName: "مسجدنا",
    tagline: "مسجد • مدرسة • خدمة • صدقة",
    bismillah: "بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ",
    welcomeIntro: "منصة رقمية خاصة لدعم المسجد والمدرسة والعمل الخيري.",
    loginSignUp: "تسجيل الدخول / إنشاء حساب",
    login: "تسجيل الدخول",
    signUp: "إنشاء حساب",
    logout: "تسجيل الخروج",
    email: "البريد الإلكتروني",
    password: "كلمة المرور",
    confirmPassword: "تأكيد كلمة المرور",
    fullName: "الاسم الكامل",
    forgotPassword: "نسيت كلمة المرور؟",
    createNewAccount: "إنشاء حساب جديد",
    alreadyHaveAccount: "هل لديك حساب بالفعل؟ تسجيل الدخول",
    resetPasswordLink: "إرسال رابط إعادة الضبط",
    sendResetEmail: "سيتم إرسال تعليمات إعادة ضبط كلمة المرور إلى بريدك الإلكتروني المسجل.",
    passwordResetSuccess: "تم إرسال رابط إعادة الضبط إلى بريدك الإلكتروني.",

    navHome: "الرئيسية",
    navWallet: "المحفظة",
    navCharity: "الصدقات",
    navHistory: "السجل",
    navProfile: "الملف الشخصي",
    navSupport: "الدعم والمساعدة",
    adminPortal: "لوحة الإدارة",

    masjidHeading: "المسجد / المدرسة",
    madrasaName: "مدرسة تيغية تعليم الإسلام",
    madrasaAddress: "كمال بورا باراديه، مظفربور، بيهار، الهند",
    madrasaDesc: "مؤسسة مكرسة لتعليم العلوم الشرعية، وحفظ القرآن الكريم بالتجويد، والتعليم الإنساني مع توفير الإقامة والإعاشة للطلاب الأيتام والفقراء.",
    madrasaPurposeTitle: "الأهداف والرسالة",
    madrasaPurposeDesc: "تربية جيل مسلم صالح، وتوفير الخدمات الدينية والاجتماعية، وتأمين طعام ومأوى للطلاب المحتاجين.",
    supportCharityTitle: "احتياجات الدعم والتبرعات",
    supportCharityDesc: "تبرعاتكم الكريمة تذهب مباشرة لتغطية وجبات الطلاب، والكتب الدراسية، ومكافآت المعلمين، وصيانة مرافق المدرسة.",
    announcementTitle: "لوحة الإعلانات والأخبار",
    quickDonate: "تبرع الآن",

    walletBalance: "رصيد المحفظة",
    addMoney: "+ شحن الرصيد",
    donateCharity: "تبرع / صدقة",
    transactionHistory: "سجل المعاملات",
    securityNoticeTitle: "بروتوكول الأمان المالي",
    securityNoticeDesc: "لا يمكن تعديل رصيد المحفظة من واجهة المستخدم. الإيداع يتم فقط بعد التحقق البنكي المعتمد.",
    upiPaymentOnly: "الدفع عبر UPI فقط",
    upiPaymentNote: "نظام UPI هو المعتمد لمنصة مسجدنا. بطاقات الائتمان غير مدعومة.",
    enterAmount: "أدخل المبلغ (₹)",
    selectAmount: "أو اختر مبلغاً محدداً:",
    submitUpiRef: "إرسال رقم مرجع UPI (UTR)",
    upiRefPlaceholder: "مثال: 423871928371",
    paymentPendingNotice: "تم تسجيل طلب الدفع بانتظار التحقق البنكي من قبل الإدارة.",
    paymentSubmittedSuccess: "تم إرسال طلب الدفع بنجاح. الحالة: قيد المراجعة.",

    monthlyCharityTitle: "الصدقة الشهرية",
    monthlyCharitySubtitle: "خصص صدقة جارية شهرية لدعم المدرسة وطلاب العلم",
    automaticMonthlyCharity: "الصدقة الشهرية التلقائية",
    monthlyCharityStatus: "الصدقة الشهرية",
    amountLabel: "المبلغ",
    statusOn: "مفعل (ON)",
    statusOff: "متوقف (OFF)",
    customAmount: "مبلغ مخصص",
    cancelMandate: "إلغاء الصدقة الدورية",
    savePreference: "حفظ الإعدادات",
    autoPayNotice: "الخصم الدوري الحقيقي يتم عبر تفويض UPI AutoPay المعتمد.",
    donateNowWallet: "التبرع من رصيد المحفظة",
    insufficientBalance: "رصيد المحفظة غير كافٍ. يرجى شحن الرصيد أولاً عبر UPI.",
    donationSuccess: "جزاكم الله خيراً! تم استلام تبرعكم المبارك.",

    historyTitle: "سجل الصدقات والمعاملات",
    date: "التاريخ",
    amount: "المبلغ",
    type: "النوع",
    status: "الحالة",
    transactionId: "رقم المعاملة",
    noTransactions: "لا توجد سجلات حالياً.",
    statusSuccessful: "ناجحة",
    statusPending: "قيد الانتظار",
    statusFailed: "فاشلة",
    typeMonthlyCharity: "صدقة شهرية",
    typeOneTimeCharity: "تبرع لمرة واحدة",
    typeSadqah: "صدقة",
    typeZakat: "زكاة",
    typeLillah: "لله",
    typeWalletTopup: "شحن المحفظة",

    profileTitle: "الملف الشخصي",
    accountCreated: "تاريخ الانضمام",
    editProfile: "تعديل الملف الشخصي",
    changePassword: "تغيير كلمة المرور",
    newPassword: "كلمة المرور الجديدة",
    updateSuccess: "تم تحديث الملف الشخصي بنجاح.",
    saveChanges: "حفظ التغييرات",

    supportTitle: "مكتب الدعم والمساعدة",
    supportSubtitle: "هل لديك استفسار حول التبرعات أو المعاملات؟ تواصل معنا مباشرة.",
    subject: "الموضوع",
    message: "نص الرسالة",
    submitTicket: "إرسال التذكرة",
    myTickets: "تذاكري السابقة",
    ticketSubmitted: "تم استلام رسالتك، وسيقوم فريق الإدارة بالرد قريباً.",
    noTickets: "لم تقم بإرسال أي تذاكر دعم بعد.",
    adminReply: "رد الإدارة",

    adminDashboard: "لوحة التحكم الإدارية",
    totalUsers: "إجمالي المستخدمين",
    totalDonations: "إجمالي التبرعات",
    totalSuccessfulPayments: "المدفوعات المؤكدة",
    totalCharity: "إجمالي الصدقات (₹)",
    pendingPayments: "المدفوعات المعلقة",
    verifyPayment: "تأكيد وإيداع",
    rejectPayment: "رفض",
    verified: "مؤكد",
    rejected: "مرفوض",

    privacyPolicy: "سياسة الخصوصية",
    termsConditions: "الشروط والأحكام",
    refundPolicy: "سياسة التبرع والاسترداد",
    contactUs: "اتصل بنا",
    close: "إغلاق",
    comingSoon: "هذه الميزة قيد التطوير / قريباً",

    communityFee: "الاشتراك الشهري لدعم المسجد وراتب الإمام",
    payMonthlyFee: "سداد الرسوم الشهرية للمسجد",
    feeStatusPaid: "تم سداد اشتراك هذا الشهر",
    feeStatusDue: "الاشتراك الشهري مستحق",
    imamSalary: "راتب الإمام وصيانة المسجد",
    publicLedger: "سجل التبرعات العام الشفاف",
    myLedger: "سجل تبرعاتي الخاص",
    anonymousDonor: "فاعل خير (فاعل خير)",
    donateAnonymously: "إخفاء اسمي في السجل العام الشفاف",
    bankTransfer: "الحساب البنكي الرسمي المباشر للإدارة",
    accountHolder: "اسم صاحب الحساب",
    accountNumber: "رقم الحساب البنكي",
    ifscCode: "رمز IFSC",
    bankName: "اسم البنك",
    rabiUlAwwal: "حملة تبرعات 12 ربيع الأول",
    mosqueRenovation: "ترميم وصيانة المسجد",
    uploadMosquePhoto: "رفع صورة المسجد",
    changeMosquePhoto: "تغيير صورة المسجد",
    adminBankConfig: "إعدادات الحساب البنكي و UPI للإدارة",
    saveBankDetails: "حفظ البيانات البنكية",
    savedSuccess: "تم الحفظ بنجاح!"
  }
};

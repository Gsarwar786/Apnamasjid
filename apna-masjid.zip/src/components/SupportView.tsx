import React, { useState } from 'react';
import { collection, addDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { UserProfile, SupportTicket, SupportedLanguage, MasjidDetails } from '../types';
import { translations } from '../i18n';
import {
  Headphones,
  Send,
  Clock,
  CheckCircle2,
  AlertCircle,
  MessageSquare,
  Loader2,
  Phone,
  Mail,
  ShieldCheck,
  Building,
  ExternalLink,
} from 'lucide-react';

interface SupportViewProps {
  userProfile: UserProfile | null;
  supportTickets: SupportTicket[];
  masjidDetails?: MasjidDetails;
  currentLang: SupportedLanguage;
}

export const SupportView: React.FC<SupportViewProps> = ({
  userProfile,
  supportTickets,
  masjidDetails,
  currentLang,
}) => {
  const t = translations[currentLang];
  const isRtl = currentLang === 'ur' || currentLang === 'ar';

  const [subject, setSubject] = useState('');
  const [messageText, setMessageText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [notice, setNotice] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const adminName = masjidDetails?.adminName || 'Hafez Md. Rizwan (मुतवल्ली / व्यवस्थापक)';
  const adminPhone = masjidDetails?.adminPhone || masjidDetails?.contact || '+91 9876543210';
  const adminWhatsapp = masjidDetails?.adminWhatsapp || masjidDetails?.contact || '+91 9876543210';
  const adminEmail = masjidDetails?.adminEmail || 'rockybo09876@gmail.com';
  const adminSupportTiming = masjidDetails?.adminSupportTiming || 'सुबह 8:00 AM से रात 9:00 PM (जुमा को 2:00 PM के बाद)';

  const cleanWhatsappNumber = adminWhatsapp.replace(/[^0-9]/g, '');

  const handleSubmitSupport = async (e: React.FormEvent) => {
    e.preventDefault();
    setNotice(null);

    if (!userProfile) return;

    const cleanSubject = subject.trim();
    const cleanMessage = messageText.trim();

    if (!cleanSubject || !cleanMessage) {
      setNotice({ type: 'error', text: 'Please provide both subject and message details.' });
      return;
    }

    try {
      setSubmitting(true);
      await addDoc(collection(db, 'supportMessages'), {
        uid: userProfile.uid,
        userEmail: userProfile.email,
        userName: userProfile.name,
        subject: cleanSubject,
        message: cleanMessage,
        status: 'Open',
        createdAt: new Date().toISOString(),
      });

      setNotice({ type: 'success', text: t.ticketSubmitted });
      setSubject('');
      setMessageText('');
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'supportMessages');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8 max-w-2xl mx-auto" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* DIRECT ADMIN CONTACT CARD */}
      <div className="bg-gradient-to-br from-emerald-900 via-emerald-950 to-slate-950 rounded-3xl p-6 sm:p-7 text-white shadow-lg border border-emerald-800 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-400 text-amber-950 font-black text-[10px] uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5 text-amber-950" />
              <span>आधिकारिक व्यवस्थापक हेल्पलाइन</span>
            </div>
            <h3 className="text-lg sm:text-xl font-black text-white mt-1">
              {adminName}
            </h3>
            <p className="text-xs text-emerald-200/90 flex items-center gap-1">
              <Building className="w-3.5 h-3.5 text-emerald-400" />
              <span>{masjidDetails?.name || 'Madrasa Tegiya Talim Al Islam'}</span>
            </p>
          </div>
        </div>

        {/* Quick Action Buttons (Call & WhatsApp) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
          <a
            href={`tel:${adminPhone}`}
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all"
          >
            <Phone className="w-4 h-4" />
            <span>सीधे कॉल करें: {adminPhone}</span>
          </a>

          <a
            href={`https://wa.me/${cleanWhatsappNumber}?text=${encodeURIComponent(
              `अस्सलाम वालेकुम, मैं अपना मस्जिद ऐप से संपर्क कर रहा हूँ। मेरा नाम: ${
                userProfile?.name || 'सदस्य'
              }`
            )}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 active:bg-emerald-600 text-emerald-950 font-black text-xs shadow-md transition-all"
          >
            <MessageSquare className="w-4 h-4" />
            <span>व्हाट्सएप पर बात करें</span>
          </a>
        </div>

        {/* Support details grid */}
        <div className="pt-3 border-t border-emerald-800/80 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="flex items-center gap-2 text-emerald-200/90">
            <Mail className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="truncate">
              ईमेल: <a href={`mailto:${adminEmail}`} className="underline hover:text-white">{adminEmail}</a>
            </span>
          </div>

          <div className="flex items-center gap-2 text-emerald-200/90">
            <Clock className="w-4 h-4 text-amber-400 shrink-0" />
            <span>समय: {adminSupportTiming}</span>
          </div>
        </div>
      </div>

      {/* Support Form Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-emerald-100">
        <div className="flex items-center gap-2.5 mb-1">
          <div className="p-2 rounded-xl bg-emerald-50 text-emerald-800">
            <Headphones className="w-5 h-5" />
          </div>
          <h2 className="text-xl font-bold text-emerald-950">{t.supportTitle}</h2>
        </div>
        <p className="text-xs text-slate-500 mb-6">
          यदि आपको वॉलेट टॉप-अप, पेमेंट वेरिफिकेशन, या चंदे में कोई समस्या है, तो नीचे विवरण लिखें। एडमिन टीम शीघ्र समाधान करेगी।
        </p>

        {notice && (
          <div
            className={`mb-5 p-3.5 rounded-xl text-xs flex items-center gap-2 ${
              notice.type === 'success'
                ? 'bg-emerald-50 border border-emerald-200 text-emerald-900'
                : 'bg-red-50 border border-red-200 text-red-900'
            }`}
          >
            {notice.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            )}
            <span>{notice.text}</span>
          </div>
        )}

        <form onSubmit={handleSubmitSupport} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">{t.subject}</label>
            <input
              id="support-subject-input"
              type="text"
              required
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="e.g. My payment has not been credited"
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">{t.message}</label>
            <textarea
              id="support-message-input"
              required
              rows={4}
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              placeholder="Please provide details (amount, UPI UTR number, date) so we can verify promptly..."
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
            />
          </div>

          <button
            id="support-submit-btn"
            type="submit"
            disabled={submitting}
            className="w-full sm:w-auto py-2.5 px-6 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold text-xs shadow-md shadow-emerald-700/20 transition-all flex items-center justify-center gap-2 disabled:opacity-60"
          >
            {submitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Submitting...</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>{t.submitTicket}</span>
              </>
            )}
          </button>
        </form>
      </div>

      {/* User's Previous Support Messages */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <MessageSquare className="w-4 h-4 text-emerald-700" />
          <h3 className="font-bold text-sm text-slate-900">{t.myTickets}</h3>
        </div>

        {supportTickets.length === 0 ? (
          <p className="text-center py-6 text-slate-400 text-xs">{t.noTickets}</p>
        ) : (
          <div className="space-y-3">
            {supportTickets.map((ticket) => {
              const statusColors: Record<string, string> = {
                Open: 'bg-amber-100 text-amber-900 border-amber-200',
                'In Progress': 'bg-blue-100 text-blue-900 border-blue-200',
                Resolved: 'bg-emerald-100 text-emerald-900 border-emerald-200',
              };

              return (
                <div
                  key={ticket.id}
                  className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2"
                >
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="font-bold text-xs sm:text-sm text-slate-900">{ticket.subject}</h4>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                        statusColors[ticket.status] || 'bg-slate-200 text-slate-700'
                      }`}
                    >
                      {ticket.status}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">{ticket.message}</p>

                  <div className="text-[10px] text-slate-400 flex items-center gap-1 pt-1">
                    <Clock className="w-3 h-3" />
                    <span>{ticket.createdAt ? new Date(ticket.createdAt).toLocaleString() : 'Recent'}</span>
                  </div>

                  {ticket.reply && (
                    <div className="mt-2 p-3 rounded-xl bg-emerald-50/80 border border-emerald-200 text-xs">
                      <span className="font-bold text-emerald-900 block mb-0.5">{t.adminReply}:</span>
                      <p className="text-emerald-800">{ticket.reply}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

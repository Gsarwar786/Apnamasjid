import React, { useState } from 'react';
import { doc, collection, addDoc, runTransaction } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { UserProfile, SupportedLanguage, MasjidDetails } from '../types';
import { translations } from '../i18n';
import {
  Heart,
  Calendar,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  ToggleLeft,
  ToggleRight,
  Info,
  Loader2,
  Sparkles,
  CalendarCheck,
  EyeOff,
  Building2,
  Gift,
} from 'lucide-react';

interface CharityViewProps {
  userProfile: UserProfile | null;
  currentLang: SupportedLanguage;
  masjidDetails: MasjidDetails;
  onNavigate: (tab: string) => void;
  onRefreshProfile?: () => void;
}

export const CharityView: React.FC<CharityViewProps> = ({
  userProfile,
  currentLang,
  masjidDetails,
  onNavigate,
}) => {
  const t = translations[currentLang];
  const isRtl = currentLang === 'ur' || currentLang === 'ar';

  // Current month key (e.g. "2026-09")
  const now = new Date();
  const currentMonthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const isFeePaidThisMonth = userProfile?.lastMonthlyFeePaid === currentMonthKey;
  const monthlyCommunityFee = masjidDetails.monthlyCommunityFee || 200;

  // Monthly recurring mandate state
  const [selectedMonthlyAmt, setSelectedMonthlyAmt] = useState<number>(
    userProfile?.monthlyCharity || monthlyCommunityFee
  );
  const [customMonthlyAmt, setCustomMonthlyAmt] = useState<string>('');
  const [autoCharityActive, setAutoCharityActive] = useState<boolean>(
    userProfile?.autoCharity ?? false
  );

  // One-time donation state
  const [oneTimeAmt, setOneTimeAmt] = useState<number>(monthlyCommunityFee);
  const [customOneTimeAmt, setCustomOneTimeAmt] = useState<string>('');
  const [charityType, setCharityType] = useState<
    'monthly_fee' | 'rabi_ul_awwal' | 'renovation' | 'sadqah' | 'zakat' | 'lillah' | 'one_time_charity'
  >('monthly_fee');
  const [isAnonymous, setIsAnonymous] = useState<boolean>(false);

  const [loadingMandate, setLoadingMandate] = useState(false);
  const [loadingDonate, setLoadingDonate] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const effectiveMonthly = customMonthlyAmt ? parseFloat(customMonthlyAmt) : selectedMonthlyAmt;
  const effectiveOneTime = customOneTimeAmt ? parseFloat(customOneTimeAmt) : oneTimeAmt;

  // 1-Click Pay Monthly Fee from Wallet
  const handlePayDirectMonthlyFee = async () => {
    if (!userProfile) return;
    setMessage(null);

    if ((userProfile.walletBalance || 0) < monthlyCommunityFee) {
      setMessage({
        type: 'error',
        text: `${t.insufficientBalance} Wallet balance: ₹${userProfile.walletBalance || 0}. Please add money.`,
      });
      return;
    }

    try {
      setLoadingDonate(true);
      const userRef = doc(db, 'users', userProfile.uid);

      await runTransaction(db, async (transaction) => {
        const uDoc = await transaction.get(userRef);
        if (!uDoc.exists()) throw new Error('User not found');
        const bal = uDoc.data().walletBalance || 0;
        if (bal < monthlyCommunityFee) throw new Error('Insufficient wallet balance');

        transaction.update(userRef, {
          walletBalance: bal - monthlyCommunityFee,
          lastMonthlyFeePaid: currentMonthKey,
          updatedAt: new Date().toISOString(),
        });
      });

      const txnId = `FEE_${Date.now()}`;
      await addDoc(collection(db, 'charities'), {
        uid: userProfile.uid,
        donorName: isAnonymous ? 'गुप्त दान (ख़िदमतगार)' : userProfile.name || 'Community Member',
        amount: monthlyCommunityFee,
        type: 'monthly_fee',
        status: 'successful',
        masjidId: 'madrasa_tegiya',
        transactionId: txnId,
        monthYear: currentMonthKey,
        isAnonymous: isAnonymous,
        createdAt: new Date().toISOString(),
      });

      await addDoc(collection(db, 'transactions'), {
        uid: userProfile.uid,
        type: 'monthly_fee',
        amount: monthlyCommunityFee,
        status: 'successful',
        paymentId: txnId,
        description: `Monthly Community Fee (${currentMonthKey}) - Mosque Maintenance & Imam Salary`,
        createdAt: new Date().toISOString(),
      });

      setMessage({
        type: 'success',
        text: `Alhamdulillah! Monthly community fee of ₹${monthlyCommunityFee} for ${currentMonthKey} has been recorded in the community ledger.`,
      });
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Payment failed.' });
    } finally {
      setLoadingDonate(false);
    }
  };

  // One-time or Cause-specific Donation from Wallet
  const handleDonateFromWallet = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);

    if (!userProfile) return;

    const donationAmt = Number(effectiveOneTime);
    if (!donationAmt || donationAmt <= 0) {
      setMessage({ type: 'error', text: 'Please enter a valid donation amount.' });
      return;
    }

    if ((userProfile.walletBalance || 0) < donationAmt) {
      setMessage({
        type: 'error',
        text: `${t.insufficientBalance} Current wallet balance: ₹${userProfile.walletBalance || 0}`,
      });
      return;
    }

    try {
      setLoadingDonate(true);
      const userRef = doc(db, 'users', userProfile.uid);

      await runTransaction(db, async (transaction) => {
        const userDoc = await transaction.get(userRef);
        if (!userDoc.exists()) {
          throw new Error('User profile does not exist!');
        }

        const currentBalance = userDoc.data().walletBalance || 0;
        if (currentBalance < donationAmt) {
          throw new Error('Insufficient wallet balance during execution.');
        }

        // Deduct from wallet
        const updates: any = {
          walletBalance: currentBalance - donationAmt,
          updatedAt: new Date().toISOString(),
        };

        if (charityType === 'monthly_fee') {
          updates.lastMonthlyFeePaid = currentMonthKey;
        }

        transaction.update(userRef, updates);
      });

      const txnId = `TXN_${Date.now()}`;
      // Record in charities collection with donor info for public transparency ledger
      await addDoc(collection(db, 'charities'), {
        uid: userProfile.uid,
        donorName: isAnonymous ? 'गुप्त दान (ख़िदमतगार)' : userProfile.name || 'Community Member',
        amount: donationAmt,
        type: charityType,
        status: 'successful',
        masjidId: 'madrasa_tegiya',
        transactionId: txnId,
        monthYear: currentMonthKey,
        isAnonymous: isAnonymous,
        createdAt: new Date().toISOString(),
      });

      // Record in transactions ledger
      await addDoc(collection(db, 'transactions'), {
        uid: userProfile.uid,
        type: 'charity_donation',
        amount: donationAmt,
        status: 'successful',
        description: `Charity: ${charityType.toUpperCase().replace(/_/g, ' ')} (${isAnonymous ? 'Anonymous' : 'Public'})`,
        paymentId: txnId,
        createdAt: new Date().toISOString(),
      });

      setMessage({
        type: 'success',
        text: `Alhamdulillah! Contribution of ₹${donationAmt} received. Logged to the community transparency ledger. Reference: ${txnId}`,
      });
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message || 'Donation failed.' });
    } finally {
      setLoadingDonate(false);
    }
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-900 text-white rounded-3xl p-6 sm:p-7 shadow-lg border border-emerald-700/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Heart className="w-5 h-5 text-amber-400 fill-amber-400" />
            <h2 className="text-xl sm:text-2xl font-black">{t.charityTitle}</h2>
          </div>
          <p className="text-xs sm:text-sm text-emerald-200">
            {t.charitySubtitle}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-emerald-800/80 px-3.5 py-2 rounded-xl border border-emerald-600/40 text-xs">
            <span className="text-emerald-300 block text-[10px] uppercase font-bold">Wallet Balance</span>
            <span className="text-base font-black text-white">₹{userProfile?.walletBalance ?? 0}</span>
          </div>

          <button
            onClick={() => onNavigate('wallet')}
            className="px-3.5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-amber-950 font-bold text-xs shadow-md transition-colors"
          >
            + Add Balance
          </button>
        </div>
      </div>

      {message && (
        <div
          className={`p-4 rounded-2xl text-xs flex items-center justify-between border ${
            message.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-red-50 border-red-200 text-red-900'
          }`}
        >
          <div className="flex items-center gap-2">
            {message.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            )}
            <span className="font-semibold">{message.text}</span>
          </div>
          <button onClick={() => setMessage(null)} className="text-slate-400 hover:text-slate-700 font-bold">
            ✕
          </button>
        </div>
      )}

      {/* SECTION 1: FIXED MONTHLY COMMUNITY FEE (इमाम साहब की तनख्वाह व मस्जिद मेंटेनेंस) */}
      <div
        className={`rounded-3xl p-6 sm:p-7 border shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-6 ${
          isFeePaidThisMonth
            ? 'bg-emerald-50/70 border-emerald-200'
            : 'bg-gradient-to-br from-amber-50 via-white to-amber-100/60 border-amber-300'
        }`}
      >
        <div className="space-y-2 max-w-xl">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg bg-amber-200 text-amber-950 text-[10px] font-black uppercase tracking-wider">
              अनिवार्य कम्युनिटी योगदान (Mandatory Community Fee)
            </span>
            <span
              className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                isFeePaidThisMonth ? 'bg-emerald-200 text-emerald-900' : 'bg-amber-200 text-amber-950'
              }`}
            >
              {isFeePaidThisMonth ? '✓ Paid for Current Month' : '⚠️ Due for Current Month'}
            </span>
          </div>

          <h3 className="text-lg sm:text-xl font-extrabold text-slate-900">
            मासिक कम्युनिटी फीस (इमाम साहब की तनख्वाह एवं मस्जिद मेंटेनेंस)
          </h3>

          <p className="text-xs text-slate-600 leading-relaxed">
            कम्युनिटी के हर सदस्य के ऊपर ₹{monthlyCommunityFee}/माह का तय चंदा है जिससे मस्जिद की बिजली, पानी, सफाई, और इमाम साहब की मासिक तनख्वाह समय पर अदा होती है।
          </p>

          <div className="flex items-center gap-4 text-xs font-semibold text-emerald-900 pt-1">
            <span className="bg-white/80 px-2.5 py-1 rounded-lg border border-slate-200">
              महीना: <strong className="font-bold">{currentMonthKey}</strong>
            </span>
            <span className="bg-white/80 px-2.5 py-1 rounded-lg border border-slate-200">
              राशि: <strong className="font-bold text-emerald-800">₹{monthlyCommunityFee}</strong>
            </span>
          </div>
        </div>

        <div className="shrink-0 self-stretch sm:self-auto flex flex-col gap-2">
          {isFeePaidThisMonth ? (
            <div className="p-3.5 rounded-2xl bg-emerald-100 text-emerald-900 text-xs font-bold flex items-center gap-2 border border-emerald-300">
              <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" />
              <span>इस महीने की फीस जमा हो चुकी है!</span>
            </div>
          ) : (
            <button
              onClick={handlePayDirectMonthlyFee}
              disabled={loadingDonate}
              className="py-3 px-6 rounded-2xl bg-emerald-800 hover:bg-emerald-900 text-white font-extrabold text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {loadingDonate ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <CalendarCheck className="w-4 h-4 text-amber-300" />
              )}
              <span>वॉलेट से ₹{monthlyCommunityFee} फीस अदा करें</span>
            </button>
          )}

          <button
            onClick={() => onNavigate('history')}
            className="text-center text-xs font-bold text-emerald-800 hover:text-emerald-950 py-1"
          >
            सार्वजनिक लेजर में सभी के नाम देखें →
          </button>
        </div>
      </div>

      {/* SECTION 2: SPECIAL CAMPAIGNS & GENERAL CHARITY DONATION */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Sparkles className="w-5 h-5 text-emerald-700" />
            <h3 className="font-bold text-base sm:text-lg text-slate-900">
              मस्जिद व मदरसा सहयोग एवं विशेष चंदा (Direct Contributions)
            </h3>
          </div>
          <p className="text-xs text-slate-500">
            चंदा सीधे आपके वॉलेट से कटकर मस्जिद के कोष में सुरक्षित जमा हो जाता है और सार्वजनिक लेजर में दर्ज होता है।
          </p>
        </div>

        <form onSubmit={handleDonateFromWallet} className="space-y-5">
          {/* Cause / Category Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-2">
              मद / कारण चुनें (Select Donation Category):
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
              {[
                { id: 'monthly_fee', label: 'मासिक कम्युनिटी फीस (इमाम तनख्वाह)' },
                { id: 'rabi_ul_awwal', label: '12 रबी-उल-अव्वल चंदा (विशेष)' },
                { id: 'renovation', label: 'मस्जिद मरम्मत एवं निर्माण' },
                { id: 'sadqah', label: 'सदक़ा (Sadqah)' },
                { id: 'zakat', label: 'ज़कात (Zakat)' },
                { id: 'lillah', label: 'लिल्लाह (Lillah / General)' },
              ].map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setCharityType(item.id as any)}
                  className={`p-3 rounded-2xl text-start font-bold border transition-all ${
                    charityType === item.id
                      ? 'bg-emerald-800 text-white border-emerald-800 shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Amount Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-800 mb-2">
              राशि चुनें (Select Amount):
            </label>
            <div className="grid grid-cols-4 gap-2 mb-2.5">
              {[100, 200, 500, 1000].map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => {
                    setOneTimeAmt(amt);
                    setCustomOneTimeAmt('');
                  }}
                  className={`py-2 px-3 rounded-xl text-xs font-bold border transition-colors ${
                    oneTimeAmt === amt && !customOneTimeAmt
                      ? 'bg-emerald-700 text-white border-emerald-700 shadow-sm'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  ₹{amt}
                </button>
              ))}
            </div>

            <div className="relative">
              <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">₹</span>
              <input
                type="number"
                min="10"
                placeholder="Or enter any custom amount in ₹"
                value={customOneTimeAmt}
                onChange={(e) => setCustomOneTimeAmt(e.target.value)}
                className="w-full pl-7 pr-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30"
              />
            </div>
          </div>

          {/* Anonymous Option */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <EyeOff className="w-4 h-4 text-slate-500" />
              <div>
                <span className="text-xs font-bold text-slate-800 block">
                  गुप्त दान (Keep My Name Anonymous in Public Ledger)
                </span>
                <span className="text-[11px] text-slate-500">
                  यदि आप इसे चुनते हैं, तो सार्वजनिक लेजर में आपके नाम की जगह "गुप्त दान (ख़िदमतगार)" दिखेगा।
                </span>
              </div>
            </div>

            <input
              type="checkbox"
              checked={isAnonymous}
              onChange={(e) => setIsAnonymous(e.target.checked)}
              className="w-5 h-5 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500 cursor-pointer"
            />
          </div>

          <button
            type="submit"
            disabled={loadingDonate}
            className="w-full py-3.5 rounded-2xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-extrabold text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {loadingDonate ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Heart className="w-4 h-4 fill-white" />
            )}
            <span>
              वॉलेट से ₹{effectiveOneTime || 0} चंदा अदा करें (Contribute from Wallet)
            </span>
          </button>
        </form>
      </div>
    </div>
  );
};

import React from 'react';
import { UserProfile, SupportedLanguage } from '../types';
import { translations } from '../i18n';
import { LogOut, Globe2, Shield, Wallet as WalletIcon } from 'lucide-react';

interface NavbarProps {
  userProfile: UserProfile | null;
  currentLang: SupportedLanguage;
  activeTab: string;
  isAdmin: boolean;
  currentMasjidName?: string;
  onOpenRegisterMasjid?: () => void;
  onLanguageChange: (lang: SupportedLanguage) => void;
  onNavigate: (tab: string) => void;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  userProfile,
  currentLang,
  activeTab,
  isAdmin,
  currentMasjidName,
  onOpenRegisterMasjid,
  onLanguageChange,
  onNavigate,
  onLogout,
}) => {
  const t = translations[currentLang];
  const isRtl = currentLang === 'ur' || currentLang === 'ar';

  return (
    <header className="bg-emerald-900 text-white shadow-md sticky top-0 z-40 border-b border-emerald-800" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="max-w-6xl mx-auto px-4 py-2.5 flex items-center justify-between">
        {/* Left Brand */}
        <div className="flex items-center gap-3">
          <button
            id="nav-brand-btn"
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 text-left focus:outline-none"
          >
            <span className="text-2xl select-none">🕌</span>
            <div>
              <span className="font-bold text-base sm:text-lg tracking-wide leading-tight block text-white">
                {t.appName}
              </span>
              <span className="text-[10px] text-emerald-200 hidden sm:block tracking-wider uppercase font-medium">
                {currentMasjidName || t.tagline}
              </span>
            </div>
          </button>

          {/* Quick Add Mosque Link in Navbar */}
          {onOpenRegisterMasjid && (
            <button
              onClick={onOpenRegisterMasjid}
              className="hidden md:flex items-center gap-1 text-[11px] font-bold text-amber-300 hover:text-amber-200 bg-amber-500/20 hover:bg-amber-500/30 px-2.5 py-1 rounded-full border border-amber-500/30 transition-all"
            >
              <span>+ मदरसा जोड़ें</span>
            </button>
          )}
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Wallet Pill */}
          <button
            id="nav-wallet-pill-btn"
            onClick={() => onNavigate('wallet')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-950/70 border border-emerald-700/60 text-emerald-200 hover:text-white hover:bg-emerald-800 transition-colors text-xs font-semibold"
            title={t.walletBalance}
          >
            <WalletIcon className="w-3.5 h-3.5 text-amber-400" />
            <span className="text-white">₹{userProfile?.walletBalance ?? 0}</span>
          </button>

          {/* Admin badge if authorized */}
          {isAdmin && (
            <button
              id="nav-admin-btn"
              onClick={() => onNavigate('admin')}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${
                activeTab === 'admin'
                  ? 'bg-amber-500 text-amber-950 shadow-sm'
                  : 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span className="hidden xs:inline">{t.adminPortal}</span>
            </button>
          )}

          {/* Language Switcher */}
          <div className="inline-flex rounded-lg bg-emerald-950/70 p-0.5 border border-emerald-700/50">
            {(['en', 'hi', 'ur', 'ar'] as SupportedLanguage[]).map((lang) => {
              const labels: Record<SupportedLanguage, string> = {
                en: 'EN',
                hi: 'हिं',
                ur: 'اردو',
                ar: 'عربي',
              };
              return (
                <button
                  key={lang}
                  id={`nav-lang-btn-${lang}`}
                  onClick={() => onLanguageChange(lang)}
                  className={`px-2 py-0.5 text-[11px] font-medium rounded transition-colors ${
                    currentLang === lang
                      ? 'bg-emerald-600 text-white font-semibold'
                      : 'text-emerald-200 hover:text-white'
                  }`}
                >
                  {labels[lang]}
                </button>
              );
            })}
          </div>

          {/* Logout */}
          <button
            id="nav-logout-btn"
            onClick={onLogout}
            title={t.logout}
            className="p-1.5 rounded-lg text-emerald-200 hover:text-white hover:bg-emerald-800/80 transition-colors"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};

import React, { useState, useEffect } from 'react';
import {
  collection,
  getDocs,
  doc,
  runTransaction,
  addDoc,
  setDoc,
  deleteDoc,
  updateDoc,
} from 'firebase/firestore';
import { db, auth } from '../firebase';
import {
  UserProfile,
  PaymentRequest,
  SupportTicket,
  AdvertisementItem,
  SupportedLanguage,
  MasjidDetails,
  MasjidRegistrationRequest,
} from '../types';
import { translations } from '../i18n';
import {
  Shield,
  Users,
  CreditCard,
  Building2,
  Megaphone,
  Headphones,
  CheckCircle2,
  XCircle,
  Clock,
  Check,
  AlertTriangle,
  Loader2,
  Search,
  Upload,
  Image as ImageIcon,
  Trash2,
  Plus,
  Landmark,
  Banknote,
  DollarSign,
  Inbox,
  FileCheck,
  Ban,
  Phone,
  Mail,
  MapPin,
  CheckCheck,
} from 'lucide-react';

interface AdminDashboardProps {
  currentLang: SupportedLanguage;
  currentUserProfile: UserProfile | null;
  masjidDetails: MasjidDetails;
  allMasjids?: MasjidDetails[];
  isSuperAdmin?: boolean;
  onSelectMasjid?: (masjidId: string) => void;
  onCloseAdmin: () => void;
  onUpdateMasjidDetails?: (details: Partial<MasjidDetails>) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentLang,
  currentUserProfile,
  masjidDetails,
  allMasjids = [],
  isSuperAdmin = false,
  onSelectMasjid,
  onCloseAdmin,
  onUpdateMasjidDetails,
}) => {
  const t = translations[currentLang];
  const isRtl = currentLang === 'ur' || currentLang === 'ar';

  const [activeTab, setActiveTab] = useState<
    'overview' | 'requests' | 'payments' | 'bank' | 'madrasa' | 'ads' | 'users' | 'support'
  >('overview');

  // Stats
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [allPayments, setAllPayments] = useState<PaymentRequest[]>([]);
  const [allSupport, setAllSupport] = useState<SupportTicket[]>([]);
  const [allAds, setAllAds] = useState<AdvertisementItem[]>([]);
  const [masjidRequests, setMasjidRequests] = useState<MasjidRegistrationRequest[]>([]);
  const [requestFilter, setRequestFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [loadingData, setLoadingData] = useState(true);

  // Direct Mosque Creation Modal by Super Admin
  const [showAddMosqueModal, setShowAddMosqueModal] = useState(false);
  const [directMosqueName, setDirectMosqueName] = useState('');
  const [directDistrict, setDirectDistrict] = useState('Muzaffarpur');
  const [directState, setDirectState] = useState('Bihar');
  const [directAddress, setDirectAddress] = useState('');
  const [directAdminName, setDirectAdminName] = useState('');
  const [directAdminEmail, setDirectAdminEmail] = useState('');
  const [directAdminPhone, setDirectAdminPhone] = useState('');
  const [directLoading, setDirectLoading] = useState(false);

  // Action states
  const [verifyingId, setVerifyingId] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Bank & Mosque Config Form State
  const [bankAccountName, setBankAccountName] = useState(masjidDetails.bankAccountName || '');
  const [bankName, setBankName] = useState(masjidDetails.bankName || '');
  const [bankAccountNumber, setBankAccountNumber] = useState(masjidDetails.bankAccountNumber || '');
  const [bankIfsc, setBankIfsc] = useState(masjidDetails.bankIfsc || '');
  const [bankUpiId, setBankUpiId] = useState(masjidDetails.bankUpiId || '');
  const [monthlyCommunityFee, setMonthlyCommunityFee] = useState<number>(masjidDetails.monthlyCommunityFee || 200);
  const [monthlyFeeNote, setMonthlyFeeNote] = useState<string>(
    masjidDetails.monthlyFeeNote || 'इमाम साहब की मासिक तनख्वाह एवं मस्जिद बिजली, पानी, सफाई मेंटेनेंस'
  );
  const [updatingMonthlyFee, setUpdatingMonthlyFee] = useState(false);
  const [savingBank, setSavingBank] = useState(false);

  // Madrasa Profile & Photo Form State
  const [madrasaName, setMadrasaName] = useState(masjidDetails.name || 'Madrasa Tegiya Talim Al Islam');
  const [madrasaAddress, setMadrasaAddress] = useState(masjidDetails.address || 'Kamalpura Baradih, Muzaffarpur, Bihar - 843113');
  const [madrasaDesc, setMadrasaDesc] = useState(masjidDetails.description || '');
  const [madrasaContact, setMadrasaContact] = useState(masjidDetails.contact || '');
  const [adminName, setAdminName] = useState(masjidDetails.adminName || 'Hafez Md. Rizwan (मुतवल्ली / व्यवस्थापक)');
  const [adminPhone, setAdminPhone] = useState(masjidDetails.adminPhone || '+91 9876543210');
  const [adminWhatsapp, setAdminWhatsapp] = useState(masjidDetails.adminWhatsapp || '+91 9876543210');
  const [adminEmail, setAdminEmail] = useState(masjidDetails.adminEmail || 'rockybo09876@gmail.com');
  const [adminSupportTiming, setAdminSupportTiming] = useState(masjidDetails.adminSupportTiming || 'सुबह 8:00 AM से रात 9:00 PM');
  const [photoUrl, setPhotoUrl] = useState(masjidDetails.photoUrl || '/madrasa_tegiya.jpg');
  const [photoPreview, setPhotoPreview] = useState<string | null>(masjidDetails.photoUrl || '/madrasa_tegiya.jpg');
  const [savingMadrasa, setSavingMadrasa] = useState(false);

  // Support Reply state
  const [replyTicketId, setReplyTicketId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');
  const [replyStatus, setReplyStatus] = useState<'Open' | 'In Progress' | 'Resolved'>('In Progress');

  // New Ad state
  const [newAdTitle, setNewAdTitle] = useState('');
  const [newAdDesc, setNewAdDesc] = useState('');
  const [newAdCategory, setNewAdCategory] = useState<'rabi_ul_awwal' | 'renovation' | 'ramadan' | 'general'>('rabi_ul_awwal');
  const [newAdTarget, setNewAdTarget] = useState<string>('50000');
  const [creatingAd, setCreatingAd] = useState(false);

  // Search filter
  const [searchQuery, setSearchQuery] = useState('');

  // Sync state when masjidDetails changes
  useEffect(() => {
    if (masjidDetails) {
      setBankAccountName(masjidDetails.bankAccountName || '');
      setBankName(masjidDetails.bankName || '');
      setBankAccountNumber(masjidDetails.bankAccountNumber || '');
      setBankIfsc(masjidDetails.bankIfsc || '');
      setBankUpiId(masjidDetails.bankUpiId || '');
      setMonthlyCommunityFee(masjidDetails.monthlyCommunityFee || 200);
      setMonthlyFeeNote(masjidDetails.monthlyFeeNote || '');
      setMadrasaName(masjidDetails.name || '');
      setMadrasaAddress(masjidDetails.address || '');
      setMadrasaDesc(masjidDetails.description || '');
      setMadrasaContact(masjidDetails.contact || '');
      setAdminName(masjidDetails.adminName || 'Hafez Md. Rizwan (मुतवल्ली / व्यवस्थापक)');
      setAdminPhone(masjidDetails.adminPhone || '+91 9876543210');
      setAdminWhatsapp(masjidDetails.adminWhatsapp || '+91 9876543210');
      setAdminEmail(masjidDetails.adminEmail || 'rockybo09876@gmail.com');
      setAdminSupportTiming(masjidDetails.adminSupportTiming || 'सुबह 8:00 AM से रात 9:00 PM');
      setPhotoUrl(masjidDetails.photoUrl || '/madrasa_tegiya.jpg');
      setPhotoPreview(masjidDetails.photoUrl || '/madrasa_tegiya.jpg');
    }
  }, [masjidDetails]);

  // Fetch admin data
  const fetchAllData = async () => {
    try {
      setLoadingData(true);

      // Fetch users
      const usersSnap = await getDocs(collection(db, 'users'));
      const usersList: UserProfile[] = [];
      usersSnap.forEach((d) => {
        usersList.push({ id: d.id, ...d.data() } as any);
      });
      setAllUsers(usersList);

      // Fetch payments
      const paymentsSnap = await getDocs(collection(db, 'payments'));
      const paymentsList: PaymentRequest[] = [];
      paymentsSnap.forEach((d) => {
        paymentsList.push({ id: d.id, ...d.data() } as any);
      });
      paymentsList.sort(
        (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
      );
      setAllPayments(paymentsList);

      // Fetch support messages
      const supportSnap = await getDocs(collection(db, 'supportMessages'));
      const supportList: SupportTicket[] = [];
      supportSnap.forEach((d) => {
        supportList.push({ id: d.id, ...d.data() } as any);
      });
      supportList.sort(
        (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
      );
      setAllSupport(supportList);

      // Fetch advertisements
      const adsSnap = await getDocs(collection(db, 'advertisements'));
      const adsList: AdvertisementItem[] = [];
      adsSnap.forEach((d) => {
        adsList.push({ id: d.id, ...d.data() } as any);
      });
      setAllAds(adsList);

      // Fetch Mosque Registration Requests
      try {
        const requestsSnap = await getDocs(collection(db, 'masjid_requests'));
        const reqList: MasjidRegistrationRequest[] = [];
        requestsSnap.forEach((d) => {
          reqList.push({ id: d.id, ...d.data() } as MasjidRegistrationRequest);
        });
        reqList.sort(
          (a, b) => new Date(b.requestedAt || 0).getTime() - new Date(a.requestedAt || 0).getTime()
        );
        setMasjidRequests(reqList);
      } catch (reqErr) {
        console.warn('Error fetching masjid requests:', reqErr);
      }
    } catch (err) {
      console.warn('Error fetching admin data:', err);
    } finally {
      setLoadingData(false);
    }
  };

  useEffect(() => {
    fetchAllData();
  }, []);

  // Super Admin: Approve Mosque Registration Request
  const handleApproveRequest = async (req: MasjidRegistrationRequest) => {
    try {
      setActionLoadingId(req.id);
      setActionMessage(null);

      // Create unique slug/id for new mosque
      const cleanSlug = req.masjidName
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '_')
        .slice(0, 20);
      const newMasjidId = `masjid_${cleanSlug}_${Date.now().toString(36).slice(-4)}`;

      // 1. Create Mosque Document in masjids collection with BLANK bank & UPI
      const newMasjidData: MasjidDetails = {
        id: newMasjidId,
        name: req.masjidName,
        address: req.address || `${req.district}, ${req.state}`,
        city: req.city || req.district,
        district: req.district,
        state: req.state,
        description: req.note || `मस्जिद एवं मदरसा ${req.masjidName}`,
        purpose: 'धार्मिक शिक्षा, हिफ़्ज़, नमाज़ एवं कम्युनिटी वेलफेयर',
        photoUrl: '/madrasa_tegiya.jpg',
        contact: req.applicantPhone,
        active: true,
        adminName: req.applicantName,
        adminPhone: req.applicantPhone,
        adminWhatsapp: req.applicantPhone,
        adminEmail: req.applicantEmail.toLowerCase(),
        adminSupportTiming: 'सुबह 8:00 AM से रात 9:00 PM',
        // IMPORTANT: Blank bank details until admin logs in and configures it
        bankAccountName: '',
        bankName: '',
        bankAccountNumber: '',
        bankIfsc: '',
        bankUpiId: '',
        monthlyCommunityFee: 200,
        monthlyFeeNote: 'इमाम साहब की मासिक तनख्वाह एवं मस्जिद बिजली, पानी, सफाई मेंटेनेंस',
        updatedAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'masjids', newMasjidId), newMasjidData);

      // 2. Grant Admin Role in admins collection by Email
      const adminEmailKey = req.applicantEmail.toLowerCase();
      await setDoc(doc(db, 'admins', adminEmailKey), {
        email: adminEmailKey,
        masjidId: newMasjidId,
        masjidName: req.masjidName,
        role: 'admin',
        applicantName: req.applicantName,
        grantedBy: currentUserProfile?.email || 'super_admin',
        grantedAt: new Date().toISOString(),
      });

      // 3. Mark request as approved
      await updateDoc(doc(db, 'masjid_requests', req.id), {
        status: 'approved',
        masjidId: newMasjidId,
        reviewedAt: new Date().toISOString(),
        reviewedBy: currentUserProfile?.email || 'super_admin',
      });

      setActionMessage({
        type: 'success',
        text: `अल्हम्दुलिल्लाह! "${req.masjidName}" का रजिस्ट्रेशन स्वीकृत कर दिया गया है। एडमिन खाता (${adminEmailKey}) सक्रिय है।`,
      });

      fetchAllData();
    } catch (err: any) {
      console.error('Approval error:', err);
      setActionMessage({
        type: 'error',
        text: err.message || 'अप्रूवल में त्रुटि आई। कृपया पुनः प्रयास करें।',
      });
    } finally {
      setActionLoadingId(null);
    }
  };

  // Super Admin: Reject Mosque Registration Request
  const handleRejectRequest = async (req: MasjidRegistrationRequest) => {
    const reason = window.prompt(
      'अस्वीकार करने का कारण दर्ज करें (Reason for rejection):',
      'दस्तावेज या सत्यापन अधूरा है।'
    );
    if (reason === null) return;

    try {
      setActionLoadingId(req.id);
      setActionMessage(null);

      await updateDoc(doc(db, 'masjid_requests', req.id), {
        status: 'rejected',
        rejectionReason: reason || 'अस्वीकृत',
        reviewedAt: new Date().toISOString(),
        reviewedBy: currentUserProfile?.email || 'super_admin',
      });

      setActionMessage({
        type: 'success',
        text: `रिक्वेस्ट अस्वीकृत (Rejected) कर दी गई है।`,
      });

      fetchAllData();
    } catch (err: any) {
      console.error('Rejection error:', err);
      setActionMessage({
        type: 'error',
        text: err.message || 'अपडेट करने में त्रुटि आई।',
      });
    } finally {
      setActionLoadingId(null);
    }
  };

  // Super Admin: Direct Instant Create Mosque
  const handleDirectCreateMosque = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = directMosqueName.trim();
    const cleanEmail = directAdminEmail.trim().toLowerCase();

    if (!cleanName || !cleanEmail) {
      setActionMessage({ type: 'error', text: 'मदरसे का नाम एवं एडमिन ईमेल आवश्यक है।' });
      return;
    }

    try {
      setDirectLoading(true);
      const cleanSlug = cleanName
        .toLowerCase()
        .replace(/[^a-z0-9]/g, '_')
        .slice(0, 20);
      const newMasjidId = `masjid_${cleanSlug}_${Date.now().toString(36).slice(-4)}`;

      const newMasjidData: MasjidDetails = {
        id: newMasjidId,
        name: cleanName,
        address: directAddress.trim() || `${directDistrict}, ${directState}`,
        city: directDistrict,
        district: directDistrict,
        state: directState,
        description: `मस्जिद एवं मदरसा ${cleanName}`,
        purpose: 'धार्मिक शिक्षा, नमाज़ एवं कम्युनिटी वेलफेयर',
        photoUrl: '/madrasa_tegiya.jpg',
        contact: directAdminPhone.trim() || '+91 9876543210',
        active: true,
        adminName: directAdminName.trim() || 'मुतवल्ली / व्यवस्थापक',
        adminPhone: directAdminPhone.trim() || '',
        adminWhatsapp: directAdminPhone.trim() || '',
        adminEmail: cleanEmail,
        adminSupportTiming: 'सुबह 8:00 AM से रात 9:00 PM',
        bankAccountName: '',
        bankName: '',
        bankAccountNumber: '',
        bankIfsc: '',
        bankUpiId: '',
        monthlyCommunityFee: 200,
        monthlyFeeNote: 'इमाम साहब की मासिक तनख्वाह एवं मस्जिद बिजली, पानी, सफाई मेंटेनेंस',
        updatedAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'masjids', newMasjidId), newMasjidData);

      await setDoc(doc(db, 'admins', cleanEmail), {
        email: cleanEmail,
        masjidId: newMasjidId,
        masjidName: cleanName,
        role: 'admin',
        applicantName: directAdminName.trim() || 'मुतवल्ली',
        grantedBy: currentUserProfile?.email || 'super_admin',
        grantedAt: new Date().toISOString(),
      });

      setActionMessage({
        type: 'success',
        text: `अल्हम्दुलिल्लाह! नया मदरसा "${cleanName}" लाइव कर दिया गया है। एडमिन: ${cleanEmail}`,
      });

      setShowAddMosqueModal(false);
      setDirectMosqueName('');
      setDirectAdminEmail('');
      setDirectAdminPhone('');
      setDirectAdminName('');
      setDirectAddress('');

      fetchAllData();
    } catch (err: any) {
      console.error('Direct creation error:', err);
      setActionMessage({
        type: 'error',
        text: err.message || 'मदरसा जोड़ने में त्रुटि आई।',
      });
    } finally {
      setDirectLoading(false);
    }
  };

  // Secure payment verification by Admin
  const handleVerifyPayment = async (payment: PaymentRequest) => {
    if (!payment.uid || !payment.amount || payment.amount <= 0) {
      setActionMessage({ type: 'error', text: 'Invalid payment record.' });
      return;
    }

    try {
      setVerifyingId(payment.id);
      setActionMessage(null);

      const userRef = doc(db, 'users', payment.uid);
      const paymentRef = doc(db, 'payments', payment.id);

      await runTransaction(db, async (transaction) => {
        const userDoc = await transaction.get(userRef);
        if (!userDoc.exists()) {
          throw new Error('Associated user account does not exist.');
        }

        const currentBal = userDoc.data().walletBalance || 0;
        const newBal = currentBal + payment.amount;

        // 1. Update wallet balance
        transaction.update(userRef, {
          walletBalance: newBal,
          updatedAt: new Date().toISOString(),
        });

        // 2. Mark payment as verified
        transaction.update(paymentRef, {
          status: 'verified',
          verifiedAt: new Date().toISOString(),
          verifiedBy: auth.currentUser?.uid || 'admin',
        });
      });

      // 3. Create verified transaction record
      await addDoc(collection(db, 'transactions'), {
        uid: payment.uid,
        type: 'wallet_topup',
        amount: payment.amount,
        status: 'successful',
        paymentId: payment.providerTransactionId || payment.id,
        description: `Verified UPI Deposit into Admin Bank (Ref: ${payment.providerTransactionId})`,
        createdAt: new Date().toISOString(),
      });

      setActionMessage({
        type: 'success',
        text: `Payment of ₹${payment.amount} verified! Credited to user account.`,
      });

      // Refresh list
      fetchAllData();
    } catch (err: any) {
      console.error('Verification error:', err);
      setActionMessage({
        type: 'error',
        text: err.message || 'Failed to verify payment. Please try again.',
      });
    } finally {
      setVerifyingId(null);
    }
  };

  // Reject payment
  const handleRejectPayment = async (paymentId: string) => {
    try {
      setVerifyingId(paymentId);
      setActionMessage(null);

      const paymentRef = doc(db, 'payments', paymentId);
      await updateDoc(paymentRef, {
        status: 'rejected',
        verifiedAt: new Date().toISOString(),
        verifiedBy: auth.currentUser?.uid || 'admin',
      });

      setActionMessage({ type: 'success', text: 'Payment request marked as Rejected.' });
      fetchAllData();
    } catch (err: any) {
      setActionMessage({ type: 'error', text: err.message || 'Failed to reject payment.' });
    } finally {
      setVerifyingId(null);
    }
  };

  // Photo upload handler (compresses to client base64 or URL)
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setActionMessage({ type: 'error', text: 'Please select a valid image file.' });
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Canvas compression to 1280px max width for clean 16:9 view and small payload
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 1280;
        let width = img.width;
        let height = img.height;

        if (width > MAX_WIDTH) {
          height = Math.round((height * MAX_WIDTH) / width);
          width = MAX_WIDTH;
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);

        // Quality 0.8 JPEG Data URL
        const dataUrl = canvas.toDataURL('image/jpeg', 0.82);
        setPhotoPreview(dataUrl);
        setPhotoUrl(dataUrl);
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Save Madrasa Profile & Photo to Firestore
  const handleSaveMadrasa = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingMadrasa(true);
    setActionMessage(null);

    try {
      const activeId = masjidDetails.id || 'madrasa_tegiya';
      const docRef = doc(db, 'masjids', activeId);
      await setDoc(
        docRef,
        {
          id: activeId,
          name: madrasaName,
          address: madrasaAddress,
          description: madrasaDesc,
          contact: madrasaContact,
          adminName: adminName.trim(),
          adminPhone: adminPhone.trim(),
          adminWhatsapp: adminWhatsapp.trim(),
          adminEmail: adminEmail.trim(),
          adminSupportTiming: adminSupportTiming.trim(),
          photoUrl: photoUrl || '/madrasa_tegiya.jpg',
          updatedAt: new Date().toISOString(),
          active: true,
        },
        { merge: true }
      );

      if (onUpdateMasjidDetails) {
        onUpdateMasjidDetails({
          name: madrasaName,
          address: madrasaAddress,
          description: madrasaDesc,
          contact: madrasaContact,
          adminName: adminName.trim(),
          adminPhone: adminPhone.trim(),
          adminWhatsapp: adminWhatsapp.trim(),
          adminEmail: adminEmail.trim(),
          adminSupportTiming: adminSupportTiming.trim(),
          photoUrl: photoUrl || '/madrasa_tegiya.jpg',
        });
      }

      setActionMessage({
        type: 'success',
        text: 'Mosque & Madrasa details, photo, and admin support contacts saved successfully! Live for all users.',
      });
    } catch (err: any) {
      console.error('Error saving madrasa details:', err);
      setActionMessage({ type: 'error', text: err.message || 'Failed to save madrasa details.' });
    } finally {
      setSavingMadrasa(false);
    }
  };

  // Direct Monthly Community Fee quick updater
  const handleDirectUpdateMonthlyFee = async (newAmount: number, noteText: string) => {
    try {
      setUpdatingMonthlyFee(true);
      setActionMessage(null);
      const feeNum = Number(newAmount) || 200;
      const activeId = masjidDetails.id || 'madrasa_tegiya';
      const docRef = doc(db, 'masjids', activeId);
      await setDoc(
        docRef,
        {
          monthlyCommunityFee: feeNum,
          monthlyFeeNote: noteText.trim(),
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );
      setMonthlyCommunityFee(feeNum);
      if (onUpdateMasjidDetails) {
        onUpdateMasjidDetails({
          monthlyCommunityFee: feeNum,
          monthlyFeeNote: noteText.trim(),
        });
      }
      setActionMessage({
        type: 'success',
        text: `मासिक कम्युनिटी फीस सफलतापूर्वक ₹${feeNum} कर दी गई है! यह सभी कम्युनिटी सदस्यों के स्क्रीन पर तुरंत लाइव हो गई है।`,
      });
    } catch (err: any) {
      console.error('Error updating fee:', err);
      setActionMessage({ type: 'error', text: err.message || 'Failed to update fee' });
    } finally {
      setUpdatingMonthlyFee(false);
    }
  };

  // Save Admin Bank & Monthly Fee Setup to Firestore
  const handleSaveBankConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingBank(true);
    setActionMessage(null);

    try {
      const activeId = masjidDetails.id || 'madrasa_tegiya';
      const docRef = doc(db, 'masjids', activeId);
      await setDoc(
        docRef,
        {
          bankAccountName: bankAccountName.trim(),
          bankName: bankName.trim(),
          bankAccountNumber: bankAccountNumber.trim(),
          bankIfsc: bankIfsc.trim().toUpperCase(),
          bankUpiId: bankUpiId.trim(),
          monthlyCommunityFee: Number(monthlyCommunityFee) || 200,
          monthlyFeeNote: monthlyFeeNote.trim(),
          adminName: adminName.trim(),
          adminPhone: adminPhone.trim(),
          adminWhatsapp: adminWhatsapp.trim(),
          adminEmail: adminEmail.trim(),
          adminSupportTiming: adminSupportTiming.trim(),
          updatedAt: new Date().toISOString(),
        },
        { merge: true }
      );

      if (onUpdateMasjidDetails) {
        onUpdateMasjidDetails({
          bankAccountName: bankAccountName.trim(),
          bankName: bankName.trim(),
          bankAccountNumber: bankAccountNumber.trim(),
          bankIfsc: bankIfsc.trim().toUpperCase(),
          bankUpiId: bankUpiId.trim(),
          monthlyCommunityFee: Number(monthlyCommunityFee) || 200,
          monthlyFeeNote: monthlyFeeNote.trim(),
        });
      }

      setActionMessage({
        type: 'success',
        text: 'Admin Bank details, Monthly Fee, and Support Contacts saved successfully! All donor payments will direct to this account.',
      });
    } catch (err: any) {
      console.error('Error saving bank details:', err);
      setActionMessage({ type: 'error', text: err.message || 'Failed to save bank configuration.' });
    } finally {
      setSavingBank(false);
    }
  };

  // Create Advertisement / Campaign
  const handleCreateAd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAdTitle.trim() || !newAdDesc.trim()) {
      setActionMessage({ type: 'error', text: 'Please fill out both title and description.' });
      return;
    }

    try {
      setCreatingAd(true);
      setActionMessage(null);

      await addDoc(collection(db, 'advertisements'), {
        title: newAdTitle.trim(),
        description: newAdDesc.trim(),
        category: newAdCategory,
        targetAmount: Number(newAdTarget) || 50000,
        active: true,
        createdAt: new Date().toISOString(),
      });

      setNewAdTitle('');
      setNewAdDesc('');
      setActionMessage({ type: 'success', text: 'New Campaign Announcement created successfully!' });
      fetchAllData();
    } catch (err: any) {
      setActionMessage({ type: 'error', text: err.message || 'Failed to create advertisement.' });
    } finally {
      setCreatingAd(false);
    }
  };

  // Toggle or delete ad
  const handleDeleteAd = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'advertisements', id));
      setActionMessage({ type: 'success', text: 'Campaign removed successfully.' });
      fetchAllData();
    } catch (err: any) {
      setActionMessage({ type: 'error', text: 'Failed to delete campaign.' });
    }
  };

  // Reply to support ticket
  const handleReplyTicket = async (ticketId: string) => {
    if (!replyText.trim()) return;

    try {
      const ticketRef = doc(db, 'supportMessages', ticketId);
      await updateDoc(ticketRef, {
        reply: replyText.trim(),
        status: replyStatus,
        updatedAt: new Date().toISOString(),
      });

      setActionMessage({ type: 'success', text: 'Support ticket updated with official reply.' });
      setReplyTicketId(null);
      setReplyText('');
      fetchAllData();
    } catch (err: any) {
      setActionMessage({ type: 'error', text: 'Failed to reply to support ticket.' });
    }
  };

  const pendingPaymentsList = allPayments.filter((p) => p.status === 'pending');
  const verifiedPaymentsList = allPayments.filter((p) => p.status === 'verified');
  const totalVerifiedAmount = verifiedPaymentsList.reduce((acc, curr) => acc + (curr.amount || 0), 0);
  const pendingRequestsList = masjidRequests.filter((r) => r.status === 'pending');

  return (
    <div className="space-y-6 pb-20 md:pb-8" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="bg-slate-900 text-white rounded-3xl p-5 sm:p-7 shadow-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg sm:text-xl font-extrabold text-white tracking-tight">
                {t.adminDashboard}
              </h2>
              <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 font-bold text-[10px] uppercase border border-amber-500/30">
                {isSuperAdmin ? 'Super Admin Portal' : 'Official Mosque Admin'}
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5 font-medium">
              {masjidDetails.name} • {masjidDetails.city || masjidDetails.district || 'Bihar'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap self-start sm:self-auto">
          {/* Mosque Selector if Super Admin or multiple mosques exist */}
          {allMasjids.length > 1 && onSelectMasjid && (
            <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
              <Building2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <select
                value={masjidDetails.id}
                onChange={(e) => onSelectMasjid(e.target.value)}
                className="bg-transparent text-xs text-white font-medium focus:outline-none cursor-pointer"
              >
                {allMasjids.map((m) => (
                  <option key={m.id} value={m.id} className="bg-slate-900 text-white">
                    {m.name} ({m.district || 'Bihar'})
                  </option>
                ))}
              </select>
            </div>
          )}

          <button
            onClick={onCloseAdmin}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition-colors"
          >
            {t.close}
          </button>
        </div>
      </div>

      {/* Action notification toast */}
      {actionMessage && (
        <div
          className={`p-4 rounded-2xl text-xs flex items-center justify-between border ${
            actionMessage.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-red-50 border-red-200 text-red-900'
          }`}
        >
          <div className="flex items-center gap-2">
            {actionMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
            )}
            <span className="font-semibold">{actionMessage.text}</span>
          </div>
          <button
            onClick={() => setActionMessage(null)}
            className="text-slate-400 hover:text-slate-700 text-sm font-bold ml-3"
          >
            ✕
          </button>
        </div>
      )}

      {/* Admin Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            activeTab === 'overview'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <span>Overview</span>
        </button>

        {/* Super Admin: Mosque Registration Requests Tab */}
        {isSuperAdmin && (
          <button
            onClick={() => setActiveTab('requests')}
            className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
              activeTab === 'requests'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'bg-amber-50 text-amber-900 hover:bg-amber-100 border border-amber-300'
            }`}
          >
            <Inbox className="w-3.5 h-3.5 text-amber-900" />
            <span>मदरसा अप्रूवल (Requests)</span>
            {pendingRequestsList.length > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-red-600 text-white text-[10px] font-black animate-pulse">
                {pendingRequestsList.length}
              </span>
            )}
          </button>
        )}

        <button
          onClick={() => setActiveTab('payments')}
          className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            activeTab === 'payments'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <CreditCard className="w-3.5 h-3.5" />
          <span>Payment Verifications</span>
          {pendingPaymentsList.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-amber-400 text-amber-950 text-[10px] font-black">
              {pendingPaymentsList.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveTab('bank')}
          className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            activeTab === 'bank'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Landmark className="w-3.5 h-3.5" />
          <span>Admin Bank & UPI Setup</span>
        </button>

        <button
          onClick={() => setActiveTab('madrasa')}
          className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            activeTab === 'madrasa'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Photo & Mosque Details</span>
        </button>

        <button
          onClick={() => setActiveTab('ads')}
          className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            activeTab === 'ads'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Megaphone className="w-3.5 h-3.5" />
          <span>Campaigns & Announcements</span>
        </button>

        <button
          onClick={() => setActiveTab('users')}
          className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            activeTab === 'users'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          <span>Users ({allUsers.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('support')}
          className={`px-3.5 py-2 rounded-xl font-bold whitespace-nowrap transition-all flex items-center gap-1.5 ${
            activeTab === 'support'
              ? 'bg-emerald-700 text-white shadow-sm'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Headphones className="w-3.5 h-3.5" />
          <span>Support ({allSupport.length})</span>
        </button>
      </div>

      {/* TAB: MOSQUE REGISTRATION REQUESTS & APPROVALS (SUPER ADMIN) */}
      {activeTab === 'requests' && (
        <div className="space-y-6">
          {/* Top Bar with stats and actions */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <Inbox className="w-5 h-5 text-amber-600" />
                <h3 className="font-extrabold text-slate-900 text-base">
                  मदरसा एवं मस्जिद अप्रूवल सेंटर (Mosque Approval Center)
                </h3>
              </div>
              <p className="text-xs text-slate-600 mt-1 max-w-xl">
                वेबसाइट से प्राप्त सभी नए मदरसों/मस्जिदों के ऑनलाइन आवेदन यहाँ आते हैं। मुतवल्ली की पुष्टि करके एक क्लिक में अप्रूव करें।
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                onClick={() => setShowAddMosqueModal(true)}
                className="px-4 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md shadow-emerald-700/20 flex items-center gap-2 transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>+ सीधे नया मदरसा जोड़ें</span>
              </button>
            </div>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <button
              onClick={() => setRequestFilter('pending')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                requestFilter === 'pending'
                  ? 'bg-amber-500 text-amber-950 shadow-sm'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <span>लंबित आवेदन (Pending)</span>
              <span className="px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-950 font-black text-[10px]">
                {pendingRequestsList.length}
              </span>
            </button>

            <button
              onClick={() => setRequestFilter('approved')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                requestFilter === 'approved'
                  ? 'bg-emerald-700 text-white shadow-sm'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <span>स्वीकृत (Approved)</span>
              <span className="px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold text-[10px]">
                {masjidRequests.filter((r) => r.status === 'approved').length}
              </span>
            </button>

            <button
              onClick={() => setRequestFilter('rejected')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                requestFilter === 'rejected'
                  ? 'bg-red-700 text-white shadow-sm'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <span>अस्वीकृत (Rejected)</span>
              <span className="px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold text-[10px]">
                {masjidRequests.filter((r) => r.status === 'rejected').length}
              </span>
            </button>

            <button
              onClick={() => setRequestFilter('all')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1.5 ${
                requestFilter === 'all'
                  ? 'bg-slate-800 text-white shadow-sm'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <span>सभी आवेदन (All)</span>
              <span className="px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold text-[10px]">
                {masjidRequests.length}
              </span>
            </button>
          </div>

          {/* Requests List */}
          {masjidRequests.length === 0 ? (
            <div className="bg-white rounded-2xl p-10 border border-slate-200 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <Inbox className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-slate-800 text-sm">अभी कोई आवेदन नहीं है</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                जब कोई मस्जिद या मदरसा प्रतिनिधि "अपनी मस्जिद जोड़ें" फॉर्म भरेगा, तो उसका विवरण यहाँ दिखेगा।
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {masjidRequests
                .filter((r) => (requestFilter === 'all' ? true : r.status === requestFilter))
                .map((req) => (
                  <div
                    key={req.id}
                    className="bg-white rounded-2xl border border-slate-200 shadow-sm p-5 space-y-4 transition-all hover:border-slate-300"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 border-b border-slate-100 pb-3.5">
                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <h4 className="font-extrabold text-slate-900 text-base">{req.masjidName}</h4>
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wide ${
                              req.status === 'pending'
                                ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                : req.status === 'approved'
                                ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                                : 'bg-red-100 text-red-900 border border-red-300'
                            }`}
                          >
                            {req.status === 'pending'
                              ? 'समीक्षा लंबित (Pending Approval)'
                              : req.status === 'approved'
                              ? 'स्वीकृत एवं सक्रिय (Active Live)'
                              : 'अस्वीकृत (Rejected)'}
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1">
                          <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>
                            {req.address ? `${req.address}, ` : ''}
                            {req.district}, {req.state}
                          </span>
                        </div>
                      </div>

                      <div className="text-left sm:text-right text-[11px] text-slate-400">
                        आवेदन तिथि: {new Date(req.requestedAt).toLocaleDateString('hi-IN', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </div>
                    </div>

                    {/* Applicant & Mosque Meta Details */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 bg-slate-50/70 p-3.5 rounded-xl text-xs border border-slate-100">
                      <div>
                        <span className="text-[10px] font-semibold text-slate-400 block uppercase">
                          आवेदक / मुतवल्ली (Applicant)
                        </span>
                        <div className="font-bold text-slate-800 mt-0.5">{req.applicantName}</div>
                        <div className="text-[11px] text-slate-500">{req.applicantDesignation || 'मुतवल्ली'}</div>
                      </div>

                      <div>
                        <span className="text-[10px] font-semibold text-slate-400 block uppercase">
                          संपर्क विवरण (Contact Info)
                        </span>
                        <div className="flex items-center gap-1.5 font-medium text-slate-700 mt-0.5">
                          <Phone className="w-3 h-3 text-slate-400" />
                          <a href={`tel:${req.applicantPhone}`} className="hover:underline text-emerald-700">
                            {req.applicantPhone}
                          </a>
                        </div>
                        <div className="flex items-center gap-1.5 font-medium text-slate-700 mt-0.5">
                          <Mail className="w-3 h-3 text-slate-400" />
                          <a href={`mailto:${req.applicantEmail}`} className="hover:underline text-emerald-700">
                            {req.applicantEmail}
                          </a>
                        </div>
                      </div>

                      <div>
                        <span className="text-[10px] font-semibold text-slate-400 block uppercase">
                          वक्फ / ट्रस्ट संख्या (Waqf / Trust No.)
                        </span>
                        <div className="font-medium text-slate-700 mt-0.5">
                          {req.waqfNumber || req.registrationNumber || 'उपलब्ध नहीं'}
                        </div>
                      </div>
                    </div>

                    {req.note && (
                      <div className="text-xs text-slate-600 bg-amber-50/60 p-3 rounded-xl border border-amber-200/60">
                        <span className="font-bold text-amber-950 mr-1">आवेदक का संदेश:</span>
                        {req.note}
                      </div>
                    )}

                    {/* Pending Request Actions */}
                    {req.status === 'pending' && (
                      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2 border-t border-slate-100">
                        <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                          <Shield className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>
                            स्वीकृत करते ही यह मदरसा लाइव हो जाएगा एवं <strong>{req.applicantEmail}</strong> को एडमिन अधिकार मिल जाएंगे।
                          </span>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-auto">
                          <button
                            onClick={() => handleRejectRequest(req)}
                            disabled={actionLoadingId === req.id}
                            className="px-3.5 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs border border-red-200 transition-colors flex items-center gap-1.5 disabled:opacity-50"
                          >
                            <Ban className="w-3.5 h-3.5" />
                            <span>अस्वीकार करें (Reject)</span>
                          </button>

                          <button
                            onClick={() => handleApproveRequest(req)}
                            disabled={actionLoadingId === req.id}
                            className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md shadow-emerald-700/20 transition-all flex items-center gap-1.5 disabled:opacity-50"
                          >
                            {actionLoadingId === req.id ? (
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            ) : (
                              <CheckCheck className="w-4 h-4" />
                            )}
                            <span>स्वीकृत करें (Approve Mosque & Admin)</span>
                          </button>
                        </div>
                      </div>
                    )}

                    {req.status === 'approved' && (
                      <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-900 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          <span>
                            स्वीकृत किया गया: {req.reviewedAt ? new Date(req.reviewedAt).toLocaleString('hi-IN') : 'सक्रिय'}
                          </span>
                        </div>
                        {req.masjidId && onSelectMasjid && (
                          <button
                            onClick={() => onSelectMasjid(req.masjidId!)}
                            className="text-[11px] font-bold text-emerald-700 hover:underline flex items-center gap-1"
                          >
                            इस मदरसे का डैशबोर्ड खोलें →
                          </button>
                        )}
                      </div>
                    )}

                    {req.status === 'rejected' && (
                      <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-xs text-red-900 flex items-center gap-2">
                        <XCircle className="w-4 h-4 text-red-600 shrink-0" />
                        <span>अस्वीकृत करने का कारण: {req.rejectionReason || 'सत्यापन अधूरा'}</span>
                      </div>
                    )}
                  </div>
                ))}
            </div>
          )}

          {/* Quick Direct Mosque Addition Modal */}
          {showAddMosqueModal && (
            <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
              <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4 my-8">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-emerald-700" />
                    <h3 className="font-extrabold text-slate-900 text-base">
                      सीधे नया मदरसा / मस्जिद जोड़ें
                    </h3>
                  </div>
                  <button
                    onClick={() => setShowAddMosqueModal(false)}
                    className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 flex items-center justify-center font-bold text-xs"
                  >
                    ✕
                  </button>
                </div>

                <form onSubmit={handleDirectCreateMosque} className="space-y-3 text-xs">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">मदरसा / मस्जिद का नाम *</label>
                    <input
                      type="text"
                      required
                      value={directMosqueName}
                      onChange={(e) => setDirectMosqueName(e.target.value)}
                      placeholder="उदा: मदरसा गौसिया नूरुल उलूम"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">जिला (District) *</label>
                      <input
                        type="text"
                        required
                        value={directDistrict}
                        onChange={(e) => setDirectDistrict(e.target.value)}
                        placeholder="उदा: मुजफ्फरपुर / दरभंगा"
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                      />
                    </div>
                    <div>
                      <label className="block font-bold text-slate-700 mb-1">राज्य (State) *</label>
                      <input
                        type="text"
                        required
                        value={directState}
                        onChange={(e) => setDirectState(e.target.value)}
                        placeholder="बिहार"
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">पूरा पता / मोहल्ला</label>
                    <input
                      type="text"
                      value={directAddress}
                      onChange={(e) => setDirectAddress(e.target.value)}
                      placeholder="गाँव/मोहल्ला, पोस्ट, पिन कोड"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                    />
                  </div>

                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 space-y-1">
                    <span className="font-bold block">एडमिन खाता जानकारी (Admin Account Info):</span>
                    <p className="text-[11px] text-amber-800">
                      नीचे दिया गया ईमेल एडमिन के रूप में अधिकृत हो जाएगा। बैंक खाता शुरुआत में रिक्त रहेगा जिसे संबंधित एडमिन बाद में भरेंगे।
                    </p>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">मुतवल्ली / एडमिन का नाम</label>
                    <input
                      type="text"
                      value={directAdminName}
                      onChange={(e) => setDirectAdminName(e.target.value)}
                      placeholder="उदा: हाफिज मोहम्मद रिज़वान"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">एडमिन ईमेल (लॉगिन हेतु) *</label>
                    <input
                      type="email"
                      required
                      value={directAdminEmail}
                      onChange={(e) => setDirectAdminEmail(e.target.value)}
                      placeholder="mutawalli@example.com"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">एडमिन मोबाइल / WhatsApp</label>
                    <input
                      type="tel"
                      value={directAdminPhone}
                      onChange={(e) => setDirectAdminPhone(e.target.value)}
                      placeholder="+91 9876543210"
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                    />
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                    <button
                      type="button"
                      onClick={() => setShowAddMosqueModal(false)}
                      className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 font-bold hover:bg-slate-100"
                    >
                      रद्द करें
                    </button>
                    <button
                      type="submit"
                      disabled={directLoading}
                      className="px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold flex items-center gap-1.5 disabled:opacity-50"
                    >
                      {directLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                      <span>मदरसा जोड़ें एवं सक्रिय करें</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-[11px] font-semibold text-slate-500 uppercase">{t.totalUsers}</span>
              <div className="text-2xl font-black text-slate-900 mt-1">{allUsers.length}</div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-[11px] font-semibold text-slate-500 uppercase">{t.pendingPayments}</span>
              <div className="text-2xl font-black text-amber-600 mt-1">{pendingPaymentsList.length}</div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-[11px] font-semibold text-slate-500 uppercase">Verified Total</span>
              <div className="text-2xl font-black text-emerald-700 mt-1">₹{totalVerifiedAmount}</div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-[11px] font-semibold text-slate-500 uppercase">Monthly Fee / Household</span>
              <div className="text-2xl font-black text-indigo-700 mt-1">₹{masjidDetails.monthlyCommunityFee || 200}</div>
            </div>
          </div>

          {/* DYNAMIC MONTHLY COMMUNITY FEE CONTROLLER (Admin sets fee for all users) */}
          <div className="bg-gradient-to-r from-amber-500/10 via-amber-50/70 to-emerald-50 rounded-2xl p-5 sm:p-6 border-2 border-amber-300 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-amber-200 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500 text-amber-950 flex items-center justify-center font-black shadow-sm">
                  ₹
                </div>
                <div>
                  <h3 className="font-extrabold text-sm sm:text-base text-amber-950">
                    मासिक कम्युनिटी फीस नियंत्रण (Monthly Fee Controller for All Users)
                  </h3>
                  <p className="text-xs text-slate-600">
                    यहाँ से आप इस महीने की फीस राशि तय करें। यह राशि सभी गाँव/कम्युनिटी सदस्यों के स्क्रीन पर तुरंत लागू हो जाएगी।
                  </p>
                </div>
              </div>
              <div className="self-start sm:self-center px-3 py-1 rounded-full bg-amber-200 text-amber-950 text-xs font-black">
                वर्तमान लागू फीस: ₹{monthlyCommunityFee}/माह
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-end">
              {/* Fee amount input */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  इस महीने की फीस राशि (₹)
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 font-extrabold text-slate-400">₹</span>
                  <input
                    id="admin-fee-input"
                    type="number"
                    min="50"
                    step="10"
                    value={monthlyCommunityFee}
                    onChange={(e) => setMonthlyCommunityFee(Number(e.target.value))}
                    className="w-full pl-8 pr-3 py-2 rounded-xl border border-amber-300 font-black text-amber-950 bg-white focus:ring-2 focus:ring-amber-500 text-sm"
                  />
                </div>
                {/* Quick Presets */}
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {[150, 200, 250, 300, 500].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setMonthlyCommunityFee(amt)}
                      className={`px-2 py-0.5 rounded-lg text-[11px] font-bold border transition-colors ${
                        monthlyCommunityFee === amt
                          ? 'bg-amber-500 text-amber-950 border-amber-500'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-amber-100'
                      }`}
                    >
                      ₹{amt}
                    </button>
                  ))}
                </div>
              </div>

              {/* Note / Purpose input */}
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  माह का कारण / विवरण (Reason shown to users)
                </label>
                <input
                  id="admin-fee-note-input"
                  type="text"
                  value={monthlyFeeNote}
                  onChange={(e) => setMonthlyFeeNote(e.target.value)}
                  placeholder="उदा. इमाम साहब की मासिक तनख्वाह एवं मस्जिद बिजली, पानी, सफाई मेंटेनेंस"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white focus:ring-2 focus:ring-emerald-600"
                />
                <p className="text-[10px] text-slate-500 mt-1">
                  💡 यह नोट सभी सदस्यों को उनके होम स्क्रीन पर दिखाई देगा।
                </p>
              </div>
            </div>

            <div className="pt-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-t border-amber-200/70">
              <span className="text-[11px] text-slate-600 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>अपडेट करते ही सभी यूज़र्स के वॉलेट से यह राशि भुगतान हेतु ड्यू (Due) हो जाएगी।</span>
              </span>

              <button
                id="admin-update-fee-btn"
                type="button"
                disabled={updatingMonthlyFee}
                onClick={() => handleDirectUpdateMonthlyFee(monthlyCommunityFee, monthlyFeeNote)}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white font-extrabold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60"
              >
                {updatingMonthlyFee ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>अपडेट हो रहा है...</span>
                  </>
                ) : (
                  <>
                    <Check className="w-4 h-4 text-amber-300" />
                    <span>अपडेट करें एवं सभी यूज़र्स को भेजें (Save & Push)</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Quick Bank Summary Card */}
          <div className="bg-emerald-950 text-white p-5 rounded-2xl border border-emerald-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-amber-300 font-bold text-xs uppercase tracking-wider mb-1">
                <Landmark className="w-4 h-4" />
                <span>Active Bank Settlement Account</span>
              </div>
              {masjidDetails.bankAccountNumber || masjidDetails.bankUpiId ? (
                <>
                  <h4 className="text-base font-extrabold text-white">{masjidDetails.bankAccountName || 'Account Configured'}</h4>
                  <p className="text-xs text-emerald-200 mt-0.5">
                    Bank: <span className="font-semibold">{masjidDetails.bankName || 'N/A'}</span> • A/C: <span className="font-mono">{masjidDetails.bankAccountNumber || 'N/A'}</span> • IFSC: <span className="font-mono">{masjidDetails.bankIfsc || 'N/A'}</span>
                  </p>
                  <p className="text-xs text-emerald-300 font-mono mt-0.5">
                    UPI ID: {masjidDetails.bankUpiId || 'Not set'}
                  </p>
                </>
              ) : (
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-amber-300">
                    ⚠️ बैंक खाता एवं UPI अभी सेट नहीं किया गया है (Blank / Not Set)
                  </h4>
                  <p className="text-xs text-emerald-200">
                    मदरसे का बैंक खाता और UPI आईडी अभी खाली है। दान/फीस प्राप्त करने के लिए नीचे दिए बटन पर क्लिक करके खाता विवरण भरें।
                  </p>
                </div>
              )}
            </div>
            <button
              onClick={() => setActiveTab('bank')}
              className="px-4 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-amber-950 font-black text-xs self-start sm:self-center transition-colors shadow-sm cursor-pointer"
            >
              {masjidDetails.bankAccountNumber || masjidDetails.bankUpiId ? 'Edit Bank Details' : '+ Add Bank & UPI Details'}
            </button>
          </div>
        </div>
      )}

      {/* TAB 2: PAYMENT VERIFICATIONS */}
      {activeTab === 'payments' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-sm sm:text-base text-slate-900">
                Direct Bank Deposit Verifications
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Donors transfer funds to your Bank/UPI. Verify the 12-digit UTR in your bank statement and credit their wallet.
              </p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 self-start sm:self-auto">
              {pendingPaymentsList.length} Pending
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {allPayments.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                No payment requests recorded yet.
              </div>
            ) : (
              allPayments.map((payment) => (
                <div
                  key={payment.id}
                  className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-base font-black text-slate-900">₹{payment.amount}</span>
                      <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-700">
                        {payment.provider}
                      </span>
                      {payment.status === 'verified' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          Verified & Credited
                        </span>
                      )}
                      {payment.status === 'pending' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-900">
                          Pending Confirmation
                        </span>
                      )}
                      {payment.status === 'rejected' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-800">
                          Rejected
                        </span>
                      )}
                    </div>

                    <div className="text-xs text-slate-600">
                      Donor: <span className="font-semibold text-slate-900">{payment.userName || 'User'}</span> ({payment.userEmail})
                    </div>

                    <div className="text-xs font-mono text-emerald-800">
                      Bank Ref / UTR: <span className="font-bold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">{payment.providerTransactionId || 'N/A'}</span>
                    </div>

                    <div className="text-[10px] text-slate-400">
                      {payment.createdAt ? new Date(payment.createdAt).toLocaleString() : 'Recent'}
                    </div>
                  </div>

                  {payment.status === 'pending' && (
                    <div className="flex items-center gap-2 self-end sm:self-center">
                      <button
                        onClick={() => handleVerifyPayment(payment)}
                        disabled={verifyingId === payment.id}
                        className="px-3.5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-sm flex items-center gap-1 transition-all disabled:opacity-50"
                      >
                        {verifyingId === payment.id ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <Check className="w-3.5 h-3.5" />
                        )}
                        <span>Confirm & Credit Wallet</span>
                      </button>

                      <button
                        onClick={() => handleRejectPayment(payment.id)}
                        disabled={verifyingId === payment.id}
                        className="px-3 py-2 rounded-xl bg-slate-100 hover:bg-red-50 text-slate-700 hover:text-red-700 font-bold text-xs transition-colors disabled:opacity-50"
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* TAB 3: ADMIN BANK & MONTHLY FEE SETUP */}
      {activeTab === 'bank' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm max-w-2xl space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Landmark className="w-5 h-5 text-emerald-700" />
              <h3 className="font-bold text-base text-slate-900">
                Official Admin Bank & UPI Account Configuration
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              When community members top-up their wallet or pay their monthly fee, they transfer directly to these bank credentials.
            </p>
          </div>

          <form onSubmit={handleSaveBankConfig} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Account Holder Name (Trust / Madrasa)</label>
              <input
                type="text"
                required
                value={bankAccountName}
                onChange={(e) => setBankAccountName(e.target.value)}
                placeholder="e.g. Madrasa Tegiya Talim Al Islam Trust"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30 text-xs"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Bank Name</label>
                <input
                  type="text"
                  required
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  placeholder="e.g. State Bank of India / HDFC Bank"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30 text-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Bank Account Number</label>
                <input
                  type="text"
                  required
                  value={bankAccountNumber}
                  onChange={(e) => setBankAccountNumber(e.target.value)}
                  placeholder="e.g. 389201928374"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono focus:ring-2 focus:ring-emerald-600/30 text-xs"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-bold text-slate-700 mb-1">IFSC Code</label>
                <input
                  type="text"
                  required
                  value={bankIfsc}
                  onChange={(e) => setBankIfsc(e.target.value)}
                  placeholder="e.g. SBIN0002938"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono uppercase focus:ring-2 focus:ring-emerald-600/30 text-xs"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Official UPI ID (VPA)</label>
                <input
                  type="text"
                  required
                  value={bankUpiId}
                  onChange={(e) => setBankUpiId(e.target.value)}
                  placeholder="e.g. tegiya.madrasa@upi or 9876543210@paytm"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 font-mono focus:ring-2 focus:ring-emerald-600/30 text-xs"
                />
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100">
              <label className="block font-bold text-slate-800 mb-1">
                Fixed Monthly Community Fee (मासिक फीस प्रति घर/सदस्य)
              </label>
              <p className="text-[11px] text-slate-500 mb-2">
                This amount is designated for mosque maintenance and Imam's monthly salary. Community members can pay this in 1-click from their wallet.
              </p>
              <div className="relative max-w-xs">
                <span className="absolute left-3 top-2.5 font-bold text-slate-400">₹</span>
                <input
                  type="number"
                  min="50"
                  step="50"
                  value={monthlyCommunityFee}
                  onChange={(e) => setMonthlyCommunityFee(Number(e.target.value))}
                  className="w-full pl-7 pr-3 py-2 rounded-xl border border-slate-300 font-bold text-emerald-800 focus:ring-2 focus:ring-emerald-600/30 text-xs"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={savingBank}
              className="py-3 px-6 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition-colors flex items-center gap-2"
            >
              {savingBank ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              <span>Save Admin Bank & Community Fee</span>
            </button>
          </form>
        </div>
      )}

      {/* TAB 4: MOSQUE PHOTO & DETAILS */}
      {activeTab === 'madrasa' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm max-w-2xl space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Building2 className="w-5 h-5 text-emerald-700" />
              <h3 className="font-bold text-base text-slate-900">
                Mosque Photo Upload & Campus Profile
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              Upload your mosque's authentic photograph. It will be displayed in 16:9 on the home screen for all members.
            </p>
          </div>

          {/* Photo Preview and Upload */}
          <div className="p-4 rounded-2xl bg-slate-900 text-white space-y-3">
            <label className="block text-xs font-bold text-slate-300">
              Current Mosque Photo (16:9 Aspect Ratio)
            </label>
            <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center">
              {photoPreview ? (
                <img
                  src={photoPreview}
                  alt="Mosque Preview"
                  className="w-full h-full object-contain"
                />
              ) : (
                <div className="text-slate-500 text-xs flex flex-col items-center gap-1">
                  <ImageIcon className="w-8 h-8 opacity-40" />
                  <span>No photo selected</span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-3 pt-2">
              <label className="cursor-pointer px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-sm">
                <Upload className="w-4 h-4" />
                <span>Choose Photo from Device / Gallery</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>

              {photoPreview !== '/madrasa_tegiya.jpg' && (
                <button
                  type="button"
                  onClick={() => {
                    setPhotoPreview('/madrasa_tegiya.jpg');
                    setPhotoUrl('/madrasa_tegiya.jpg');
                  }}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  Reset to Default
                </button>
              )}
            </div>
          </div>

          <form onSubmit={handleSaveMadrasa} className="space-y-4 text-xs">
            <div>
              <label className="block font-bold text-slate-700 mb-1">Institution Name</label>
              <input
                type="text"
                value={madrasaName}
                onChange={(e) => setMadrasaName(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30 text-xs"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Address</label>
              <input
                type="text"
                value={madrasaAddress}
                onChange={(e) => setMadrasaAddress(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30 text-xs"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Description</label>
              <textarea
                rows={3}
                value={madrasaDesc}
                onChange={(e) => setMadrasaDesc(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30 text-xs"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">Contact Phone</label>
              <input
                type="text"
                value={madrasaContact}
                onChange={(e) => setMadrasaContact(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30 text-xs"
              />
            </div>

            {/* Admin Support & Contact Details (Shown in Member Support Screen) */}
            <div className="pt-4 border-t border-slate-200 space-y-3">
              <div className="flex items-center gap-2">
                <Headphones className="w-4 h-4 text-emerald-700" />
                <h4 className="font-extrabold text-slate-900 text-xs">
                  एडमिन संपर्क विवरण (Admin Contact Info shown in Support Helpdesk)
                </h4>
              </div>
              <p className="text-[11px] text-slate-500">
                ये विवरण सीधे यूज़र्स के "Support / सहायता" टैब में दिखाई देंगे ताकि किसी समस्या पर वे आपको सीधे कॉल या व्हाट्सएप कर सकें।
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Admin / Mutawalli Name</label>
                  <input
                    type="text"
                    value={adminName}
                    onChange={(e) => setAdminName(e.target.value)}
                    placeholder="e.g. Hafez Md. Rizwan"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Admin Calling Number</label>
                  <input
                    type="text"
                    value={adminPhone}
                    onChange={(e) => setAdminPhone(e.target.value)}
                    placeholder="e.g. +91 9876543210"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30 text-xs"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">WhatsApp Direct Number</label>
                  <input
                    type="text"
                    value={adminWhatsapp}
                    onChange={(e) => setAdminWhatsapp(e.target.value)}
                    placeholder="e.g. +91 9876543210"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Admin Email ID</label>
                  <input
                    type="email"
                    value={adminEmail}
                    onChange={(e) => setAdminEmail(e.target.value)}
                    placeholder="e.g. rockybo09876@gmail.com"
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30 text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Support Availability / Office Timing</label>
                <input
                  type="text"
                  value={adminSupportTiming}
                  onChange={(e) => setAdminSupportTiming(e.target.value)}
                  placeholder="e.g. सुबह 8:00 AM से रात 9:00 PM (जुमा को 2:00 PM के बाद)"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30 text-xs"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={savingMadrasa}
              className="py-3 px-6 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition-colors flex items-center gap-2"
            >
              {savingMadrasa ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              <span>Save Mosque Photo, Details & Admin Contacts</span>
            </button>
          </form>
        </div>
      )}

      {/* TAB 5: CAMPAIGNS & ANNOUNCEMENTS (ADMIN ONLY) */}
      {activeTab === 'ads' && (
        <div className="space-y-6 max-w-3xl">
          {/* Create New Campaign Form */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center gap-2">
              <Megaphone className="w-5 h-5 text-amber-600" />
              <h3 className="font-bold text-base text-slate-900">
                Launch Community Campaign / Announcement
              </h3>
            </div>
            <p className="text-xs text-slate-500">
              Only authorized admin can post advertisements (e.g. 12 Rabi-ul-Awwal Appeal, Mosque Renovation, Eid Ration).
            </p>

            <form onSubmit={handleCreateAd} className="space-y-3 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Campaign Title</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. 12 रबी-उल-अव्वल चंदा अपील / 12 Rabi-ul-Awwal Donation Drive"
                    value={newAdTitle}
                    onChange={(e) => setNewAdTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Category</label>
                  <select
                    value={newAdCategory}
                    onChange={(e: any) => setNewAdCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30"
                  >
                    <option value="rabi_ul_awwal">12 Rabi-ul-Awwal Fund (12 रबी-उल-अव्वल)</option>
                    <option value="renovation">Mosque Renovation (मस्जिद मरम्मत एवं निर्माण)</option>
                    <option value="ramadan">Ramadan & Iftar Support</option>
                    <option value="general">General Community Notice</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Target Amount (₹)</label>
                <input
                  type="number"
                  placeholder="e.g. 50000"
                  value={newAdTarget}
                  onChange={(e) => setNewAdTarget(e.target.value)}
                  className="w-full max-w-xs px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">Announcement Details / Appeal Message</label>
                <textarea
                  rows={3}
                  required
                  placeholder="Describe the objective and encourage community members to donate through the app..."
                  value={newAdDesc}
                  onChange={(e) => setNewAdDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 focus:ring-2 focus:ring-emerald-600/30"
                />
              </div>

              <button
                type="submit"
                disabled={creatingAd}
                className="py-2.5 px-5 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-colors"
              >
                {creatingAd ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                <span>Post Campaign on Home Screen</span>
              </button>
            </form>
          </div>

          {/* Active Campaigns List */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-3">
            <h4 className="font-bold text-sm text-slate-900">Active Community Advertisements</h4>

            {allAds.length === 0 ? (
              <p className="text-xs text-slate-400 py-4">No active advertisements created yet.</p>
            ) : (
              <div className="space-y-3">
                {allAds.map((ad) => (
                  <div
                    key={ad.id}
                    className="p-4 rounded-2xl bg-amber-50/60 border border-amber-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-amber-200 text-amber-900">
                          {ad.category || 'Announcement'}
                        </span>
                        <h5 className="font-bold text-sm text-slate-900">{ad.title}</h5>
                      </div>
                      <p className="text-xs text-slate-600 mt-1">{ad.description}</p>
                      {ad.targetAmount && (
                        <p className="text-[11px] font-semibold text-emerald-800 mt-0.5">
                          Target Fund: ₹{ad.targetAmount}
                        </p>
                      )}
                    </div>

                    <button
                      onClick={() => handleDeleteAd(ad.id)}
                      className="p-2 rounded-xl bg-red-100 hover:bg-red-200 text-red-800 text-xs font-bold shrink-0 self-end sm:self-center flex items-center gap-1 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 6: USERS */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h3 className="font-bold text-sm sm:text-base text-slate-900">Registered Community Users</h3>
            <div className="relative max-w-xs w-full">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by name or email..."
                className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30"
              />
            </div>
          </div>

          <div className="divide-y divide-slate-100">
            {allUsers
              .filter(
                (u) =>
                  u.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
                  u.email?.toLowerCase().includes(searchQuery.toLowerCase())
              )
              .map((u) => (
                <div key={u.uid} className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">{u.name}</h4>
                    <p className="text-xs text-slate-500">{u.email}</p>
                    <p className="text-[10px] text-slate-400">UID: {u.uid}</p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto text-xs">
                    <span className="px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 font-bold border border-emerald-200">
                      Balance: ₹{u.walletBalance || 0}
                    </span>
                    <span className="px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 font-semibold">
                      Monthly: {u.autoCharity ? `₹${u.monthlyCharity} (Active)` : 'Disabled'}
                    </span>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* TAB 7: SUPPORT TICKETS */}
      {activeTab === 'support' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-bold text-sm sm:text-base text-slate-900">Member Helpdesk Tickets</h3>
            <span className="text-xs text-slate-500">{allSupport.length} tickets</span>
          </div>

          <div className="divide-y divide-slate-100">
            {allSupport.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                No support tickets found.
              </div>
            ) : (
              allSupport.map((ticket) => (
                <div key={ticket.id} className="p-4 sm:p-5 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900">{ticket.subject}</span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            ticket.status === 'Resolved'
                              ? 'bg-emerald-100 text-emerald-800'
                              : ticket.status === 'In Progress'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {ticket.status}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">
                        By: <span className="font-semibold">{ticket.userName}</span> ({ticket.userEmail})
                      </p>
                    </div>
                    <span className="text-[10px] text-slate-400 self-start sm:self-auto">
                      {ticket.createdAt ? new Date(ticket.createdAt).toLocaleString() : ''}
                    </span>
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-700 leading-relaxed border border-slate-200/70">
                    {ticket.message}
                  </div>

                  {ticket.reply && (
                    <div className="p-3 bg-emerald-50 rounded-xl text-xs text-emerald-900 border border-emerald-200">
                      <span className="font-bold block mb-1">Official Administration Reply:</span>
                      <p>{ticket.reply}</p>
                    </div>
                  )}

                  {replyTicketId === ticket.id ? (
                    <div className="pt-2 space-y-2">
                      <textarea
                        rows={2}
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        placeholder="Write official response..."
                        className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30"
                      />
                      <div className="flex items-center justify-between">
                        <select
                          value={replyStatus}
                          onChange={(e: any) => setReplyStatus(e.target.value)}
                          className="px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs"
                        >
                          <option value="In Progress">In Progress</option>
                          <option value="Resolved">Resolved</option>
                        </select>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => setReplyTicketId(null)}
                            className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-600 text-xs font-bold"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => handleReplyTicket(ticket.id)}
                            className="px-3.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold"
                          >
                            Send Reply
                          </button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <button
                      onClick={() => {
                        setReplyTicketId(ticket.id);
                        setReplyText(ticket.reply || '');
                        setReplyStatus(ticket.status || 'Resolved');
                      }}
                      className="text-xs font-bold text-emerald-700 hover:text-emerald-800"
                    >
                      {ticket.reply ? 'Edit Reply' : 'Reply to Member'}
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

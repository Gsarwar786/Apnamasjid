import React, { useState } from 'react';
import { collection, addDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import { UserProfile, SupportedLanguage, PaymentRequest, MasjidDetails } from '../types';
import { translations } from '../i18n';
import {
  Wallet as WalletIcon,
  PlusCircle,
  Heart,
  History,
  ShieldCheck,
  QrCode,
  Copy,
  Check,
  AlertTriangle,
  Clock,
  CheckCircle2,
  XCircle,
  X,
  Loader2,
  Landmark,
  ExternalLink,
} from 'lucide-react';

interface WalletViewProps {
  userProfile: UserProfile | null;
  currentLang: SupportedLanguage;
  payments: PaymentRequest[];
  masjidDetails: MasjidDetails;
  onNavigate: (tab: string) => void;
  onRefreshProfile?: () => void;
}

export const WalletView: React.FC<WalletViewProps> = ({
  userProfile,
  currentLang,
  payments,
  masjidDetails,
  onNavigate,
}) => {
  const t = translations[currentLang];
  const isRtl = currentLang === 'ur' || currentLang === 'ar';

  const [isAddMoneyOpen, setIsAddMoneyOpen] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState<number>(masjidDetails.monthlyCommunityFee || 200);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [utrNumber, setUtrNumber] = useState('');
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [copiedAcc, setCopiedAcc] = useState(false);
  const [copiedIfsc, setCopiedIfsc] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  // Admin Bank & UPI Details
  const authorizedUpiId = masjidDetails.bankUpiId || '';
  const payeeName = masjidDetails.bankAccountName || '';
  const bankName = masjidDetails.bankName || '';
  const bankAccountNumber = masjidDetails.bankAccountNumber || '';
  const bankIfsc = masjidDetails.bankIfsc || '';
  const hasBankOrUpi = Boolean(authorizedUpiId || bankAccountNumber);

  const effectiveAmount = customAmount ? parseFloat(customAmount) : selectedAmount;

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(authorizedUpiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleCopyAcc = () => {
    navigator.clipboard.writeText(bankAccountNumber);
    setCopiedAcc(true);
    setTimeout(() => setCopiedAcc(false), 2000);
  };

  const handleCopyIfsc = () => {
    navigator.clipboard.writeText(bankIfsc);
    setCopiedIfsc(true);
    setTimeout(() => setCopiedIfsc(false), 2000);
  };

  const handleSelectPreset = (amt: number) => {
    setSelectedAmount(amt);
    setCustomAmount('');
  };

  const handleSubmitPaymentRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSubmissionSuccess(null);

    if (!userProfile) return;

    if (!effectiveAmount || effectiveAmount <= 0 || isNaN(effectiveAmount)) {
      setFormError('Please enter a valid amount greater than ₹0.');
      return;
    }

    const cleanUtr = utrNumber.trim();
    if (!cleanUtr || cleanUtr.length < 6) {
      setFormError('Please enter a valid Bank / UPI Reference or UTR number (at least 6 digits).');
      return;
    }

    try {
      setSubmitting(true);
      const paymentPath = 'payments';

      // Store in payments collection with strictly 'pending' status
      await addDoc(collection(db, paymentPath), {
        uid: userProfile.uid,
        amount: Number(effectiveAmount),
        provider: 'UPI / Direct Bank Transfer',
        providerTransactionId: cleanUtr,
        status: 'pending',
        userEmail: userProfile.email,
        userName: userProfile.name,
        createdAt: new Date().toISOString(),
      });

      setSubmissionSuccess(
        'Payment reference submitted! Admin will verify the deposit in their bank account and credit your wallet shortly.'
      );
      setUtrNumber('');
      setTimeout(() => {
        setIsAddMoneyOpen(false);
        setSubmissionSuccess(null);
      }, 3500);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, 'payments');
    } finally {
      setSubmitting(false);
    }
  };

  // QR image URL for UPI payment
  const upiQrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=upi://pay?pa=${encodeURIComponent(
    authorizedUpiId
  )}%26pn=${encodeURIComponent(payeeName)}%26am=${effectiveAmount || 200}%26cu=INR`;

  return (
    <div className="space-y-6 pb-20 md:pb-8" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Wallet Balance Hero Card */}
      <div className="bg-gradient-to-br from-emerald-900 via-teal-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-emerald-700/50 relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center justify-between gap-4 mb-3">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-emerald-800/80 text-amber-300">
                <WalletIcon className="w-5 h-5" />
              </div>
              <span className="text-xs sm:text-sm font-semibold uppercase tracking-wider text-emerald-200">
                {t.walletBalance}
              </span>
            </div>
            <span className="px-3 py-1 rounded-full bg-emerald-800/60 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
              Personal Secure Wallet
            </span>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-4 pt-1 pb-4">
            <div>
              <div className="text-3xl sm:text-5xl font-black text-white tracking-tight flex items-baseline gap-1">
                <span className="text-2xl sm:text-3xl text-amber-400 font-serif">₹</span>
                <span>{userProfile?.walletBalance ?? 0}</span>
                <span className="text-xs sm:text-sm font-normal text-emerald-300 ml-1">INR</span>
              </div>
              <p className="text-xs text-emerald-200 mt-1">
                {userProfile?.autoCharity ? (
                  <span className="text-amber-300 font-semibold">
                    ✓ Auto-Charity: ₹{userProfile.monthlyCharity}/month
                  </span>
                ) : (
                  <span>Ready for Masjid donation, fee, or relief charity</span>
                )}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                id="wallet-add-money-btn"
                onClick={() => setIsAddMoneyOpen(true)}
                className="px-5 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-amber-950 font-extrabold text-xs sm:text-sm shadow-lg shadow-amber-500/20 transition-all flex items-center gap-2 cursor-pointer"
              >
                <PlusCircle className="w-4 h-4" />
                <span>{t.addMoney}</span>
              </button>

              <button
                id="wallet-donate-now-btn"
                onClick={() => onNavigate('charity')}
                className="px-4 py-3 rounded-2xl bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs sm:text-sm border border-emerald-500/40 transition-colors flex items-center gap-1.5"
              >
                <Heart className="w-4 h-4" />
                <span>{t.donateCharity}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Admin Bank & Account Transparency Card */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm space-y-3">
        <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
          <Landmark className="w-4 h-4 text-emerald-600" />
          <span>आधिकारिक मस्जिद एवं मदरसा बैंक विवरण (Official Admin Settlement Account)</span>
        </div>
        {hasBankOrUpi ? (
          <>
            <p className="text-xs text-slate-500">
              वॉलेट टॉप-अप और चंदा सीधे मदरसे के इस रजिस्टर्ड बैंक खाते में ट्रांसफर होता है:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs pt-1">
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Account Holder</span>
                <span className="font-extrabold text-slate-900 mt-0.5 block">{payeeName || 'Not Specified'}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Bank Name</span>
                <span className="font-extrabold text-slate-900 mt-0.5 block">{bankName || 'Not Specified'}</span>
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Account Number</span>
                  <span className="font-mono font-extrabold text-slate-900 mt-0.5 block">{bankAccountNumber || 'Not Set'}</span>
                </div>
                {bankAccountNumber && (
                  <button onClick={handleCopyAcc} className="text-emerald-700 hover:text-emerald-900 p-1">
                    {copiedAcc ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                )}
              </div>

              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">IFSC / UPI</span>
                  <span className="font-mono font-extrabold text-slate-900 mt-0.5 block">{bankIfsc || authorizedUpiId || 'Not Set'}</span>
                </div>
                {(bankIfsc || authorizedUpiId) && (
                  <button onClick={handleCopyIfsc} className="text-emerald-700 hover:text-emerald-900 p-1">
                    {copiedIfsc ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                )}
              </div>
            </div>
          </>
        ) : (
          <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200/90 text-amber-950 text-xs flex items-start gap-2.5">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div>
              <h5 className="font-extrabold text-amber-900 text-xs">
                बैंक खाता एवं UPI अभी एडमिन द्वारा अपडेट नहीं किया गया है
              </h5>
              <p className="text-[11px] text-amber-800 mt-0.5">
                इस मदरसे के व्यवस्थापक (Admin) ने अभी तक अपना आधिकारिक बैंक खाता या UPI नहीं जोड़ा है। जैसे ही एडमिन इसे दर्ज करेंगे, आप यहाँ से सीधे बैंक ट्रांसफर कर सकेंगे।
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Security notice */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex items-start gap-4">
        <div className="p-3 rounded-xl bg-emerald-50 text-emerald-800 shrink-0">
          <ShieldCheck className="w-6 h-6" />
        </div>
        <div className="space-y-1 text-start">
          <h4 className="text-sm font-bold text-slate-900">{t.securityNoticeTitle}</h4>
          <p className="text-xs text-slate-600 leading-relaxed">
            {t.securityNoticeDesc}
          </p>
        </div>
      </div>

      {/* User's Recent Payment Requests */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-700" />
            <h3 className="font-bold text-sm sm:text-base text-slate-900">
              Recent Bank / UPI Top-up Requests
            </h3>
          </div>
          <span className="text-xs text-slate-500 font-medium">
            {payments.length} {payments.length === 1 ? 'request' : 'requests'}
          </span>
        </div>

        <div className="p-4">
          {payments.length === 0 ? (
            <div className="text-center py-8 text-slate-500 text-xs">
              <p>No recent payment requests logged.</p>
              <p className="text-slate-400 mt-1">
                Click "+ Add Money" to transfer funds to the Admin Bank and top-up your wallet.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {payments.map((p) => (
                <div
                  key={p.id}
                  className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900">₹{p.amount}</span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-slate-200 text-slate-700 font-medium">
                        {p.provider}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Ref / UTR: <span className="font-mono font-medium text-slate-700">{p.providerTransactionId || 'N/A'}</span>
                    </p>
                    <p className="text-[10px] text-slate-400">
                      {p.createdAt ? new Date(p.createdAt).toLocaleString() : 'Recent'}
                    </p>
                  </div>

                  <div className="self-end sm:self-center">
                    {p.status === 'verified' && (
                      <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Verified & Credited
                      </span>
                    )}
                    {p.status === 'pending' && (
                      <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-900 text-xs font-bold flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-amber-600" />
                        Pending Verification
                      </span>
                    )}
                    {p.status === 'rejected' && (
                      <span className="px-2.5 py-1 rounded-full bg-red-100 text-red-800 text-xs font-bold flex items-center gap-1">
                        <XCircle className="w-3.5 h-3.5 text-red-600" />
                        Rejected
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Add Money Modal (Direct Bank & UPI Deposit) */}
      {isAddMoneyOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-emerald-100 overflow-hidden relative my-6">
            {/* Modal Header */}
            <div className="bg-emerald-900 text-white p-4 sm:p-5 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base sm:text-lg flex items-center gap-2">
                  <PlusCircle className="w-5 h-5 text-amber-400" />
                  <span>{t.addMoney} — Admin Bank / UPI Transfer</span>
                </h3>
                <p className="text-xs text-emerald-200 mt-0.5">
                  Transfer directly to the Admin Bank account, then submit your UTR reference.
                </p>
              </div>
              <button
                id="close-add-money-modal-btn"
                onClick={() => setIsAddMoneyOpen(false)}
                className="p-1 rounded-lg text-emerald-200 hover:text-white hover:bg-emerald-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content Form */}
            <form onSubmit={handleSubmitPaymentRequest} className="p-5 sm:p-6 space-y-4">
              {formError && (
                <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {submissionSuccess && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
                  <span>{submissionSuccess}</span>
                </div>
              )}

              {/* Step 1: Select Amount */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-2">
                  1. {t.selectAmount}
                </label>
                <div className="grid grid-cols-4 gap-2 mb-2.5">
                  {[100, 200, 500, 1000].map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => handleSelectPreset(amt)}
                      className={`py-2 px-3 rounded-xl text-xs font-bold border transition-colors ${
                        selectedAmount === amt && !customAmount
                          ? 'bg-emerald-700 text-white border-emerald-700 shadow-sm'
                          : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      ₹{amt}
                    </button>
                  ))}
                </div>

                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">₹</span>
                  <input
                    id="custom-amount-input"
                    type="number"
                    min="10"
                    placeholder="Or enter custom amount in ₹"
                    value={customAmount}
                    onChange={(e) => {
                      setCustomAmount(e.target.value);
                    }}
                    className="w-full pl-7 pr-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                  />
                </div>
              </div>

              {/* Step 2: Bank & UPI Credentials */}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
                <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Landmark className="w-4 h-4 text-emerald-700" />
                  <span>2. Admin Bank & UPI Payment Options</span>
                </div>

                {hasBankOrUpi ? (
                  <>
                    {/* UPI QR & VPA */}
                    {authorizedUpiId && (
                      <div className="bg-white p-3 rounded-xl border border-slate-200 text-center space-y-2">
                        <div className="inline-block p-1.5 bg-white rounded-lg shadow-sm border border-slate-100">
                          <img
                            src={upiQrUrl}
                            alt="UPI Payment QR Code"
                            className="w-32 h-32 mx-auto object-contain"
                          />
                        </div>
                        <div className="flex items-center justify-center gap-2">
                          <div className="px-2.5 py-1 rounded bg-slate-100 text-xs font-mono font-bold text-emerald-950">
                            {authorizedUpiId}
                          </div>
                          <button
                            type="button"
                            onClick={handleCopyUpi}
                            className="px-2.5 py-1 rounded bg-emerald-100 text-emerald-800 hover:bg-emerald-200 text-xs font-bold flex items-center gap-1 transition-colors"
                          >
                            {copiedUpi ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                            <span>{copiedUpi ? 'Copied' : 'Copy'}</span>
                          </button>
                        </div>
                      </div>
                    )}

                    {/* Direct Bank Account Details */}
                    {bankAccountNumber && (
                      <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-2 text-xs">
                        <span className="font-bold text-slate-800 block">Direct Bank Transfer (NEFT/IMPS):</span>
                        <div className="space-y-1 text-slate-600">
                          {payeeName && (
                            <div className="flex justify-between">
                              <span className="text-slate-400">Beneficiary:</span>
                              <span className="font-bold text-slate-800">{payeeName}</span>
                            </div>
                          )}
                          <div className="flex justify-between items-center">
                            <span className="text-slate-400">Account No:</span>
                            <div className="flex items-center gap-1 font-mono font-bold text-slate-900">
                              <span>{bankAccountNumber}</span>
                              <button type="button" onClick={handleCopyAcc} className="text-emerald-700">
                                {copiedAcc ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                              </button>
                            </div>
                          </div>
                          {bankIfsc && (
                            <div className="flex justify-between items-center">
                              <span className="text-slate-400">IFSC Code:</span>
                              <div className="flex items-center gap-1 font-mono font-bold text-slate-900">
                                <span>{bankIfsc}</span>
                                <button type="button" onClick={handleCopyIfsc} className="text-emerald-700">
                                  {copiedIfsc ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                                </button>
                              </div>
                            </div>
                          )}
                          {bankName && (
                            <div className="flex justify-between">
                              <span className="text-slate-400">Bank:</span>
                              <span className="font-semibold text-slate-700">{bankName}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 text-xs flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold block">बैंक / UPI विवरण अभी सेट नहीं है</span>
                      <span>एडमिन द्वारा बैंक खाता और UPI आईडी अपडेट किया जा रहा है। अपडेट होते ही यहाँ QR कोड और बैंक खाता प्रदर्शित होगा।</span>
                    </div>
                  </div>
                )}
              </div>

              {/* Step 3: Enter Reference / UTR Number */}
              <div>
                <label className="block text-xs font-bold text-slate-800 mb-1">
                  3. Enter UPI Ref / UTR / Transaction ID
                </label>
                <input
                  id="utr-number-input"
                  type="text"
                  required
                  placeholder="e.g. 423871928371 or UPI/IMPS ref from bank"
                  value={utrNumber}
                  onChange={(e) => setUtrNumber(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 font-mono text-xs focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  Found in your GPay / PhonePe / Paytm / Bank SMS receipt after making the transfer.
                </p>
              </div>

              {/* Submit Button */}
              <button
                id="submit-payment-request-btn"
                type="submit"
                disabled={submitting}
                className="w-full py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {submitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Submitting Reference...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Submit for Admin Verification</span>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

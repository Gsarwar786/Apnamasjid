import React from 'react';
import { SupportedLanguage } from '../types';
import { translations } from '../i18n';
import { Home, Wallet, HeartHandshake, History, User, Headphones } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  currentLang: SupportedLanguage;
  onTabChange: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  currentLang,
  onTabChange,
}) => {
  const t = translations[currentLang];
  const isRtl = currentLang === 'ur' || currentLang === 'ar';

  const navItems = [
    { id: 'home', label: t.navHome, icon: Home, emoji: '🏠' },
    { id: 'wallet', label: t.navWallet, icon: Wallet, emoji: '💰' },
    { id: 'charity', label: t.navCharity, icon: HeartHandshake, emoji: '🤲' },
    { id: 'history', label: t.navHistory, icon: History, emoji: '📜' },
    { id: 'profile', label: t.navProfile, icon: User, emoji: '👤' },
    { id: 'support', label: t.navSupport, icon: Headphones, emoji: '📞' },
  ];

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur border-t border-emerald-100 shadow-lg px-2 py-1.5 md:hidden"
      dir={isRtl ? 'rtl' : 'ltr'}
    >
      <div className="flex items-center justify-around max-w-lg mx-auto">
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              id={`bottom-nav-${item.id}`}
              onClick={() => onTabChange(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all ${
                isActive
                  ? 'text-emerald-700 font-bold scale-105'
                  : 'text-slate-500 hover:text-emerald-600 font-medium'
              }`}
            >
              <div className={`p-1 rounded-lg ${isActive ? 'bg-emerald-50 text-emerald-700' : ''}`}>
                <Icon className={`w-5 h-5 ${isActive ? 'stroke-[2.5]' : 'stroke-[1.8]'}`} />
              </div>
              <span className="text-[10px] leading-tight tracking-tight mt-0.5 truncate max-w-[54px]">
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

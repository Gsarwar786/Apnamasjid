import React from 'react';
import { SupportedLanguage } from '../types';
import { translations } from '../i18n';
import { ShieldCheck, Lock, Landmark, Heart, Globe2 } from 'lucide-react';

interface UnauthenticatedHomeProps {
  currentLang: SupportedLanguage;
  onLanguageChange: (lang: SupportedLanguage) => void;
  onOpenAuth?: (initialMode?: 'login' | 'signup', initialRole?: 'user' | 'admin') => void;
  onOpenLogin?: (role?: 'user' | 'admin') => void;
  onOpenSignUp?: () => void;
  onOpenLegal?: (type: 'privacy' | 'terms' | 'refund' | 'contact') => void;
}

export const UnauthenticatedHome: React.FC<UnauthenticatedHomeProps> = ({
  currentLang,
  onLanguageChange,
  onOpenAuth,
  onOpenLogin,
  onOpenSignUp,
  onOpenLegal,
}) => {
  const t = translations[currentLang];
  const isRtl = currentLang === 'ur' || currentLang === 'ar';

  const triggerLogin = (role: 'user' | 'admin' = 'user') => {
    if (onOpenLogin) onOpenLogin(role);
    else if (onOpenAuth) onOpenAuth('login', role);
  };

  const triggerSignUp = () => {
    if (onOpenSignUp) onOpenSignUp();
    else if (onOpenAuth) onOpenAuth('signup', 'user');
  };

  const handleLegal = (type: 'privacy' | 'terms' | 'refund' | 'contact') => {
    if (onOpenLegal) onOpenLegal(type);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Top Header */}
      <header className="bg-emerald-900 text-white shadow-md border-b border-emerald-800/60 sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <span className="text-2xl" role="img" aria-label="mosque">🕌</span>
            <div>
              <span className="font-bold text-lg tracking-wide text-white block leading-tight">{t.appName}</span>
              <span className="text-[11px] text-emerald-200/90 hidden sm:block tracking-wider uppercase">
                {t.tagline}
              </span>
            </div>
          </div>

          {/* Right Header Actions */}
          <div className="flex items-center gap-2">
            <button
              id="header-login-btn"
              onClick={triggerLogin}
              className="px-3.5 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 transition-colors"
            >
              <Lock className="w-3.5 h-3.5 text-emerald-200" />
              <span>{t.login}</span>
            </button>

            {/* Language Switcher */}
            <div className="inline-flex rounded-lg bg-emerald-950/70 p-0.5 border border-emerald-700/50">
              {(['en', 'hi', 'ur', 'ar'] as SupportedLanguage[]).map((lang) => {
                const labels: Record<SupportedLanguage, string> = {
                  en: 'EN',
                  hi: 'हिंदी',
                  ur: 'اردو',
                  ar: 'العربية',
                };
                return (
                  <button
                    key={lang}
                    id={`lang-btn-${lang}`}
                    onClick={() => onLanguageChange(lang)}
                    className={`px-2 py-1 text-xs font-medium rounded-md transition-colors ${
                      currentLang === lang
                        ? 'bg-emerald-600 text-white shadow-sm font-semibold'
                        : 'text-emerald-200 hover:text-white hover:bg-emerald-800/40'
                    }`}
                  >
                    {labels[lang]}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </header>

      {/* Main Welcome Hero Container */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-10 sm:py-16">
        <div className="w-full max-w-2xl text-center">
          {/* Islamic Bismillah Banner */}
          <div className="mb-6 inline-block">
            <p className="font-arabic text-2xl sm:text-3xl text-emerald-800 font-bold tracking-wider mb-1 select-none">
              {t.bismillah}
            </p>
            <div className="h-0.5 w-32 mx-auto bg-gradient-to-r from-transparent via-amber-500 to-transparent"></div>
          </div>

          {/* Central Logo & Title Card */}
          <div className="bg-white rounded-2xl shadow-xl shadow-emerald-950/5 border border-emerald-100 p-6 sm:p-10 text-center relative overflow-hidden">
            {/* Top decorative accent */}
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-emerald-600 via-teal-500 to-amber-500"></div>

            <div className="w-20 h-20 mx-auto mb-5 rounded-2xl bg-emerald-50 border border-emerald-200 flex items-center justify-center text-4xl shadow-inner">
              🕌
            </div>

            <h1 className="text-3xl sm:text-4xl font-extrabold text-emerald-950 tracking-tight mb-2">
              {t.appName}
            </h1>

            <p className="text-sm sm:text-base font-semibold text-emerald-700 tracking-wide uppercase mb-4">
              {t.tagline}
            </p>

            <p className="text-base sm:text-lg text-slate-600 max-w-lg mx-auto leading-relaxed mb-8">
              “{t.welcomeIntro}”
            </p>

            {/* Dual Login Options: User Login vs Admin Login */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl mx-auto mb-6 text-start">
              {/* Card 1: User / Community Member */}
              <div className="bg-emerald-50/70 rounded-2xl p-5 border border-emerald-200 flex flex-col justify-between hover:shadow-md transition-shadow">
                <div>
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center mb-3 shadow-sm">
                    <Heart className="w-5 h-5 fill-white" />
                  </div>
                  <h3 className="font-extrabold text-base text-emerald-950">
                    {currentLang === 'hi'
                      ? 'लॉगिन एज अ यूजर (User Login)'
                      : currentLang === 'ur'
                      ? 'صارف لاگ ان (User Login)'
                      : 'Login as Member / User'}
                  </h3>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    {currentLang === 'hi'
                      ? 'गाँव के सदस्य: अपनी मासिक कम्युनिटी फीस चेक व पे करें, सदक़ा, ज़कात एवं लिल्लाह चंदा दें।'
                      : 'Village members: check & pay monthly fees, donate sadaqah, zakat, and view receipts.'}
                  </p>
                </div>

                <div className="mt-4 space-y-2">
                  <button
                    id="user-login-btn"
                    type="button"
                    onClick={() => triggerLogin('user')}
                    className="w-full py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold text-xs shadow-sm flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>{t.login}</span>
                  </button>
                  <button
                    id="user-signup-btn"
                    type="button"
                    onClick={triggerSignUp}
                    className="w-full py-2 px-3 rounded-xl text-emerald-800 hover:bg-white/80 font-semibold text-xs border border-emerald-300 transition-colors text-center cursor-pointer"
                  >
                    {t.createNewAccount}
                  </button>
                </div>
              </div>

              {/* Card 2: Mosque / Madrasa Admin */}
              <div className="bg-gradient-to-br from-amber-50/80 via-white to-orange-50/60 rounded-2xl p-5 border border-amber-300 flex flex-col justify-between hover:shadow-md transition-shadow">
                <div>
                  <div className="w-10 h-10 rounded-xl bg-amber-500 text-amber-950 flex items-center justify-center mb-3 shadow-sm">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <h3 className="font-extrabold text-base text-amber-950">
                    {currentLang === 'hi'
                      ? 'लॉगिन एज अ एडमिन (Admin Login)'
                      : currentLang === 'ur'
                      ? 'ایڈمن لاگ ان (Admin Login)'
                      : 'Login as Mosque Admin'}
                  </h3>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                    {currentLang === 'hi'
                      ? 'मस्जिद कमेटी / मुतवल्ली: मासिक फीस सेट करें, UPI पेमेंट्स वेरिफाई करें, फोटो बदलें, और विज्ञापन जोड़ें।'
                      : 'Mosque committee: set monthly fees, verify UPI payments, upload photo, and post appeals.'}
                  </p>
                </div>

                <div className="mt-4">
                  <button
                    id="admin-login-btn"
                    type="button"
                    onClick={() => triggerLogin('admin')}
                    className="w-full py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-amber-950 font-extrabold text-xs shadow-sm flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>{currentLang === 'hi' ? 'एडमिन पोर्टल लॉगिन →' : 'Admin Portal Login →'}</span>
                  </button>
                  <p className="text-[10px] text-center text-slate-400 mt-1.5">
                    Authorized for rockybo09876@gmail.com & Committee
                  </p>
                </div>
              </div>
            </div>

            {/* Privacy notice banner */}
            <div className="mt-8 pt-6 border-t border-slate-100 flex items-center justify-center gap-2 text-xs text-slate-500">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                {currentLang === 'hi'
                  ? 'सुरक्षित एवं निजी मंच: संस्था विवरण, वॉलेट एवं दान रिकॉर्ड केवल लॉगिन के बाद दृश्यमान हैं।'
                  : currentLang === 'ur'
                  ? 'محفوظ اور نجی پلیٹ فارم: مدرسہ تفصیلات، والیٹ اور خیرات ریکارڈ لاگ ان کے بعد ہی دستیاب ہیں۔'
                  : currentLang === 'ar'
                  ? 'منصة خاصة وآمنة: معلومات المدرسة والمحفظة وسجل الصدقات مرئية فقط بعد تسجيل الدخول.'
                  : 'Private & Secure Platform: Institution details, wallet balance, and charity history are protected.'}
              </span>
            </div>
          </div>

          {/* Highlight badges */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-6 max-w-2xl mx-auto">
            <div className="bg-white/80 backdrop-blur rounded-xl p-3.5 border border-slate-200/80 flex items-center gap-3 text-start">
              <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                <Landmark className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-800">
                  {currentLang === 'hi' ? 'प्रमाणित संस्थान' : currentLang === 'ur' ? 'تصدیق شدہ ادارہ' : currentLang === 'ar' ? 'مؤسسة معتمدة' : 'Verified Madrasa'}
                </h4>
                <p className="text-[11px] text-slate-500">
                  {currentLang === 'hi' ? 'मुजफ्फरपुर, बिहार' : currentLang === 'ur' ? 'مظفرپور، بہار' : currentLang === 'ar' ? 'مظفربور، بيهار' : 'Muzaffarpur, Bihar'}
                </p>
              </div>
            </div>

            <div className="bg-white/80 backdrop-blur rounded-xl p-3.5 border border-slate-200/80 flex items-center gap-3 text-start">
              <div className="w-9 h-9 rounded-lg bg-teal-100 text-teal-800 flex items-center justify-center shrink-0">
                <Heart className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-800">
                  {currentLang === 'hi' ? 'पारदर्शी खैरात' : currentLang === 'ur' ? 'شفاف خیرات' : currentLang === 'ar' ? 'صدقات موثوقة' : 'Transparent Charity'}
                </h4>
                <p className="text-[11px] text-slate-500">
                  {currentLang === 'hi' ? 'मासिक एवं एकमुश्त' : currentLang === 'ur' ? 'ماہانہ و یک وقتی' : currentLang === 'ar' ? 'شهرية وفورية' : 'Monthly & Direct'}
                </p>
              </div>
            </div>

            <div className="bg-white/80 backdrop-blur rounded-xl p-3.5 border border-slate-200/80 flex items-center gap-3 text-start">
              <div className="w-9 h-9 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-slate-800">
                  {currentLang === 'hi' ? 'सुरक्षित UPI' : currentLang === 'ur' ? 'محفوظ UPI' : currentLang === 'ar' ? 'دفع آمن' : 'Protected UPI'}
                </h4>
                <p className="text-[11px] text-slate-500">
                  {currentLang === 'hi' ? 'सत्यापित बैंक प्रणाली' : currentLang === 'ur' ? 'بینک سے تصدیق شدہ' : currentLang === 'ar' ? 'تحقق بنكي رسمي' : 'Bank Verified Flow'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Public Footer with Legal links */}
      <footer className="bg-slate-900 text-slate-400 py-6 border-t border-slate-800 text-xs">
        <div className="max-w-5xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="text-lg">🕌</span>
            <span className="text-slate-200 font-semibold">{t.appName}</span>
            <span>• © 2026</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs">
            <button
              id="footer-privacy-btn"
              onClick={() => onOpenLegal('privacy')}
              className="hover:text-emerald-400 transition-colors"
            >
              {t.privacyPolicy}
            </button>
            <span>•</span>
            <button
              id="footer-terms-btn"
              onClick={() => onOpenLegal('terms')}
              className="hover:text-emerald-400 transition-colors"
            >
              {t.termsConditions}
            </button>
            <span>•</span>
            <button
              id="footer-refund-btn"
              onClick={() => onOpenLegal('refund')}
              className="hover:text-emerald-400 transition-colors"
            >
              {t.refundPolicy}
            </button>
            <span>•</span>
            <button
              id="footer-contact-btn"
              onClick={() => onOpenLegal('contact')}
              className="hover:text-emerald-400 transition-colors"
            >
              {t.contactUs}
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};

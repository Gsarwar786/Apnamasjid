import React, { useState } from 'react';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { SupportedLanguage, MasjidDetails } from '../types';
import { translations } from '../i18n';
import { X, Mail, Lock, User, AlertCircle, CheckCircle2, Loader2, ArrowRight, ShieldCheck, Shield, Building2 } from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  initialMode?: 'login' | 'signup';
  initialRole?: 'user' | 'admin';
  currentLang: SupportedLanguage;
  masjids?: MasjidDetails[];
  selectedMasjidId?: string;
  onOpenRegisterMasjid?: () => void;
  onClose: () => void;
  onSuccess: (role?: 'user' | 'admin', selectedMasjidId?: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode = 'login',
  initialRole = 'user',
  currentLang,
  masjids = [],
  selectedMasjidId,
  onOpenRegisterMasjid,
  onClose,
  onSuccess,
}) => {
  const [mode, setMode] = useState<'login' | 'signup' | 'forgot'>(initialMode);
  const [role, setRole] = useState<'user' | 'admin'>(initialRole);
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [chosenMasjidId, setChosenMasjidId] = useState<string>(selectedMasjidId || (masjids[0]?.id ?? 'madrasa_tegiya'));
  
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Sync mode and role when modal opens or props change
  React.useEffect(() => {
    if (isOpen) {
      setMode(initialMode);
      setRole(initialRole);
      setErrorMsg(null);
      setSuccessMsg(null);
      if (selectedMasjidId) {
        setChosenMasjidId(selectedMasjidId);
      } else if (masjids.length > 0 && !chosenMasjidId) {
        setChosenMasjidId(masjids[0].id);
      }
      if (initialRole === 'admin') {
        setEmail('rockybo09876@gmail.com');
      }
    }
  }, [isOpen, initialMode, initialRole, selectedMasjidId, masjids]);

  if (!isOpen) return null;

  const t = translations[currentLang];
  const isRtl = currentLang === 'ur' || currentLang === 'ar';

  const resetForm = () => {
    setErrorMsg(null);
    setSuccessMsg(null);
  };

  const switchMode = (newMode: 'login' | 'signup' | 'forgot') => {
    resetForm();
    setMode(newMode);
  };

  const getFirebaseErrorMessage = (code: string): string => {
    switch (code) {
      case 'auth/email-already-in-use':
        return currentLang === 'hi'
          ? 'यह ईमेल पहले से पंजीकृत है। कृपया लॉगिन करें।'
          : currentLang === 'ur'
          ? 'یہ ای میل پہلے سے رجسٹرڈ ہے۔ برائے مہربانی لاگ ان کریں۔'
          : currentLang === 'ar'
          ? 'هذا البريد مسجل مسبقاً، يرجى تسجيل الدخول.'
          : 'This email is already registered. Please login instead.';
      case 'auth/invalid-email':
        return currentLang === 'hi'
          ? 'अमान्य ईमेल पता। कृपया सही ईमेल दर्ज करें।'
          : currentLang === 'ur'
          ? 'درست ای میل درج کریں۔'
          : currentLang === 'ar'
          ? 'عنوان بريد إلكتروني غير صالح.'
          : 'Invalid email address format.';
      case 'auth/weak-password':
        return currentLang === 'hi'
          ? 'पासवर्ड कम से कम 6 अक्षरों का होना चाहिए।'
          : currentLang === 'ur'
          ? 'پاس ورڈ کم از کم 6 حروف کا ہونا چاہیے۔'
          : currentLang === 'ar'
          ? 'يجب أن تتكون كلمة المرور من 6 أحرف على الأقل.'
          : 'Password should be at least 6 characters long.';
      case 'auth/user-not-found':
      case 'auth/wrong-password':
      case 'auth/invalid-credential':
        return currentLang === 'hi'
          ? 'गलत ईमेल या पासवर्ड। यदि आपने अभी तक खाता नहीं बनाया है, तो कृपया नीचे "खाता बनाएं" पर क्लिक करें।'
          : currentLang === 'ur'
          ? 'غلط ای میل یا پاس ورڈ۔ اگر آپ کا اکاؤنٹ نہیں ہے تو نیچے "نیا اکاؤنٹ بنائیں" پر کلک کریں۔'
          : currentLang === 'ar'
          ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة. يرجى إنشاء حساب جديد إذا لم تكن مسجلاً.'
          : 'Invalid email or password. If you do not have an account yet, please click "Create New Account / Sign Up" below.';
      default:
        return currentLang === 'hi'
          ? 'प्रमाणीकरण में त्रुटि: ' + code
          : currentLang === 'ur'
          ? 'توثیقی خرابی: ' + code
          : currentLang === 'ar'
          ? 'خطأ في المصادقة: ' + code
          : 'Authentication error: ' + code;
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail || !password) {
      setErrorMsg('Please enter both email and password.');
      return;
    }

    try {
      setLoading(true);
      const userCredential = await signInWithEmailAndPassword(auth, cleanEmail, password);
      const user = userCredential.user;

      // Ensure user profile document exists in Firestore
      const userRef = doc(db, 'users', user.uid);
      const snap = await getDoc(userRef);

      if (!snap.exists()) {
        try {
          await setDoc(userRef, {
            uid: user.uid,
            name: user.displayName || cleanEmail.split('@')[0],
            email: cleanEmail,
            walletBalance: 0,
            monthlyCharity: 0,
            autoCharity: false,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          });
        } catch (dbErr) {
          console.warn('Initial doc setup notice: ', dbErr);
        }
      }

      onSuccess(role);
      onClose();
    } catch (err: any) {
      console.error('Login error:', err);
      setErrorMsg(getFirebaseErrorMessage(err?.code || err?.message || 'Login failed'));
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanName = fullName.trim();
    const cleanEmail = email.trim().toLowerCase();

    if (!cleanName) {
      setErrorMsg('Please enter your full name.');
      return;
    }
    if (!cleanEmail) {
      setErrorMsg('Please enter a valid email address.');
      return;
    }
    if (password.length < 6) {
      setErrorMsg('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    try {
      setLoading(true);
      const userCredential = await createUserWithEmailAndPassword(auth, cleanEmail, password);
      const user = userCredential.user;

      const activeChosenMasjid = masjids.find((m) => m.id === chosenMasjidId) || masjids[0];

      // Store in users/{uid} as specified:
      // walletBalance = 0, monthlyCharity = 0, autoCharity = false, name, email and chosen masjidId
      const userDocPath = `users/${user.uid}`;
      try {
        await setDoc(doc(db, 'users', user.uid), {
          uid: user.uid,
          name: cleanName,
          email: cleanEmail,
          walletBalance: 0,
          monthlyCharity: 0,
          autoCharity: false,
          masjidId: chosenMasjidId || 'madrasa_tegiya',
          masjidName: activeChosenMasjid?.name || 'Madrasa Tegiya Talim Al Islam',
          role: 'user',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.WRITE, userDocPath);
      }

      onSuccess(role, chosenMasjidId);
      onClose();
    } catch (err: any) {
      console.error('Sign up error:', err);
      setErrorMsg(getFirebaseErrorMessage(err?.code || err?.message || 'Sign up failed'));
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail) {
      setErrorMsg('Please provide your registered email address.');
      return;
    }

    try {
      setLoading(true);
      await sendPasswordResetEmail(auth, cleanEmail);
      setSuccessMsg(t.passwordResetSuccess);
    } catch (err: any) {
      console.error('Password reset error:', err);
      setErrorMsg(getFirebaseErrorMessage(err?.code || err?.message || 'Reset failed'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div
        className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-emerald-100 overflow-hidden relative animate-in fade-in zoom-in-95 duration-200"
        dir={isRtl ? 'rtl' : 'ltr'}
      >
        {/* Header decoration */}
        <div className="bg-gradient-to-r from-emerald-800 to-teal-800 text-white p-5 relative">
          <button
            id="auth-modal-close-btn"
            onClick={onClose}
            className="absolute top-4 right-4 text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xl">🕌</span>
            <span className="font-bold tracking-wide">{t.appName}</span>
          </div>

          <h2 className="text-xl font-bold text-white">
            {mode === 'login' && t.login}
            {mode === 'signup' && t.signUp}
            {mode === 'forgot' && t.forgotPassword}
          </h2>
          <p className="text-xs text-emerald-100/90 mt-0.5">
            {mode === 'login' && 'Enter your credentials to access Madrasa records & wallet'}
            {mode === 'signup' && 'Create your private account to support Apna Masjid'}
            {mode === 'forgot' && t.sendResetEmail}
          </p>
        </div>

        {/* Form Body */}
        <div className="p-6">
          {/* Role Switcher (User vs Admin) */}
          <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl mb-5 text-xs font-bold">
            <button
              id="role-select-user-btn"
              type="button"
              onClick={() => {
                setRole('user');
                resetForm();
              }}
              className={`py-2 px-2 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                role === 'user'
                  ? 'bg-white text-emerald-950 shadow-sm'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <User className="w-3.5 h-3.5 text-emerald-700" />
              <span>लॉगिन: यूजर (User)</span>
            </button>

            <button
              id="role-select-admin-btn"
              type="button"
              onClick={() => {
                setRole('admin');
                setEmail('rockybo09876@gmail.com');
                resetForm();
              }}
              className={`py-2 px-2 rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                role === 'admin'
                  ? 'bg-amber-500 text-amber-950 shadow-sm'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>लॉगिन: एडमिन (Admin)</span>
            </button>
          </div>

          {/* Admin Guidance Notice if Admin Role is Selected */}
          {role === 'admin' && (
            <div className="mb-4 p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-950 text-xs flex flex-col gap-1.5">
              <div className="flex items-center gap-1.5 font-extrabold text-amber-900">
                <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0" />
                <span>मस्जिद / मदरसा व्यवस्थापक (Admin Portal)</span>
              </div>
              <p className="text-[11px] text-amber-800">
                Authorized Admin: <span className="font-bold underline">rockybo09876@gmail.com</span>.
                लॉगिन करने के बाद आप मासिक फीस सेट कर सकेंगे, फोटो अपलोड कर सकेंगे एवं विज्ञापन जारी कर सकेंगे।
              </p>
              {email !== 'rockybo09876@gmail.com' && (
                <button
                  type="button"
                  onClick={() => setEmail('rockybo09876@gmail.com')}
                  className="self-start text-[10px] font-bold text-emerald-800 bg-white px-2 py-0.5 rounded border border-amber-300 hover:bg-amber-100"
                >
                  ⚡ Fill rockybo09876@gmail.com
                </button>
              )}
            </div>
          )}

          {errorMsg && (
            <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* LOGIN FORM */}
          {mode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">{t.email}</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    id="login-email-input"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-700">{t.password}</label>
                  <button
                    id="auth-forgot-pw-btn"
                    type="button"
                    onClick={() => switchMode('forgot')}
                    className="text-xs text-emerald-700 hover:text-emerald-800 font-medium"
                  >
                    {t.forgotPassword}
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    id="login-password-input"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                  />
                </div>
              </div>

              <button
                id="auth-login-submit-btn"
                type="submit"
                disabled={loading}
                className="w-full py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow-md shadow-emerald-700/20 transition-all flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Processing...</span>
                  </>
                ) : (
                  <>
                    <span>{t.login}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="text-center pt-2">
                <button
                  id="switch-to-signup-btn"
                  type="button"
                  onClick={() => switchMode('signup')}
                  className="text-xs text-slate-600 hover:text-emerald-700 font-medium"
                >
                  Don't have an account? <span className="font-bold text-emerald-700">{t.signUp}</span>
                </button>
              </div>
            </form>
          )}

          {/* SIGN UP FORM */}
          {mode === 'signup' && (
            <form onSubmit={handleSignUp} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{t.fullName}</label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    id="signup-name-input"
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Mohammad Bilal"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                  />
                </div>
              </div>

              {/* Select Mosque / Madrasa */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-semibold text-slate-700">
                    अपना मदरसा / मस्जिद चुनें (Select Mosque) *
                  </label>
                  {onOpenRegisterMasjid && (
                    <button
                      type="button"
                      onClick={() => {
                        onClose();
                        onOpenRegisterMasjid();
                      }}
                      className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 underline cursor-pointer"
                    >
                      + नई मस्जिद जोड़ें
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <select
                    id="signup-masjid-select"
                    value={chosenMasjidId}
                    onChange={(e) => setChosenMasjidId(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-xs focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 bg-white font-medium"
                  >
                    {masjids.length > 0 ? (
                      masjids.map((m) => (
                        <option key={m.id} value={m.id}>
                          {m.name} ({m.district || m.address?.split(',')[1] || 'Bihar'})
                        </option>
                      ))
                    ) : (
                      <option value="madrasa_tegiya">
                        Madrasa Tegiya Talim Al Islam (Muzaffarpur)
                      </option>
                    )}
                  </select>
                </div>
                <span className="text-[10px] text-slate-500 mt-1 block">
                  आप जिस मदरसे को चुनेंगे, आपको केवल उसी का बैंक खाता, चंदा लेजर एवं मासिक फीस दिखेगी।
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{t.email}</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    id="signup-email-input"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{t.password}</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    id="signup-password-input"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Minimum 6 characters"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">{t.confirmPassword}</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    id="signup-confirm-password-input"
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Re-enter password"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                  />
                </div>
              </div>

              <button
                id="auth-signup-submit-btn"
                type="submit"
                disabled={loading}
                className="w-full py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow-md shadow-emerald-700/20 transition-all flex items-center justify-center gap-2 disabled:opacity-60 mt-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Creating Account...</span>
                  </>
                ) : (
                  <>
                    <span>{t.signUp}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="text-center pt-2">
                <button
                  id="switch-to-login-btn"
                  type="button"
                  onClick={() => switchMode('login')}
                  className="text-xs text-slate-600 hover:text-emerald-700 font-medium"
                >
                  {t.alreadyHaveAccount}
                </button>
              </div>
            </form>
          )}

          {/* FORGOT PASSWORD FORM */}
          {mode === 'forgot' && (
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">{t.email}</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    id="forgot-email-input"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your registered email"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                  />
                </div>
              </div>

              <button
                id="auth-reset-submit-btn"
                type="submit"
                disabled={loading}
                className="w-full py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow-md shadow-emerald-700/20 transition-all flex items-center justify-center gap-2 disabled:opacity-60"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Sending Link...</span>
                  </>
                ) : (
                  <span>{t.resetPasswordLink}</span>
                )}
              </button>

              <div className="text-center pt-2">
                <button
                  id="back-to-login-btn"
                  type="button"
                  onClick={() => switchMode('login')}
                  className="text-xs text-emerald-700 hover:underline font-medium"
                >
                  ← Back to Login
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

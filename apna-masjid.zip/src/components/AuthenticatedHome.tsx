import React, { useState } from 'react';
import { UserProfile, SupportedLanguage, AdvertisementItem, MasjidDetails } from '../types';
import { translations } from '../i18n';
import {
  MapPin,
  Heart,
  BookOpen,
  Compass,
  Megaphone,
  ArrowRight,
  ShieldCheck,
  CalendarCheck,
  AlertCircle,
  CheckCircle2,
  Wallet,
  Sparkles,
} from 'lucide-react';
import { doc, runTransaction, addDoc, collection } from 'firebase/firestore';
import { db } from '../firebase';

interface AuthenticatedHomeProps {
  userProfile: UserProfile | null;
  currentLang: SupportedLanguage;
  advertisements: AdvertisementItem[];
  masjidDetails: MasjidDetails;
  onNavigate: (tab: string) => void;
  onRefreshProfile?: () => void;
}

export const AuthenticatedHome: React.FC<AuthenticatedHomeProps> = ({
  userProfile,
  currentLang,
  advertisements,
  masjidDetails,
  onNavigate,
}) => {
  const t = translations[currentLang];
  const isRtl = currentLang === 'ur' || currentLang === 'ar';

  const [payingFee, setPayingFee] = useState(false);
  const [feeMessage, setFeeMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Fallback active community campaigns if none in Firestore
  const activeAds: AdvertisementItem[] =
    advertisements && advertisements.length > 0
      ? advertisements
      : [
          {
            id: 'default_rabi_ul_awwal',
            title: '12 रबी-उल-अव्वल मिलाद-उन-नबी एवं लंगर विशेष अपील',
            description:
              'मदरसा तेगिया तालीम अल इस्लाम में 12 रबी-उल-अव्वल के मुबारक मौके पर कुरआन ख्वानी, सीरत जलसा एवं लंगर-ए-आम का आयोजन। सवाब-ए-जारिया में हिस्सा लें।',
            category: 'rabi_ul_awwal',
            targetAmount: 50000,
            collectedAmount: 22400,
            active: true,
            createdAt: new Date().toISOString(),
          },
          {
            id: 'default_renovation',
            title: 'मस्जिद वजूखाना, वाटर कूलर एवं कालीन रिनोवेशन अपील',
            description:
              'नमाजियों की सहूलियत के लिए नए वजूखाने के निर्माण, ठंडा पानी की व्यवस्था एवं हॉल के वाटरप्रूफ कालीन हेतु आर्थिक सहयोग प्रदान करें।',
            category: 'renovation',
            targetAmount: 75000,
            collectedAmount: 38500,
            active: true,
            createdAt: new Date().toISOString(),
          },
        ];

  // Current month key (e.g. "2026-09")
  const now = new Date();
  const currentMonthKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const isFeePaidThisMonth = userProfile?.lastMonthlyFeePaid === currentMonthKey;
  const monthlyFeeAmount = masjidDetails.monthlyCommunityFee || 200;

  // 1-Click Monthly Community Fee Payment from Wallet
  const handlePayMonthlyFee = async () => {
    if (!userProfile) return;
    setFeeMessage(null);

    if ((userProfile.walletBalance || 0) < monthlyFeeAmount) {
      setFeeMessage({
        type: 'error',
        text: `${t.insufficientBalance} Please add money to your wallet first. Current balance: ₹${userProfile.walletBalance || 0}`,
      });
      return;
    }

    try {
      setPayingFee(true);
      const userRef = doc(db, 'users', userProfile.uid);

      await runTransaction(db, async (transaction) => {
        const uDoc = await transaction.get(userRef);
        if (!uDoc.exists()) throw new Error('User not found');
        const bal = uDoc.data().walletBalance || 0;
        if (bal < monthlyFeeAmount) throw new Error('Insufficient wallet balance');

        transaction.update(userRef, {
          walletBalance: bal - monthlyFeeAmount,
          lastMonthlyFeePaid: currentMonthKey,
          updatedAt: new Date().toISOString(),
        });
      });

      const txnId = `FEE_${Date.now()}`;
      // Add to public charity ledger
      await addDoc(collection(db, 'charities'), {
        uid: userProfile.uid,
        donorName: userProfile.name || 'Community Member',
        amount: monthlyFeeAmount,
        type: 'monthly_fee',
        status: 'successful',
        masjidId: 'madrasa_tegiya',
        transactionId: txnId,
        monthYear: currentMonthKey,
        isAnonymous: false,
        createdAt: new Date().toISOString(),
      });

      // Add to user transactions
      await addDoc(collection(db, 'transactions'), {
        uid: userProfile.uid,
        type: 'monthly_fee',
        amount: monthlyFeeAmount,
        status: 'successful',
        paymentId: txnId,
        description: `Monthly Community Fee (${currentMonthKey}) - Mosque Maintenance & Imam Salary`,
        createdAt: new Date().toISOString(),
      });

      setFeeMessage({
        type: 'success',
        text: `Alhamdulillah! Monthly fee of ₹${monthlyFeeAmount} for ${currentMonthKey} has been successfully paid from your wallet.`,
      });
    } catch (err: any) {
      setFeeMessage({ type: 'error', text: err.message || 'Payment failed.' });
    } finally {
      setPayingFee(false);
    }
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Welcome Greeting Banner */}
      <div className="bg-gradient-to-r from-emerald-800 to-teal-800 rounded-2xl text-white p-5 sm:p-6 shadow-md border border-emerald-700">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xl">Assalamu Alaikum,</span>
              <span className="font-bold text-amber-300 text-lg">
                {userProfile?.name || 'Brother / Sister'}
              </span>
            </div>
            <p className="font-arabic text-emerald-100 text-sm sm:text-base">
              {t.bismillah}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              id="auth-home-donate-btn"
              onClick={() => onNavigate('charity')}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-amber-950 font-bold text-xs sm:text-sm shadow-sm flex items-center gap-1.5 transition-all"
            >
              <Heart className="w-4 h-4 fill-amber-950" />
              <span>{t.quickDonate}</span>
            </button>
            <button
              id="auth-home-wallet-btn"
              onClick={() => onNavigate('wallet')}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-xs sm:text-sm border border-white/20 transition-colors"
            >
              {t.walletBalance}: ₹{userProfile?.walletBalance ?? 0}
            </button>
          </div>
        </div>
      </div>

      {/* MONTHLY COMMUNITY FEE CARD */}
      <div
        className={`rounded-2xl p-5 border shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
          isFeePaidThisMonth
            ? 'bg-emerald-50/80 border-emerald-200'
            : 'bg-gradient-to-r from-amber-50 via-orange-50 to-amber-100 border-amber-300'
        }`}
      >
        <div className="flex items-start gap-3.5">
          <div
            className={`p-2.5 rounded-xl shrink-0 ${
              isFeePaidThisMonth
                ? 'bg-emerald-100 text-emerald-800'
                : 'bg-amber-500 text-amber-950'
            }`}
          >
            {isFeePaidThisMonth ? (
              <CheckCircle2 className="w-6 h-6" />
            ) : (
              <CalendarCheck className="w-6 h-6" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-white/80 text-slate-800 border border-slate-200">
                {currentLang === 'hi'
                  ? 'मासिक कम्युनिटी चंदा'
                  : currentLang === 'ur'
                  ? 'ماہانہ کمیونٹی فیس'
                  : 'Monthly Community Fee'}
              </span>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                  isFeePaidThisMonth
                    ? 'bg-emerald-200 text-emerald-900'
                    : 'bg-amber-200 text-amber-950'
                }`}
              >
                {isFeePaidThisMonth ? 'Paid for this month' : 'Due for this month'}
              </span>
            </div>
            <h3 className="text-sm sm:text-base font-extrabold text-slate-900 mt-1">
              {currentLang === 'hi'
                ? `मस्जिद मेंटेनेंस एवं इमाम साहब की तनख्वाह (₹${monthlyFeeAmount}/माह)`
                : currentLang === 'ur'
                ? `مسجد کا خرچ اور امام صاحب کی تنخواہ (₹${monthlyFeeAmount} ماہانہ)`
                : `Mosque Maintenance & Imam Salary Fund (₹${monthlyFeeAmount}/mo)`}
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              {isFeePaidThisMonth
                ? `Alhamdulillah, your family's fee for ${currentMonthKey} has been received and logged in the transparent community ledger.`
                : `Every village household is requested to pay ₹${monthlyFeeAmount} per month to maintain the mosque and support our Imam.`}
            </p>
            {masjidDetails.monthlyFeeNote && (
              <div className="mt-2 text-xs text-amber-950 font-medium bg-white/80 p-2 rounded-xl border border-amber-200/90 flex items-start gap-1.5">
                <span className="font-bold shrink-0">📌 विवरण:</span>
                <span>{masjidDetails.monthlyFeeNote}</span>
              </div>
            )}
          </div>
        </div>

        <div className="shrink-0 self-end sm:self-center flex flex-col sm:flex-row items-center gap-2">
          {isFeePaidThisMonth ? (
            <button
              onClick={() => onNavigate('history')}
              className="px-4 py-2 rounded-xl bg-white border border-emerald-300 text-emerald-800 font-bold text-xs hover:bg-emerald-100 transition-colors"
            >
              View in Ledger
            </button>
          ) : (
            <button
              onClick={handlePayMonthlyFee}
              disabled={payingFee}
              className="px-5 py-2.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 active:bg-emerald-950 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-1.5"
            >
              <Wallet className="w-4 h-4 text-amber-300" />
              <span>{payingFee ? 'Processing...' : `Pay ₹${monthlyFeeAmount} from Wallet`}</span>
            </button>
          )}
        </div>
      </div>

      {feeMessage && (
        <div
          className={`p-3.5 rounded-xl text-xs flex items-center justify-between border ${
            feeMessage.type === 'success'
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : 'bg-red-50 border-red-200 text-red-900'
          }`}
        >
          <span>{feeMessage.text}</span>
          <button
            onClick={() => setFeeMessage(null)}
            className="text-slate-400 hover:text-slate-700 font-bold ml-2"
          >
            ✕
          </button>
        </div>
      )}

      {/* Community Advertisement / Announcements Area (Always Visible & Admin Controlled) */}
      {activeAds.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-1.5 text-xs font-extrabold text-amber-900 uppercase tracking-wider">
              <Megaphone className="w-4 h-4 text-amber-600" />
              <span>मस्जिद व मदरसा विज्ञापन एवं विशेष अपील (Campaigns & Notices)</span>
            </div>
            <span className="text-[11px] text-slate-500 font-medium">एडमिन द्वारा सत्यापित</span>
          </div>

          {activeAds.map((ad) => (
            <div
              key={ad.id}
              className="bg-gradient-to-r from-amber-50/80 via-white to-emerald-50/80 rounded-2xl p-4 sm:p-5 border border-amber-200/90 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 hover:border-amber-300 transition-all"
            >
              <div className="flex items-start gap-3">
                <div className="p-2.5 rounded-xl bg-amber-500 text-amber-950 shrink-0 shadow-sm">
                  <Megaphone className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-amber-200 text-amber-950">
                      {ad.category === 'rabi_ul_awwal'
                        ? '12 Rabi-ul-Awwal Appeal'
                        : ad.category === 'renovation'
                        ? 'Mosque Renovation'
                        : 'Official Announcement'}
                    </span>
                    <h4 className="text-sm sm:text-base font-extrabold text-slate-900">{ad.title}</h4>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">{ad.description}</p>
                  {ad.targetAmount && (
                    <p className="text-[11px] font-bold text-emerald-800 mt-1">
                      Campaign Target: ₹{ad.targetAmount}
                    </p>
                  )}
                </div>
              </div>
              <button
                onClick={() => onNavigate('charity')}
                className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold shrink-0 self-end sm:self-center flex items-center gap-1 shadow-sm transition-colors cursor-pointer"
              >
                <span>Support Campaign</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Main Masjid / Madrasa Profile Card with Photo */}
      <div className="bg-white rounded-2xl shadow-sm border border-emerald-100 overflow-hidden">
        {/* Card Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🕌</span>
            <h2 className="text-lg sm:text-xl font-extrabold text-emerald-950">
              {masjidDetails.name || t.masjidHeading}
            </h2>
          </div>
          <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
            Verified Profile
          </span>
        </div>

        {/* 16:9 Mosque Photo Display with object-fit: contain (Mandatory Requirement) */}
        <div className="p-4 sm:p-6 bg-slate-950">
          <div className="relative w-full aspect-video rounded-xl overflow-hidden bg-slate-900 border border-slate-800 flex items-center justify-center">
            <img
              src={masjidDetails.photoUrl || '/madrasa_tegiya.jpg'}
              alt={masjidDetails.name || 'Madrasa Tegiya'}
              className="w-full h-full object-contain"
              loading="lazy"
            />
          </div>
          <p className="text-center text-[11px] text-slate-400 mt-2">
            📷 {masjidDetails.name || 'MADRASA TEGIYA TALIM AL ISLAM'} — Official Campus
          </p>
        </div>

        {/* Detailed Information Section */}
        <div className="p-5 sm:p-7 space-y-6">
          {/* Name & Address */}
          <div>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {masjidDetails.name || t.madrasaName}
            </h3>
            <div className="flex items-center gap-1.5 text-xs sm:text-sm text-emerald-800 font-semibold mt-1">
              <MapPin className="w-4 h-4 shrink-0 text-emerald-600" />
              <span>{masjidDetails.address || t.madrasaAddress}</span>
            </div>
          </div>

          {/* Description */}
          <div className="bg-slate-50 rounded-xl p-4 border border-slate-200/80">
            <div className="flex items-center gap-2 mb-2 text-emerald-900 font-bold text-sm">
              <BookOpen className="w-4 h-4 text-emerald-700" />
              <span>Description & Educational Scope</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              {masjidDetails.description || t.madrasaDesc}
            </p>
          </div>

          {/* Purpose */}
          <div className="bg-emerald-50/70 rounded-xl p-4 border border-emerald-200/60">
            <div className="flex items-center gap-2 mb-2 text-emerald-900 font-bold text-sm">
              <Compass className="w-4 h-4 text-emerald-700" />
              <span>{t.madrasaPurposeTitle}</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              {masjidDetails.purpose || t.madrasaPurposeDesc}
            </p>
          </div>

          {/* Support / Charity Information */}
          <div className="bg-amber-50/70 rounded-xl p-4 border border-amber-200/70">
            <div className="flex items-center gap-2 mb-2 text-amber-950 font-bold text-sm">
              <Heart className="w-4 h-4 text-amber-700" />
              <span>{t.supportCharityTitle}</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              {t.supportCharityDesc}
            </p>
          </div>

          {/* Quick Action Bar */}
          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              id="home-contribute-now-btn"
              onClick={() => onNavigate('charity')}
              className="flex-1 min-w-[200px] py-3 px-5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm shadow-md shadow-emerald-700/20 transition-all flex items-center justify-center gap-2"
            >
              <Heart className="w-4 h-4" />
              <span>{t.donateCharity}</span>
            </button>
            <button
              id="home-wallet-view-btn"
              onClick={() => onNavigate('wallet')}
              className="py-3 px-5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-sm transition-colors"
            >
              {t.navWallet}
            </button>
            <button
              onClick={() => onNavigate('history')}
              className="py-3 px-5 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold text-sm border border-amber-200 transition-colors flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-amber-600" />
              <span>सार्वजनिक लेजर (Public Ledger)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

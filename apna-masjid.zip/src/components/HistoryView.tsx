import React, { useState } from 'react';
import { CharityRecord, WalletTransaction, SupportedLanguage } from '../types';
import { translations } from '../i18n';
import {
  History as HistoryIcon,
  CheckCircle2,
  Clock,
  XCircle,
  Copy,
  Check,
  Filter,
  Users,
  Search,
  Landmark,
  ShieldCheck,
  Calendar,
  Sparkles,
} from 'lucide-react';

interface HistoryViewProps {
  allCommunityCharities: CharityRecord[];
  userCharities: CharityRecord[];
  transactions: WalletTransaction[];
  currentLang: SupportedLanguage;
  currentUserId?: string;
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  allCommunityCharities,
  userCharities,
  transactions,
  currentLang,
  currentUserId,
}) => {
  const t = translations[currentLang];
  const isRtl = currentLang === 'ur' || currentLang === 'ar';

  const [activeTab, setActiveTab] = useState<'community' | 'personal'>('community');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const handleCopyId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Category labels and styles
  const getCategoryMeta = (type: string) => {
    switch (type) {
      case 'monthly_fee':
        return {
          label: currentLang === 'hi' ? 'मासिक कम्युनिटी फीस (इमाम तनख्वाह व मेंटेनेंस)' : 'Monthly Community Fee (Imam & Maintenance)',
          color: 'bg-emerald-100 text-emerald-900 border-emerald-300',
        };
      case 'rabi_ul_awwal':
        return {
          label: currentLang === 'hi' ? '12 रबी-उल-अव्वल चंदा (विशेष)' : '12 Rabi-ul-Awwal Appeal',
          color: 'bg-amber-100 text-amber-950 border-amber-300',
        };
      case 'renovation':
        return {
          label: currentLang === 'hi' ? 'मस्जिद मरम्मत एवं निर्माण' : 'Mosque Renovation & Construction',
          color: 'bg-indigo-100 text-indigo-900 border-indigo-300',
        };
      case 'sadqah':
        return {
          label: currentLang === 'hi' ? 'सदक़ा (Sadqah)' : 'Sadqah',
          color: 'bg-blue-100 text-blue-900 border-blue-300',
        };
      case 'zakat':
        return {
          label: currentLang === 'hi' ? 'ज़कात (Zakat)' : 'Zakat',
          color: 'bg-purple-100 text-purple-900 border-purple-300',
        };
      case 'lillah':
        return {
          label: currentLang === 'hi' ? 'लिल्लाह (Lillah)' : 'Lillah',
          color: 'bg-slate-100 text-slate-800 border-slate-300',
        };
      default:
        return {
          label: type.toUpperCase().replace(/_/g, ' '),
          color: 'bg-slate-100 text-slate-700 border-slate-200',
        };
    }
  };

  // Calculate Community Transparency stats
  const totalCommunitySum = allCommunityCharities.reduce((sum, c) => sum + (c.amount || 0), 0);
  const totalMonthlyFeeSum = allCommunityCharities
    .filter((c) => c.type === 'monthly_fee')
    .reduce((sum, c) => sum + (c.amount || 0), 0);
  const totalDonorsCount = allCommunityCharities.length;

  // Filter Community charities
  const filteredCommunityList = allCommunityCharities.filter((item) => {
    const matchesSearch =
      (item.donorName || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.transactionId || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.monthYear || '').toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCat =
      selectedCategory === 'all' || item.type === selectedCategory;

    return matchesSearch && matchesCat;
  });

  // Personal combined records
  interface PersonalRecord {
    id: string;
    dateStr: string;
    timestamp: number;
    amount: number;
    typeLabel: string;
    status: string;
    transactionId: string;
    category: 'charity' | 'wallet';
  }

  const personalRecords: PersonalRecord[] = [];

  userCharities.forEach((c) => {
    const d = c.createdAt ? new Date(c.createdAt) : new Date();
    personalRecords.push({
      id: c.id,
      dateStr: d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      timestamp: d.getTime(),
      amount: c.amount,
      typeLabel: getCategoryMeta(c.type).label,
      status: c.status || 'successful',
      transactionId: c.transactionId || c.id,
      category: 'charity',
    });
  });

  transactions.forEach((tx) => {
    const d = tx.createdAt ? new Date(tx.createdAt) : new Date();
    if (tx.type === 'wallet_topup') {
      personalRecords.push({
        id: tx.id,
        dateStr: d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
        timestamp: d.getTime(),
        amount: tx.amount,
        typeLabel: t.typeWalletTopup,
        status: tx.status || 'successful',
        transactionId: tx.paymentId || tx.id,
        category: 'wallet',
      });
    }
  });

  personalRecords.sort((a, b) => b.timestamp - a.timestamp);

  return (
    <div className="space-y-6 pb-20 md:pb-8" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Header Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 shadow-sm border border-emerald-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <HistoryIcon className="w-5 h-5 text-emerald-700" />
            <h2 className="text-xl font-bold text-emerald-950">
              {currentLang === 'hi' ? 'चंदा एवं लेन-देन इतिहास' : 'Donations & Transaction History'}
            </h2>
          </div>
          <p className="text-xs text-slate-500">
            {currentLang === 'hi'
              ? 'मस्जिद के सभी चंदे का पारदर्शी सार्वजनिक लेजर और आपका व्यक्तिगत रिकॉर्ड।'
              : 'Transparent community ledger of all contributions and personal receipts.'}
          </p>
        </div>

        {/* View switcher tabs */}
        <div className="flex items-center p-1 bg-slate-100 rounded-2xl self-start sm:self-auto text-xs">
          <button
            onClick={() => setActiveTab('community')}
            className={`px-4 py-2 rounded-xl font-extrabold transition-all flex items-center gap-1.5 ${
              activeTab === 'community'
                ? 'bg-emerald-800 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>सार्वजनिक लेजर (Community Ledger)</span>
          </button>

          <button
            onClick={() => setActiveTab('personal')}
            className={`px-4 py-2 rounded-xl font-extrabold transition-all flex items-center gap-1.5 ${
              activeTab === 'personal'
                ? 'bg-emerald-800 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span>मेरा इतिहास (My History)</span>
          </button>
        </div>
      </div>

      {/* COMMUNITY TRANSPARENCY LEDGER TAB */}
      {activeTab === 'community' && (
        <div className="space-y-6">
          {/* Transparency Stats Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-gradient-to-br from-emerald-800 to-teal-800 text-white p-5 rounded-2xl shadow-sm border border-emerald-700">
              <span className="text-[11px] font-bold text-emerald-200 uppercase tracking-wider block">
                कुल एकत्रित चंदा (Total Community Collection)
              </span>
              <div className="text-3xl font-black text-amber-300 mt-1">₹{totalCommunitySum}</div>
              <p className="text-[11px] text-emerald-200 mt-0.5">Directly audited in Madrasa Tegiya account</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                मासिक फीस संकलन (Imam & Maintenance)
              </span>
              <div className="text-3xl font-black text-emerald-800 mt-1">₹{totalMonthlyFeeSum}</div>
              <p className="text-[11px] text-slate-400 mt-0.5">Fixed community maintenance contributions</p>
            </div>

            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                कुल प्राप्त प्रविष्टियां (Total Contributions)
              </span>
              <div className="text-3xl font-black text-slate-900 mt-1">{totalDonorsCount}</div>
              <p className="text-[11px] text-slate-400 mt-0.5">Logged records on blockchain-style ledger</p>
            </div>
          </div>

          {/* Search & Filter Controls */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="नाम, माह (e.g. 2026-09), या Transaction ID से खोजें..."
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
              {[
                { id: 'all', label: 'सभी (All)' },
                { id: 'monthly_fee', label: 'मासिक फीस' },
                { id: 'rabi_ul_awwal', label: '12 रबी-उल-अव्वल' },
                { id: 'renovation', label: 'मस्जिद मरम्मत' },
                { id: 'sadqah', label: 'सदक़ा' },
                { id: 'zakat', label: 'ज़कात' },
              ].map((c) => (
                <button
                  key={c.id}
                  onClick={() => setSelectedCategory(c.id)}
                  className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-colors ${
                    selectedCategory === c.id
                      ? 'bg-emerald-800 text-white'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* Public Ledger Records */}
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
              <h3 className="font-bold text-sm sm:text-base text-slate-900 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                <span>मस्जिद चंदा सार्वजनिक विवरण (Community Ledger)</span>
              </h3>
              <span className="text-xs text-slate-500 font-semibold">
                {filteredCommunityList.length} दानदाता प्रविष्टियाँ
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {filteredCommunityList.length === 0 ? (
                <div className="p-10 text-center text-xs text-slate-400">
                  कोई प्रविष्टि नहीं मिली।
                </div>
              ) : (
                filteredCommunityList.map((item) => {
                  const meta = getCategoryMeta(item.type);
                  const isCurrentUser = currentUserId && item.uid === currentUserId;
                  const dateStr = item.createdAt
                    ? new Date(item.createdAt).toLocaleString('en-IN', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })
                    : 'Recent';

                  return (
                    <div
                      key={item.id}
                      className={`p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                        isCurrentUser ? 'bg-emerald-50/40' : ''
                      }`}
                    >
                      <div className="space-y-1.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-sm sm:text-base font-extrabold text-slate-900">
                            {item.isAnonymous ? 'गुप्त दान (ख़िदमतगार)' : item.donorName || 'नेक बंदा'}
                          </span>
                          {isCurrentUser && (
                            <span className="px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-950 font-bold text-[10px]">
                              आप (You)
                            </span>
                          )}
                          <span
                            className={`px-2.5 py-0.5 rounded-md text-[10px] font-bold border ${meta.color}`}
                          >
                            {meta.label}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                          {item.monthYear && (
                            <span className="font-semibold text-emerald-800">
                              महीना: {item.monthYear}
                            </span>
                          )}
                          <span>दिनांक: {dateStr}</span>
                          <span className="font-mono text-[11px] text-slate-400">
                            ID: {item.transactionId || item.id}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 self-end sm:self-center">
                        <div className="text-right">
                          <span className="text-base sm:text-lg font-black text-emerald-800">
                            ₹{item.amount}
                          </span>
                          <span className="block text-[10px] text-emerald-600 font-bold">
                            ✓ Verified & Logged
                          </span>
                        </div>

                        <button
                          onClick={() => handleCopyId(item.transactionId || item.id)}
                          title="Copy Transaction ID"
                          className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
                        >
                          {copiedId === (item.transactionId || item.id) ? (
                            <Check className="w-3.5 h-3.5 text-emerald-700" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* PERSONAL HISTORY TAB */}
      {activeTab === 'personal' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
            <h3 className="font-bold text-sm sm:text-base text-slate-900">
              आपका व्यक्तिगत खाता विवरण (My Personal Receipts)
            </h3>
            <span className="text-xs text-slate-500">{personalRecords.length} कुल रिकॉर्ड</span>
          </div>

          <div className="divide-y divide-slate-100">
            {personalRecords.length === 0 ? (
              <div className="p-10 text-center text-xs text-slate-400">
                अभी तक कोई व्यक्तिगत लेन-देन नहीं हुआ।
              </div>
            ) : (
              personalRecords.map((item) => (
                <div
                  key={item.id}
                  className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900">{item.typeLabel}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold">
                        {item.status}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">दिनांक: {item.dateStr}</p>
                    <p className="text-[11px] font-mono text-slate-400 mt-0.5">Ref: {item.transactionId}</p>
                  </div>

                  <div className="flex items-center gap-3 self-end sm:self-center">
                    <span className="text-base font-black text-emerald-800">₹{item.amount}</span>
                    <button
                      onClick={() => handleCopyId(item.transactionId)}
                      className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
                    >
                      {copiedId === item.transactionId ? (
                        <Check className="w-3.5 h-3.5 text-emerald-700" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

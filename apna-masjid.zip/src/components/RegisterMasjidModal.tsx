import React, { useState } from 'react';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { SupportedLanguage } from '../types';
import {
  X,
  Building2,
  MapPin,
  User,
  Phone,
  Mail,
  FileText,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ShieldCheck,
} from 'lucide-react';

interface RegisterMasjidModalProps {
  isOpen: boolean;
  currentLang: SupportedLanguage;
  onClose: () => void;
  onSubmitted?: () => void;
}

export const RegisterMasjidModal: React.FC<RegisterMasjidModalProps> = ({
  isOpen,
  currentLang,
  onClose,
  onSubmitted,
}) => {
  const [masjidName, setMasjidName] = useState('');
  const [district, setDistrict] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('Bihar');
  const [address, setAddress] = useState('');
  const [applicantName, setApplicantName] = useState('');
  const [applicantPhone, setApplicantPhone] = useState('');
  const [applicantEmail, setApplicantEmail] = useState('');
  const [waqfOrRegNumber, setWaqfOrRegNumber] = useState('');
  const [note, setNote] = useState('');

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const cleanMasjidName = masjidName.trim();
    const cleanApplicantName = applicantName.trim();
    const cleanPhone = applicantPhone.trim();
    const cleanEmail = applicantEmail.trim().toLowerCase();
    const cleanDistrict = district.trim();
    const cleanAddress = address.trim();

    if (!cleanMasjidName || !cleanApplicantName || !cleanPhone || !cleanEmail || !cleanDistrict) {
      setErrorMsg('कृपया मदरसा/मस्जिद का नाम, मुतवल्ली का नाम, फ़ोन, ईमेल और ज़िला अवश्य दर्ज करें।');
      return;
    }

    try {
      setLoading(true);

      await addDoc(collection(db, 'masjid_requests'), {
        masjidName: cleanMasjidName,
        city: city.trim() || cleanDistrict,
        district: cleanDistrict,
        state: state.trim() || 'Bihar',
        address: cleanAddress || `${cleanDistrict}, ${state}`,
        applicantName: cleanApplicantName,
        applicantPhone: cleanPhone,
        applicantEmail: cleanEmail,
        waqfOrRegNumber: waqfOrRegNumber.trim() || '',
        note: note.trim() || '',
        status: 'pending',
        requestedAt: new Date().toISOString(),
      });

      setIsSuccess(true);
      if (onSubmitted) {
        onSubmitted();
      }
    } catch (err: any) {
      console.error('Masjid registration request error:', err);
      setErrorMsg(err.message || 'रिक्वेस्ट सबमिट करने में समस्या आई। कृपया पुनः प्रयास करें।');
    } finally {
      setLoading(false);
    }
  };

  const handleResetAndClose = () => {
    setIsSuccess(false);
    setErrorMsg(null);
    setMasjidName('');
    setDistrict('');
    setCity('');
    setAddress('');
    setApplicantName('');
    setApplicantPhone('');
    setApplicantEmail('');
    setWaqfOrRegNumber('');
    setNote('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-emerald-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-emerald-100 relative my-8">
        <button
          onClick={handleResetAndClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {isSuccess ? (
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-700 mx-auto flex items-center justify-center shadow-inner">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h3 className="text-xl font-extrabold text-emerald-950">
              अल्हम्दुलिल्लाह! रजिस्ट्रेशन रिक्वेस्ट प्राप्त हुई
            </h3>
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-left text-xs text-emerald-950 space-y-2">
              <p className="font-semibold">
                <strong>मदरसा / मस्जिद:</strong> {masjidName} ({district}, {state})
              </p>
              <p>
                <strong>आवेदक / मुतवल्ली:</strong> {applicantName} ({applicantPhone})
              </p>
              <p>
                <strong>एडमिन ईमेल:</strong> {applicantEmail}
              </p>
            </div>
            <p className="text-xs text-slate-600 max-w-md mx-auto leading-relaxed">
              आपकी रिक्वेस्ट सुपर एडमिन को भेज दी गई है। सुपर एडमिन द्वारा सत्यापन (Verification) और अप्रूवल होते ही आपको सूचित किया जाएगा और आपका एडमिन अकाउंट एक्टिव हो जाएगा।
            </p>
            <button
              onClick={handleResetAndClose}
              className="px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-md transition-colors"
            >
              ठीक है (Done)
            </button>
          </div>
        ) : (
          <div>
            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 rounded-2xl bg-emerald-700 text-white flex items-center justify-center shadow-md">
                <Building2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg sm:text-xl font-extrabold text-emerald-950">
                  अपनी मस्जिद / मदरसा जोड़ें
                </h3>
                <p className="text-xs text-slate-500">
                  Register Your Mosque / Madrasa for Verification & Onboarding
                </p>
              </div>
            </div>

            {errorMsg && (
              <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-3.5 text-xs">
              {/* Mosque Name */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  मदरसा / मस्जिद का पूरा नाम *
                </label>
                <div className="relative">
                  <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={masjidName}
                    onChange={(e) => setMasjidName(e.target.value)}
                    placeholder="उदा. मदरसा फैजाने रज़ा, सकरा"
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                </div>
              </div>

              {/* Location: District, City, State */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">ज़िला (District) *</label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="text"
                      required
                      value={district}
                      onChange={(e) => setDistrict(e.target.value)}
                      placeholder="उदा. Muzaffarpur"
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">तहसील / कस्बा (City/Town)</label>
                  <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    placeholder="उदा. Sakra / Marwan"
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">राज्य (State) *</label>
                  <select
                    value={state}
                    onChange={(e) => setState(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium bg-white"
                  >
                    <option value="Bihar">Bihar</option>
                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                    <option value="West Bengal">West Bengal</option>
                    <option value="Jharkhand">Jharkhand</option>
                    <option value="Delhi">Delhi</option>
                    <option value="Maharashtra">Maharashtra</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              {/* Full Address */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  गाँव / मोहल्ला एवं पिनकोड (Full Address)
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="उदा. ग्राम व पोस्ट: रामपुर, थाना: सकरा, पिन: 843105"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                />
              </div>

              {/* Applicant / Mutawalli Details */}
              <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center gap-1.5 text-xs font-extrabold text-slate-800">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>मुतवल्ली / कमेटी व्यवस्थापक विवरण (Admin Applicant)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  <div>
                    <label className="font-bold text-slate-700 block mb-1">मुतवल्ली का नाम *</label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                      <input
                        type="text"
                        required
                        value={applicantName}
                        onChange={(e) => setApplicantName(e.target.value)}
                        placeholder="उदा. हाफ़िज़ अनवर आलम"
                        className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium bg-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="font-bold text-slate-700 block mb-1">फ़ोन / व्हाट्सएप नंबर *</label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                      <input
                        type="tel"
                        required
                        value={applicantPhone}
                        onChange={(e) => setApplicantPhone(e.target.value)}
                        placeholder="+91 98XXXXXXXX"
                        className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium bg-white"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    प्रस्तावित एडमिन ईमेल आईडी (Admin Login Email) *
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <input
                      type="email"
                      required
                      value={applicantEmail}
                      onChange={(e) => setApplicantEmail(e.target.value)}
                      placeholder="उदा. anwar.madrasa@gmail.com"
                      className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium bg-white"
                    />
                  </div>
                  <span className="text-[10px] text-slate-500 mt-1 block">
                    अप्रूवल के बाद इसी ईमेल से मुतवल्ली साहब अपना बैंक खाता व मदरसा मैनेज कर सकेंगे।
                  </span>
                </div>
              </div>

              {/* Optional Waqf / Society reg number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    वक्फ / सोसायटी रजिस्ट्रेशन सं. (वैकल्पिक)
                  </label>
                  <input
                    type="text"
                    value={waqfOrRegNumber}
                    onChange={(e) => setWaqfOrRegNumber(e.target.value)}
                    placeholder="उदा. WB/BR/2019/382"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">विशेष टिप्पणी (Note)</label>
                  <input
                    type="text"
                    value={note}
                    onChange={(e) => setNote(e.target.value)}
                    placeholder="उदा. दारुल इक़ामा व हिफ़्ज़ शाखा"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500 font-medium"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={handleResetAndClose}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 font-bold transition-colors cursor-pointer"
                >
                  रद्द करें
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold shadow-md flex items-center gap-1.5 transition-all cursor-pointer"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>सबमिट हो रहा है...</span>
                    </>
                  ) : (
                    <span>रिक्वेस्ट भेजें (Submit Request)</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};

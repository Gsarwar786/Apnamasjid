import React, { useState } from 'react';
import { updateProfile } from 'firebase/auth';
import { doc, updateDoc } from 'firebase/firestore';
import { sendPasswordResetEmail } from 'firebase/auth';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { UserProfile, SupportedLanguage } from '../types';
import { translations } from '../i18n';
import { User, Mail, Calendar, KeyRound, LogOut, CheckCircle2, AlertCircle, Edit3, Loader2 } from 'lucide-react';

interface ProfileViewProps {
  userProfile: UserProfile | null;
  currentLang: SupportedLanguage;
  onLogout: () => void;
  onRefreshProfile?: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({
  userProfile,
  currentLang,
  onLogout,
}) => {
  const t = translations[currentLang];
  const isRtl = currentLang === 'ur' || currentLang === 'ar';

  const [isEditing, setIsEditing] = useState(false);
  const [nameInput, setNameInput] = useState(userProfile?.name || '');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const creationDateStr = userProfile?.createdAt
    ? new Date(userProfile.createdAt).toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
      })
    : 'Active Member';

  const handleUpdateName = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userProfile) return;
    setMessage(null);

    const clean = nameInput.trim();
    if (!clean) {
      setMessage({ type: 'error', text: 'Name cannot be empty.' });
      return;
    }

    try {
      setSaving(true);
      const userRef = doc(db, 'users', userProfile.uid);
      await updateDoc(userRef, {
        name: clean,
        updatedAt: new Date().toISOString(),
      });

      if (auth.currentUser) {
        await updateProfile(auth.currentUser, { displayName: clean });
      }

      setIsEditing(false);
      setMessage({ type: 'success', text: t.updateSuccess });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${userProfile.uid}`);
    } finally {
      setSaving(false);
    }
  };

  const handleSendPasswordReset = async () => {
    if (!userProfile?.email) return;
    setMessage(null);

    try {
      setSaving(true);
      await sendPasswordResetEmail(auth, userProfile.email);
      setMessage({
        type: 'success',
        text: `Password reset link sent to ${userProfile.email}. Check your inbox.`,
      });
    } catch (err: any) {
      console.error('Password reset request error:', err);
      setMessage({ type: 'error', text: err?.message || 'Could not send reset email.' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 pb-20 md:pb-8 max-w-2xl mx-auto" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-emerald-100">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-emerald-700 text-white flex items-center justify-center text-2xl font-bold shadow-md shadow-emerald-700/20">
            {userProfile?.name?.charAt(0)?.toUpperCase() || 'U'}
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">{userProfile?.name || 'User Profile'}</h2>
            <p className="text-xs text-slate-500 mt-0.5">{userProfile?.email}</p>
          </div>
        </div>

        {message && (
          <div
            className={`mt-5 p-3.5 rounded-xl text-xs flex items-center gap-2 ${
              message.type === 'success'
                ? 'bg-emerald-50 border border-emerald-200 text-emerald-900'
                : 'bg-red-50 border border-red-200 text-red-900'
            }`}
          >
            {message.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            )}
            <span>{message.text}</span>
          </div>
        )}

        {/* Profile Details List */}
        <div className="mt-6 divide-y divide-slate-100 border-t border-slate-100 text-xs">
          <div className="py-3.5 flex items-center justify-between">
            <span className="text-slate-500 flex items-center gap-2">
              <User className="w-4 h-4 text-emerald-700" />
              <span>{t.fullName}</span>
            </span>
            <span className="font-semibold text-slate-900">{userProfile?.name}</span>
          </div>

          <div className="py-3.5 flex items-center justify-between">
            <span className="text-slate-500 flex items-center gap-2">
              <Mail className="w-4 h-4 text-emerald-700" />
              <span>{t.email}</span>
            </span>
            <span className="font-semibold text-slate-900">{userProfile?.email}</span>
          </div>

          <div className="py-3.5 flex items-center justify-between">
            <span className="text-slate-500 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-700" />
              <span>{t.accountCreated}</span>
            </span>
            <span className="font-semibold text-slate-900">{creationDateStr}</span>
          </div>
        </div>

        {/* Edit Profile Form */}
        {isEditing ? (
          <form onSubmit={handleUpdateName} className="mt-5 p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <label className="block text-xs font-bold text-slate-800">
              Update Name
            </label>
            <input
              id="edit-profile-name-input"
              type="text"
              required
              value={nameInput}
              onChange={(e) => setNameInput(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
            />
            <div className="flex items-center gap-2">
              <button
                id="save-profile-btn"
                type="submit"
                disabled={saving}
                className="py-2 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-sm flex items-center gap-1.5 disabled:opacity-60"
              >
                {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
                <span>{t.saveChanges}</span>
              </button>
              <button
                id="cancel-edit-profile-btn"
                type="button"
                onClick={() => setIsEditing(false)}
                className="py-2 px-4 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs"
              >
                Cancel
              </button>
            </div>
          </form>
        ) : (
          <div className="mt-6 flex flex-wrap items-center gap-3 pt-4 border-t border-slate-100">
            <button
              id="profile-edit-name-btn"
              onClick={() => {
                setNameInput(userProfile?.name || '');
                setIsEditing(true);
              }}
              className="py-2.5 px-4 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs flex items-center gap-1.5 transition-colors"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{t.editProfile}</span>
            </button>

            <button
              id="profile-change-pw-btn"
              onClick={handleSendPasswordReset}
              disabled={saving}
              className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs flex items-center gap-1.5 transition-colors disabled:opacity-60"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>{t.changePassword}</span>
            </button>

            <button
              id="profile-logout-btn"
              onClick={onLogout}
              className="py-2.5 px-4 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs flex items-center gap-1.5 transition-colors ml-auto"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{t.logout}</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

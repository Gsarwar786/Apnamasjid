export type SupportedLanguage = 'en' | 'hi' | 'ur' | 'ar';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  walletBalance: number;
  monthlyCharity: number;
  autoCharity: boolean;
  lastMonthlyFeePaid?: string; // e.g. "2026-09"
  masjidId?: string;
  masjidName?: string;
  role?: 'user' | 'admin' | 'superadmin';
  createdAt?: string | any;
  updatedAt?: string | any;
}

export interface MasjidDetails {
  id: string;
  name: string;
  address: string;
  city?: string;
  district?: string;
  state?: string;
  description: string;
  purpose: string;
  photoUrl: string;
  contact: string;
  active: boolean;
  // Admin contact details for members support
  adminName?: string;
  adminPhone?: string;
  adminWhatsapp?: string;
  adminEmail?: string;
  adminSupportTiming?: string;
  // Bank details configured by admin
  bankAccountName: string;
  bankName: string;
  bankAccountNumber: string;
  bankIfsc: string;
  bankUpiId: string;
  qrImageUrl?: string;
  // Community monthly fee per household/member & month note
  monthlyCommunityFee: number;
  monthlyFeeNote?: string;
  supportInfo?: string;
  updatedAt?: string | any;
}

export interface MasjidRegistrationRequest {
  id: string;
  masjidName: string;
  city: string;
  district: string;
  state: string;
  address: string;
  applicantName: string;
  applicantPhone: string;
  applicantEmail: string;
  waqfOrRegNumber?: string;
  note?: string;
  status: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
  requestedAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
}

export interface WalletTransaction {
  id: string;
  uid: string;
  type: 'wallet_topup' | 'charity_donation' | 'monthly_charity' | 'monthly_fee';
  amount: number;
  status: 'pending' | 'successful' | 'failed';
  paymentId?: string;
  description?: string;
  createdAt: any;
}

export interface PaymentRequest {
  id: string;
  uid: string;
  amount: number;
  provider: 'UPI';
  providerTransactionId?: string;
  status: 'pending' | 'verified' | 'rejected';
  userEmail?: string;
  userName?: string;
  createdAt: any;
  verifiedAt?: any;
}

export interface CharityRecord {
  id: string;
  uid: string;
  amount: number;
  type:
    | 'monthly_fee'
    | 'monthly_charity'
    | 'one_time_charity'
    | 'sadqah'
    | 'zakat'
    | 'lillah'
    | 'renovation'
    | 'rabi_ul_awwal';
  status: 'successful' | 'pending' | 'failed';
  donorName?: string;
  isAnonymous?: boolean;
  masjidId?: string;
  transactionId?: string;
  monthYear?: string; // e.g. "Sep 2026"
  createdAt: any;
}

export interface SupportTicket {
  id: string;
  uid: string;
  userEmail: string;
  userName: string;
  subject: string;
  message: string;
  status: 'Open' | 'In Progress' | 'Resolved';
  reply?: string;
  createdAt: any;
  updatedAt?: any;
}

export interface AdvertisementItem {
  id: string;
  title: string;
  description: string;
  imageUrl?: string;
  active: boolean;
  category?: 'rabi_ul_awwal' | 'renovation' | 'ramadan' | 'general';
  targetAmount?: number;
  collectedAmount?: number;
  startDate?: string;
  endDate?: string;
  createdAt?: string;
}

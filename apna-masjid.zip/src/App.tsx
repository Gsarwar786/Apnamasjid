import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User, signOut } from 'firebase/auth';
import {
  doc,
  getDoc,
  onSnapshot,
  collection,
  query,
  where,
  setDoc,
} from 'firebase/firestore';
import { auth, db } from './firebase';
import {
  UserProfile,
  SupportedLanguage,
  PaymentRequest,
  CharityRecord,
  WalletTransaction,
  SupportTicket,
  AdvertisementItem,
  MasjidDetails,
} from './types';
import { translations } from './i18n';

// Components
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { UnauthenticatedHome } from './components/UnauthenticatedHome';
import { AuthenticatedHome } from './components/AuthenticatedHome';
import { WalletView } from './components/WalletView';
import { CharityView } from './components/CharityView';
import { HistoryView } from './components/HistoryView';
import { ProfileView } from './components/ProfileView';
import { SupportView } from './components/SupportView';
import { AdminDashboard } from './components/AdminDashboard';
import { AuthModal } from './components/AuthModal';
import { RegisterMasjidModal } from './components/RegisterMasjidModal';

const defaultMasjid: MasjidDetails = {
  id: 'madrasa_tegiya',
  name: 'Madrasa Tegiya Talim Al Islam',
  address: 'Kamalpura Baradih, Muzaffarpur, Bihar - 843113',
  district: 'Muzaffarpur',
  state: 'Bihar',
  city: 'Muzaffarpur',
  description:
    'Dedicated to imparting authentic Islamic knowledge, Quranic Hifz, Tajweed, moral teachings, and community welfare with boarding and educational facilities.',
  purpose:
    'Religious education, Hifz-e-Quran, community charity, student accommodation, and Islamic spiritual guidance.',
  photoUrl: '/madrasa_tegiya.jpg',
  contact: '+91 9876543210',
  active: true,
  bankAccountName: '',
  bankName: '',
  bankAccountNumber: '',
  bankIfsc: '',
  bankUpiId: '',
  monthlyCommunityFee: 200,
  monthlyFeeNote: 'इमाम साहब की मासिक तनख्वाह एवं मस्जिद बिजली, पानी, सफाई मेंटेनेंस',
  adminName: 'Hafez Md. Rizwan (मुतवल्ली / व्यवस्थापक)',
  adminPhone: '+91 9876543210',
  adminWhatsapp: '+91 9876543210',
  adminEmail: 'rockybo09876@gmail.com',
  adminSupportTiming: 'सुबह 8:00 AM से रात 9:00 PM (जुमा को 2:00 PM के बाद)',
  supportInfo: 'Contact admin: rockybo09876@gmail.com',
};

export default function App() {
  // Navigation & Language
  const [activeTab, setActiveTab] = useState<string>('home');
  const [currentLang, setCurrentLang] = useState<SupportedLanguage>('hi');

  // Auth & Profile
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loadingAuth, setLoadingAuth] = useState(true);

  // Auth Modal
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'signup'>('login');
  const [authModalRole, setAuthModalRole] = useState<'user' | 'admin'>('user');

  // Register Mosque Modal
  const [isRegisterMasjidOpen, setIsRegisterMasjidOpen] = useState(false);

  // Legal Modal
  const [legalModalType, setLegalModalType] = useState<
    'privacy' | 'terms' | 'refund' | 'contact' | null
  >(null);

  // Admin & Super Admin status
  const [isAdmin, setIsAdmin] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);

  // Multi-tenancy Mosques State
  const [allMasjids, setAllMasjids] = useState<MasjidDetails[]>([defaultMasjid]);
  const [selectedMasjidId, setSelectedMasjidId] = useState<string>('madrasa_tegiya');
  const [masjidDetails, setMasjidDetails] = useState<MasjidDetails>(defaultMasjid);

  // Real-time collections for user
  const [payments, setPayments] = useState<PaymentRequest[]>([]);
  const [charities, setCharities] = useState<CharityRecord[]>([]);
  const [allCommunityCharities, setAllCommunityCharities] = useState<CharityRecord[]>([]);
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [supportTickets, setSupportTickets] = useState<SupportTicket[]>([]);
  const [advertisements, setAdvertisements] = useState<AdvertisementItem[]>([]);

  // 1. Firebase Auth listener with Multi-Tenant Admin Resolution
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        const cleanEmail = user.email?.toLowerCase().trim() || '';
        const isSuper = cleanEmail === 'rockybo09876@gmail.com';
        setIsSuperAdmin(isSuper);

        try {
          // Check admin by user UID
          let adminDoc = await getDoc(doc(db, 'admins', user.uid));

          // If not found by UID, check admin by lowercase email
          if (!adminDoc.exists() && cleanEmail) {
            adminDoc = await getDoc(doc(db, 'admins', cleanEmail));
          }

          if (adminDoc.exists()) {
            setIsAdmin(true);
            const adminData = adminDoc.data();
            if (adminData?.masjidId) {
              setSelectedMasjidId(adminData.masjidId);
            }
          } else if (isSuper) {
            await setDoc(
              doc(db, 'admins', user.uid),
              {
                role: 'super_admin',
                email: user.email,
                grantedAt: new Date().toISOString(),
              },
              { merge: true }
            );
            setIsAdmin(true);
          } else {
            setIsAdmin(false);
          }
        } catch (e) {
          if (isSuper) {
            setIsAdmin(true);
          }
        }
      } else {
        setUserProfile(null);
        setIsAdmin(false);
        setIsSuperAdmin(false);
        setActiveTab('home');
      }
      setLoadingAuth(false);
    });

    return () => unsubscribeAuth();
  }, []);

  // 2. Real-time User Profile sync
  useEffect(() => {
    if (!currentUser) return;

    const userDocRef = doc(db, 'users', currentUser.uid);
    const unsubProfile = onSnapshot(
      userDocRef,
      (docSnap) => {
        if (docSnap.exists()) {
          const profileData = docSnap.data() as UserProfile;
          setUserProfile(profileData);
          if (profileData.masjidId) {
            setSelectedMasjidId(profileData.masjidId);
          }
        }
      },
      (err) => {
        console.warn('User profile snapshot error:', err);
      }
    );

    return () => unsubProfile();
  }, [currentUser]);

  // 3. Real-time Masjids list sync
  useEffect(() => {
    const unsubMasjids = onSnapshot(
      collection(db, 'masjids'),
      (snap) => {
        if (!snap.empty) {
          const list: MasjidDetails[] = [];
          snap.forEach((d) => {
            list.push({ id: d.id, ...d.data() } as MasjidDetails);
          });
          setAllMasjids(list);
        }
      },
      (err) => console.warn('Masjids snapshot error:', err)
    );

    return () => unsubMasjids();
  }, []);

  // 4. Real-time Masjid Configuration & Details sync
  useEffect(() => {
    const activeId = selectedMasjidId || userProfile?.masjidId || 'madrasa_tegiya';
    const unsubMasjid = onSnapshot(
      doc(db, 'masjids', activeId),
      (snap) => {
        if (snap.exists()) {
          setMasjidDetails((prev) => ({ ...prev, ...(snap.data() as MasjidDetails) }));
        } else {
          const found = allMasjids.find((m) => m.id === activeId);
          if (found) {
            setMasjidDetails(found);
          }
        }
      },
      (err) => console.warn('Masjid details snapshot error:', err)
    );

    return () => unsubMasjid();
  }, [selectedMasjidId, userProfile?.masjidId, allMasjids]);

  // 4. Real-time User Collections sync
  useEffect(() => {
    if (!currentUser) {
      setPayments([]);
      setCharities([]);
      setTransactions([]);
      setSupportTickets([]);
      setAllCommunityCharities([]);
      return;
    }

    // Payments for this user
    const qPayments = query(collection(db, 'payments'), where('uid', '==', currentUser.uid));
    const unsubPayments = onSnapshot(
      qPayments,
      (snapshot) => {
        const list: PaymentRequest[] = [];
        snapshot.forEach((d) => list.push({ id: d.id, ...d.data() } as any));
        list.sort(
          (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
        );
        setPayments(list);
      },
      (err) => console.warn('Payments snapshot error:', err)
    );

    // User's own donations
    const qCharities = query(collection(db, 'charities'), where('uid', '==', currentUser.uid));
    const unsubCharities = onSnapshot(
      qCharities,
      (snapshot) => {
        const list: CharityRecord[] = [];
        snapshot.forEach((d) => list.push({ id: d.id, ...d.data() } as any));
        list.sort(
          (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
        );
        setCharities(list);
      },
      (err) => console.warn('Charities snapshot error:', err)
    );

    // Public community ledger: all contributions
    const unsubAllCharities = onSnapshot(
      collection(db, 'charities'),
      (snapshot) => {
        const list: CharityRecord[] = [];
        snapshot.forEach((d) => list.push({ id: d.id, ...d.data() } as any));
        list.sort(
          (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
        );
        setAllCommunityCharities(list);
      },
      (err) => console.warn('All charities snapshot error:', err)
    );

    // Transactions for this user
    const qTxns = query(collection(db, 'transactions'), where('uid', '==', currentUser.uid));
    const unsubTxns = onSnapshot(
      qTxns,
      (snapshot) => {
        const list: WalletTransaction[] = [];
        snapshot.forEach((d) => list.push({ id: d.id, ...d.data() } as any));
        list.sort(
          (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
        );
        setTransactions(list);
      },
      (err) => console.warn('Transactions snapshot error:', err)
    );

    // Support tickets for this user
    const qSupport = query(
      collection(db, 'supportMessages'),
      where('uid', '==', currentUser.uid)
    );
    const unsubSupport = onSnapshot(
      qSupport,
      (snapshot) => {
        const list: SupportTicket[] = [];
        snapshot.forEach((d) => list.push({ id: d.id, ...d.data() } as any));
        list.sort(
          (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
        );
        setSupportTickets(list);
      },
      (err) => console.warn('Support snapshot error:', err)
    );

    return () => {
      unsubPayments();
      unsubCharities();
      unsubAllCharities();
      unsubTxns();
      unsubSupport();
    };
  }, [currentUser]);

  // 5. Advertisements sync (global)
  useEffect(() => {
    const unsubAds = onSnapshot(
      collection(db, 'advertisements'),
      (snapshot) => {
        const list: AdvertisementItem[] = [];
        snapshot.forEach((d) => list.push({ id: d.id, ...d.data() } as any));
        setAdvertisements(list);
      },
      (err) => console.warn('Ads snapshot error:', err)
    );

    return () => unsubAds();
  }, []);

  // Handlers
  const handleOpenAuth = (mode: 'login' | 'signup', role: 'user' | 'admin' = 'user') => {
    setAuthModalMode(mode);
    setAuthModalRole(role);
    setIsAuthOpen(true);
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
      setActiveTab('home');
    } catch (e) {
      console.error('Sign out error:', e);
    }
  };

  if (loadingAuth) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4 text-white">
        <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="font-arabic text-emerald-400 text-lg">بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ</p>
        <p className="text-xs text-slate-400 mt-2">Connecting to Apna Masjid secure portal...</p>
      </div>
    );
  }

  // 1. Unauthenticated Visitor Flow:
  if (!currentUser) {
    return (
      <>
        <UnauthenticatedHome
          onOpenLogin={(role) => handleOpenAuth('login', role || 'user')}
          onOpenSignUp={(role) => handleOpenAuth('signup', role || 'user')}
          currentLang={currentLang}
          onLanguageChange={setCurrentLang}
          onOpenLegal={(type) => setLegalModalType(type)}
          allMasjids={allMasjids}
          selectedMasjidId={selectedMasjidId}
          onSelectMasjid={(id) => setSelectedMasjidId(id)}
          onOpenRegisterMasjid={() => setIsRegisterMasjidOpen(true)}
        />

        <AuthModal
          isOpen={isAuthOpen}
          initialMode={authModalMode}
          initialRole={authModalRole}
          currentLang={currentLang}
          masjids={allMasjids}
          selectedMasjidId={selectedMasjidId}
          onOpenRegisterMasjid={() => setIsRegisterMasjidOpen(true)}
          onClose={() => setIsAuthOpen(false)}
          onSuccess={(role) => {
            if (role === 'admin') {
              setActiveTab('admin');
            }
          }}
        />

        <RegisterMasjidModal
          isOpen={isRegisterMasjidOpen}
          onClose={() => setIsRegisterMasjidOpen(false)}
          currentLang={currentLang}
        />

        {legalModalType && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm">
            <div className="bg-white max-w-lg w-full rounded-2xl p-6 shadow-2xl space-y-4 text-xs text-slate-600 border border-slate-200">
              <h3 className="text-base font-bold text-slate-900 capitalize">
                {legalModalType === 'privacy' && 'Privacy Policy'}
                {legalModalType === 'terms' && 'Terms & Conditions'}
                {legalModalType === 'refund' && 'Refund & Donation Policy'}
                {legalModalType === 'contact' && 'Official Contact Information'}
              </h3>

              <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                {legalModalType === 'privacy' && (
                  <>
                    <p>Apna Masjid takes member privacy with utmost sanctity. All data including email, name, and contribution logs are securely isolated.</p>
                    <p>Mosque finances and member wallets are encrypted, audited, and strictly safeguarded against unauthorized access.</p>
                  </>
                )}
                {legalModalType === 'terms' && (
                  <>
                    <p>1. Only verified accounts may participate in Madrasa donations and community campaigns.</p>
                    <p>2. Wallet balances are maintained securely and subject to administrative bank settlement confirmation.</p>
                    <p>3. Misuse, fraudulent UTR generation, or unauthorized access attempts will lead to immediate account suspension.</p>
                  </>
                )}
                {legalModalType === 'refund' && (
                  <>
                    <p>Charity contributions (Sadaqah, Zakat, Lillah) made to Madrasa Tegiya Talim Al Islam are religious voluntary contributions dedicated to student education and campus facilities.</p>
                    <p>In case of duplicate bank transfer or erroneous double-payment, donors can lodge a ticket under the Helpdesk Support section with their 12-digit UPI UTR for verification and adjustment.</p>
                  </>
                )}
                {legalModalType === 'contact' && (
                  <>
                    <p className="font-bold text-slate-800">MADRASA TEGIYA TALIM AL ISLAM</p>
                    <p>Address: Kamalpura Baradih, Muzaffarpur, Bihar - 843113</p>
                    <p>Official UPI ID: {masjidDetails.bankUpiId}</p>
                    <p>Authorized Bank: {masjidDetails.bankName} (A/C: {masjidDetails.bankAccountNumber})</p>
                    <p>Authorized Admin: rockybo09876@gmail.com</p>
                  </>
                )}
              </div>

              <div className="pt-2 text-right">
                <button
                  onClick={() => setLegalModalType(null)}
                  className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </>
    );
  }

  // 2. Authenticated User Flow:
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Top Navigation */}
      <Navbar
        userProfile={userProfile}
        currentLang={currentLang}
        activeTab={activeTab}
        isAdmin={isAdmin}
        currentMasjidName={masjidDetails.name}
        onOpenRegisterMasjid={() => setIsRegisterMasjidOpen(true)}
        onLanguageChange={setCurrentLang}
        onNavigate={setActiveTab}
        onLogout={handleLogout}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-6">
        {activeTab === 'home' && (
          <AuthenticatedHome
            userProfile={userProfile}
            currentLang={currentLang}
            advertisements={advertisements}
            masjidDetails={masjidDetails}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'wallet' && (
          <WalletView
            userProfile={userProfile}
            currentLang={currentLang}
            payments={payments}
            masjidDetails={masjidDetails}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'charity' && (
          <CharityView
            userProfile={userProfile}
            currentLang={currentLang}
            masjidDetails={masjidDetails}
            onNavigate={setActiveTab}
          />
        )}

        {activeTab === 'history' && (
          <HistoryView
            allCommunityCharities={allCommunityCharities}
            userCharities={charities}
            transactions={transactions}
            currentLang={currentLang}
            currentUserId={currentUser?.uid}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileView
            userProfile={userProfile}
            currentLang={currentLang}
            onLogout={handleLogout}
          />
        )}

        {activeTab === 'support' && (
          <SupportView
            userProfile={userProfile}
            supportTickets={supportTickets}
            masjidDetails={masjidDetails}
            currentLang={currentLang}
          />
        )}

        {activeTab === 'admin' && isAdmin && (
          <AdminDashboard
            currentLang={currentLang}
            currentUserProfile={userProfile}
            masjidDetails={masjidDetails}
            allMasjids={allMasjids}
            isSuperAdmin={isSuperAdmin}
            onSelectMasjid={(id) => setSelectedMasjidId(id)}
            onUpdateMasjidDetails={(details) =>
              setMasjidDetails((prev) => ({ ...prev, ...details }))
            }
            onCloseAdmin={() => setActiveTab('home')}
          />
        )}
      </main>

      {/* Mosque Registration Modal accessible when authenticated too */}
      <RegisterMasjidModal
        isOpen={isRegisterMasjidOpen}
        onClose={() => setIsRegisterMasjidOpen(false)}
        currentLang={currentLang}
      />

      {/* Bottom Navigation for Mobile Devices */}
      <BottomNav
        activeTab={activeTab}
        currentLang={currentLang}
        onTabChange={setActiveTab}
      />
    </div>
  );
}
